# E5 全量战役原始证据打包（e5-all-20261008-a11）

打包日期：2026-10-10
战役 run：`e5-all-20261008-a11-v02`（最终结论 PASS：verify-items 逐项 60/60 + collection 独立重跑 60/60，双阶段同源码快照、无 PASS 复用）
对应源码提交：`674792e`（经 PR #9 合并入 `main`，合并提交 `9c25be8`）
测试源码冻结快照：`82336d6b`（即 `local/source-v03.tar.gz`，逐文件 sha256 见 `local/snapshot-v03.json`）

## 目录结构

### local/ — 发起侧留存工件（11 个文件，约 20M）
- `result-a11-v02.json` — 战役结果 JSON，双阶段 120 项全字段（taskId、boundary、argv、起止时间、时长、退出码、测试计数、sha256、postcondition）
- `report-detailed-a11-v02.md` — 逐项详细报告（由 result.json 派生）
- `report-rows.txt` — 双阶段 120 行摘要
- `source-v0{1,2,3}.tar.gz` + `snapshot-v0{1,2,3}.json` — 三轮源码冻结快照与逐文件清单（v03 即最终测试树 `82336d6b`）
- `provision_e5_clones_full_a1{0,1}.py` — run-scoped 隔离克隆 provisioner（mysqldump 复制 + readiness 异常精确清理事务 + CAS/lease 门禁）

### remote/e5-all-20261008-a11-evidence/ — 测试节点侧战役证据（2051 个文件，约 24M）
- `runs/e5-all-20261008-a11-v02/` — 最终 PASS run 完整产物：
  - `items/` 与 `collection/` — 两阶段各 60 套件的 stdout/stderr 日志（共 240 份，生成时已经 `scripts/test_campaign.py` 的 `scrub_log` 净化）
  - `result.json` — 战役原生结果记录
  - `items/criterion/`、`collection/criterion/` — Criterion 基准原始工件（base/new 的 estimates/sample/tukey/benchmark.json，共 4 个基准套件）
- `runs/e5-all-20261008-a11-v01/` — 首次启动失败留存（launcher 工作目录笔误，49 个文件）
- `campaign-a11.env.redacted` — 战役环境变量清单，**值全部脱敏**；原 `campaign-a11.env` 因含 `DATABASE_URL`/`RABBITMQ_URL`/`REDIS_URL` 真实口令，未纳入本包
- `campaign-launch-a11-v0{1,2}.sh`、`campaign-a11-v0{1,2}.nohup.log`、`selection-a11.json`（60 项选择清单）

### remote/e5-all-20261008-a11-provision/ — 隔离克隆预置证据（21 个文件，约 43M）
- `backup/` — 克隆库内容 dump、readiness 异常清理事务记录、schema/data 校验 SQL（克隆命名 `astral_rehearsal_e5all20261008aNN` / `sdk_identity_mapping_test_e5all20261008aNN`）
- `build/`、`evidence/`、`source/` — 本轮为空目录；`provision-state.json` 为预置状态记录

## 安全审查记录（2026-10-10，打包前全量执行）

- **IPv4 全量扫描**：2083 个文件中仅原 `campaign-a11.env` 命中 `127.0.0.1`（回环地址）；其余文件零命中，无内网/公网 IP 泄漏。
- **带凭据 URL 扫描**（`scheme://user:password@` 形态）：仅原 `campaign-a11.env` 命中；原件已删除，以 `<redacted>` 版替代。
- **口令字符串扩散检查**：MySQL 与 RabbitMQ 两个口令字面量在全部待打包文件中仅存在于原 env 文件，删除后无任何残留。
- **password/token/secret 关键词复查**：其余命中均为测试用例名或数据库列名（如 `l2_hmac_secret_validation_is_fail_closed`、`lease_token_hash`），非秘密。
- **套件日志净化**：由 `scripts/test_campaign.py::scrub_log` 在日志生成时执行——敏感环境变量值与全部 `scheme://` URL 已替换为 `[redacted]`/`[redacted-url]`。

## 排除项（未纳入本包，仍完整保留在测试节点 astral-test-runs/ 下）

- `e5-all-20261008-a10-evidence`（31G，中间尝试轮次，含大体量构建产物，不适合入 git）
- `e5-all-20261008-a08-evidence`（81M）、`e5-all-20261008-a09-evidence`（1.2M）、`e5-all-20261008-a06/a07-provision`、基目录 `e5-all-20261008`（205M）：同战役的中间失败/预置尝试，最终结论以 a11-v02 为准。

## 完整性

- `SHA256SUMS.txt` 覆盖本包除其自身外的全部内容文件（打包前生成）。
