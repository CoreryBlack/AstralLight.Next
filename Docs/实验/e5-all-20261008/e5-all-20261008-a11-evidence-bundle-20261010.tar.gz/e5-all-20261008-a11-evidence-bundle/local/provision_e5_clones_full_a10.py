from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time
from datetime import datetime, timezone

os.umask(0o077)

MYSQL = 'astral-test-gate20261007-mysql-1'
ORDINARY_SOURCE = 'astral_test'
MAPPING_SOURCE = 'sdk_identity_mapping_test_gate20261007'
PHASES = {
    'identity-retest': (
        'e5-fix-identity-20261008-a02',
        'e5-fix-identity-20261008-a02-provision-r03',
        [(ORDINARY_SOURCE, 'astral_rehearsal_e5fix20261008r03', 'identity-retest')],
    ),
    'full-campaign': (
        'e5-all-20261008-a10',
        'e5-all-20261008-a10-provision',
        [
            (ORDINARY_SOURCE, 'astral_rehearsal_e5all20261008a10', 'full-campaign'),
            (MAPPING_SOURCE, 'sdk_identity_mapping_test_e5all20261008a10', 'full-campaign'),
        ],
    ),
}
parser = argparse.ArgumentParser()
parser.add_argument('--phase', choices=PHASES, required=True)
PHASE = parser.parse_args().phase
RUN_ID, PROVISION_DIR, CLONES = PHASES[PHASE]
BASE = Path.home() / 'astral-test-runs' / PROVISION_DIR
PROVISION_LOCK = Path.home() / '.astral-test-locks' / 'e5-mysql-clone-provision.lock'
ACTIVE_SOURCES = tuple(dict.fromkeys(source for source, _, _ in CLONES))
EXPECTED_ROW_COUNT_HASHES = {
    ORDINARY_SOURCE: '8027810adb352f7d0f7e4adeaed74f5bf34a68ae0025dc0bb6654f799b8b92c3',
    MAPPING_SOURCE: 'fba0d306e1ec4ffb42587c3f1c9e9befd4d1ddec1c3fdafc9000c6e438b63325',
}
MAPPING_ENUM_CONTRACT = [
    "integration_identity_mapping\tenum('ACTIVE','DISABLED','REVOKED')\tascii\tascii_bin\tNO",
    "integration_identity_mapping_operation\tenum('PENDING','COMPLETED')\tascii\tascii_bin\tNO",
]
SPLIT = {
    'tenant_id': 107658855600000,
    'card_id': 107658855600001,
    'aggregate_id': 107658855600002,
    'pointer_id': 21,
    'manifest_id': 30,
    'segment_id': 30,
    'event_id': 'ev-l2ev-db-split-7d618cd36fee47e1802244b4d83c000c-gen1',
    'operation_id': 'op-l2ev-db-split-7d618cd36fee47e1802244b4d83c000c-gen1',
}
SPLIT_TABLES = (
    'authorization_projection_current',
    'authorization_projection_manifest_segment',
    'authorization_projection_manifest',
    'authorization_projection_segment',
)
DATABASE_NAME = re.compile(r'^[A-Za-z0-9_]{1,64}$')
ORDINARY_CLONE_NAME = re.compile(r'^astral_rehearsal_[a-z0-9_]{1,47}$')
DEDICATED_CLONE_NAME = re.compile(r'^sdk_identity_mapping_test_[a-z0-9_]{1,38}$')
EXPECTED_SOURCE_SNAPSHOT = 'db32b708a2588950166c9deedcf6551fab994ea6fce43fca16ae0e1a204dbbec'
RETEST_RUN_ID = 'e5-fix-identity-20261008-a02'
RETEST_TARGET = 'astral_rehearsal_e5fix20261008r03'
RETEST_PROVISION_DIR = 'e5-fix-identity-20261008-a02-provision-r03'
RETEST_EVIDENCE_DIR = 'e5-fix-identity-20261008-a02-evidence'
RETEST_RECONCILE_DIR = 'e5-fix-identity-20261008-a02-reconcile'


def mysql_argv(database=None, dump=False, *, data_only=False, schema_only=False, where=None, tables=()):
    if dump:
        args = ['mysqldump', '--user=root', '--single-transaction', '--quick', '--hex-blob',
                '--no-tablespaces', '--set-gtid-purged=OFF', '--skip-comments', '--compact']
        if data_only:
            args += ['--no-create-info', '--skip-triggers', '--complete-insert',
                     '--order-by-primary', '--skip-extended-insert']
        if schema_only:
            args += ['--no-data', '--skip-triggers']
        if where is not None:
            args.append('--where=' + where)
        if not DATABASE_NAME.fullmatch(database or '') or any(not DATABASE_NAME.fullmatch(t) for t in tables):
            raise ValueError('invalid mysqldump database/table identifier')
        if tables:
            return args + [database, *tables]
        return args + ['--databases', '--no-create-db', database]
    args = ['mysql', '--user=root', '--batch', '--skip-column-names', '--raw']
    if database is not None:
        if not DATABASE_NAME.fullmatch(database):
            raise ValueError('invalid database identifier')
        args.append('--database=' + database)
    return args


def load_completed_retest_proof():
    proof_path = Path.home() / "astral-test-runs" / RETEST_EVIDENCE_DIR / "identity-gate-proof.json"
    if not proof_path.is_file():
        raise RuntimeError("derived identity gate proof is missing; full-run clone creation is blocked")
    proof = json.loads(proof_path.read_text(encoding="utf-8"))
    provision_path = Path(proof.get("original_provision_state_path", ""))
    verify_path = Path(proof.get("verify_items_result_path", ""))
    collection_path = Path(proof.get("collection_result_path", ""))
    reconciliation_path = Path(proof.get("clone_reconciliation_path", ""))
    manifest_path = Path.home() / "astral-test-runs" / RETEST_EVIDENCE_DIR / "source-r03" / "snapshot.json"
    required_paths = (provision_path, verify_path, collection_path, reconciliation_path, manifest_path)
    if not all(path.is_file() for path in required_paths):
        raise RuntimeError("identity proof references missing provision, source, campaign or reconciliation evidence")
    provision = json.loads(provision_path.read_text(encoding="utf-8"))
    verify = json.loads(verify_path.read_text(encoding="utf-8"))
    collection = json.loads(collection_path.read_text(encoding="utf-8"))
    reconciliation = json.loads(reconciliation_path.read_text(encoding="utf-8"))
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    expected_source = EXPECTED_SOURCE_SNAPSHOT
    if (proof.get("status") != "PASS" or
            proof.get("evidence_type") != "derived gate attestation; underlying provision state remains UNKNOWN and is not rewritten" or
            proof.get("source_sha256") != expected_source or
            proof.get("source_manifest_sha256") != hashlib.sha256(manifest_path.read_bytes()).hexdigest() or
            proof.get("source_file_count") != manifest.get("file_count") or manifest.get("source_sha256") != expected_source or
            proof.get("identity_mapping_selection") != ["identity-mapping-premise"] or
            proof.get("verify_items_run_id") != "e5-fix-identity-20261008-a02-v01" or
            proof.get("collection_run_id") != "e5-fix-identity-20261008-a02-r04" or
            proof.get("original_provision_status") != "UNKNOWN" or proof.get("clone_database") != RETEST_TARGET):
        raise RuntimeError("derived identity gate proof does not match the exact reviewed run and source freeze")
    if (provision.get("runId") != RETEST_RUN_ID or provision.get("status") != "UNKNOWN" or
            provision.get("no_migration") is not True or provision.get("no_original_database_write") is not True or
            hashlib.sha256(provision_path.read_bytes()).hexdigest() != proof.get("original_provision_state_sha256")):
        raise RuntimeError("original provision UNKNOWN record was changed or its hash does not match derived proof")
    if (hashlib.sha256(verify_path.read_bytes()).hexdigest() != proof.get("verify_items_result_sha256") or
            hashlib.sha256(collection_path.read_bytes()).hexdigest() != proof.get("collection_result_sha256") or
            hashlib.sha256(reconciliation_path.read_bytes()).hexdigest() != proof.get("clone_reconciliation_sha256")):
        raise RuntimeError("identity proof result or reconciliation hash does not match its referenced artifact")
    for report, expected_verify in ((verify, True), (collection, False)):
        if (report.get("status") != "PASS" or report.get("source_sha256") != expected_source or
                report.get("selection") != ["identity-mapping-premise"] or
                report.get("verify_items") is not expected_verify or report.get("stopped_at") is not None or
                report.get("preflight", {}).get("status") != "PASS" or report.get("preflight", {}).get("issues") != []):
            raise RuntimeError("identity premise report is not an exact, clean PASS")
        groups = (report.get("item_results", []), report.get("results", [])) if expected_verify else (report.get("results", []),)
        for phase_records in groups:
            if len(phase_records) != 1:
                raise RuntimeError("identity premise report is missing a required phase result")
            record = phase_records[0]
            if (record.get("id") != "identity-mapping-premise" or record.get("status") != "PASS" or
                    record.get("exit_code") != 0 or record.get("log_integrity") != "complete" or
                    record.get("stream_disconnect") is not False or record.get("tests", {}).get("passed") != 2 or
                    record.get("tests", {}).get("failed") != 0 or record.get("tests", {}).get("ignored") != 0):
                raise RuntimeError("identity premise phase does not have two complete passing assertions")
            for stream in ("stdout", "stderr"):
                log_path = record.get(stream)
                log_hash = record.get(stream + "_sha256")
                if (not isinstance(log_path, str) or not Path(log_path).is_file() or
                        hashlib.sha256(Path(log_path).read_bytes()).hexdigest() != log_hash):
                    raise RuntimeError("identity premise log is missing or its hash differs from result evidence")
    checks = reconciliation.get("checks", {})
    if (reconciliation.get("status") != "PASS" or reconciliation.get("clone_database") != RETEST_TARGET or
            reconciliation.get("source_database") != ORDINARY_SOURCE or
            checks.get("source_content_unchanged") is not True or
            checks.get("clone_content_matches_initial_minus_exact_four_rows") is not True or
            checks.get("source_exception_counts") != ["1"] * 4 or checks.get("clone_exception_counts") != ["0"] * 4 or
            checks.get("active_source_or_clone_connections") != "0" or checks.get("active_projection_leases") != "0" or
            proof.get("post_test_clone_data_matches_clean_baseline") is not True):
        raise RuntimeError("independent source/clone post-test reconciliation did not PASS")
    if (proof.get("database_side_effect_reconciliation", {}).get("mapping_rows") != "0" or
            proof.get("database_side_effect_reconciliation", {}).get("operation_rows") != "0" or
            proof.get("database_side_effect_reconciliation", {}).get("mapping_audit_rows") != "0" or
            proof.get("database_side_effect_reconciliation", {}).get("active_source_or_clone_sessions") != "0" or
            proof.get("database_side_effect_reconciliation", {}).get("active_clone_projection_leases") != "0"):
        raise RuntimeError("identity test DB side-effect reconciliation is incomplete")
    clean_dump = Path(proof.get("pretest_clean_dump_path", ""))
    verify_dump = Path(proof.get("post_verify_items_dump_path", ""))
    collection_dump = Path(proof.get("post_collection_dump_path", ""))
    dumps = (clean_dump, verify_dump, collection_dump)
    if (not all(path.is_file() for path in dumps) or
            len({hashlib.sha256(path.read_bytes()).hexdigest() for path in dumps}) != 1):
        raise RuntimeError("clone data does not match the reconciled clean baseline after both test phases")
    return {
        "run_id": proof.get("verify_items_run_id"),
        "source_sha256": expected_source,
        "selection": proof.get("identity_mapping_selection"),
        "verify_items_result_sha256": proof.get("verify_items_result_sha256"),
        "collection_result_sha256": proof.get("collection_result_sha256"),
        "clone_database": RETEST_TARGET,
        "original_provision_status_preserved": "UNKNOWN",
        "original_provision_state_sha256": hashlib.sha256(provision_path.read_bytes()).hexdigest(),
        "gate_proof_sha256": hashlib.sha256(proof_path.read_bytes()).hexdigest(),
        "reconciliation_state_sha256": hashlib.sha256(reconciliation_path.read_bytes()).hexdigest(),
    }


RETEST_PROOF = load_completed_retest_proof() if PHASE == 'full-campaign' else None

PROVISION_LOCK.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
lock_file = PROVISION_LOCK.open('a+b')
try:
    import fcntl
    fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
except ImportError as error:
    raise RuntimeError('fcntl locking is required on this provisioning host') from error
except BlockingIOError:
    raise SystemExit('global MySQL provision lock is held; reconcile before any operation')

started_monotonic = time.monotonic()
try:
    if BASE.exists():
        raise SystemExit('run directory already exists; reconcile without overwrite')
    BASE.mkdir(mode=0o700, parents=False)
    for child in ('backup', 'source', 'build', 'evidence'):
        (BASE / child).mkdir(mode=0o700)
except BaseException:
    lock_file.close()
    raise


def now():
    return datetime.now(timezone.utc).isoformat()


state = {
    'taskId': RUN_ID + ':clone-provision',
    'operationId': RUN_ID + ':clone-provision:' + PHASE + ':v1',
    'runId': RUN_ID,
    'responsible_agent': 'main ZCode agent',
    'delegated': False,
    'cwd': str(BASE),
    'started_at': now(),
    'status': 'PENDING',
    'phase': 'preflight',
    'retries': 0,
    'stream_disconnect': False,
    'no_migration': True,
    'no_original_database_write': True,
    'no_container_change': True,
    'timing': {'preflight_completed_monotonic': None, 'clone_creation_started_monotonic': None,
               'first_clone_postcondition_monotonic': None, 'source_reconciliation_monotonic': None},
    'sources': list(ACTIVE_SOURCES),
    'clones': [],
    'actions': [],
    'identity_retest_proof': RETEST_PROOF,
}
state_path = BASE / 'provision-state.json'


def save():
    temporary = state_path.with_suffix('.tmp')
    temporary.write_text(json.dumps(state, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    temporary.replace(state_path)


def credentials():
    password = os.environ.get('MYSQL_ROOT_PASSWORD')
    if not password or '\n' in password or '\r' in password:
        raise RuntimeError('protected MySQL credential is absent or malformed')
    return password


def run_command(argv, *, label, input_bytes=None, output_path=None, timeout=600):
    argv = list(argv)
    if argv and argv[0] in {'mysql', 'mysqldump'}:
        docker = ['docker', 'exec']
        if input_bytes is not None:
            docker.append('-i')
        docker += ['-e', 'MYSQL_PWD', MYSQL]
        argv = docker + argv
        child_env = os.environ.copy()
        child_env['MYSQL_PWD'] = credentials()
    else:
        child_env = None
    record = {
        'label': label,
        'started_at': now(),
        'argv_redacted': ['MYSQL_PWD=<inherited environment>' if value == 'MYSQL_PWD' else value for value in argv],
        'stdin_bytes': len(input_bytes) if input_bytes is not None else 0,
        'stdin_sha256': hashlib.sha256(input_bytes).hexdigest() if input_bytes is not None else None,
        'timeout_seconds': timeout,
    }
    if output_path is not None:
        with output_path.open('xb') as output:
            result = subprocess.run(argv, input=input_bytes, stdout=output, stderr=subprocess.PIPE,
                                    timeout=timeout, check=False, env=child_env)
        data = output_path.read_bytes()
        record.update(stdout_path=str(output_path), stdout_bytes=len(data),
                      stdout_sha256=hashlib.sha256(data).hexdigest())
        stdout = ''
    else:
        result = subprocess.run(argv, input=input_bytes, capture_output=True, timeout=timeout, check=False, env=child_env)
        stdout = result.stdout.decode('utf-8', errors='strict')
    stderr = result.stderr.decode('utf-8', errors='replace')
    record.update(exit_code=result.returncode, stderr=stderr, finished_at=now())
    state['actions'].append(record)
    save()
    if result.returncode != 0:
        raise RuntimeError(f'{label} failed, exit={result.returncode}: {stderr[:1200]}')
    return stdout


def query(sql, label):
    return run_command(mysql_argv(), label=label,
                       input_bytes=(sql.rstrip(';') + ';\n').encode(), timeout=120).strip()


def list_tables(database):
    return query("SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA='" + database +
                 "' AND TABLE_TYPE='BASE TABLE' ORDER BY TABLE_NAME", 'list base tables ' + database).splitlines()


def row_counts(database, tables):
    statements = []
    for table in tables:
        if not DATABASE_NAME.fullmatch(table):
            raise ValueError('invalid table identifier')
        statements.append("SELECT '" + table + "',COUNT(*) FROM `" + database + "`.`" + table + "`")
    output = query(';'.join(statements), 'count every row ' + database)
    observed = {}
    for line in output.splitlines():
        table, value = line.split('\t', 1)
        observed[table] = int(value)
    if list(observed) != tables:
        raise RuntimeError('row-count query did not cover tables in exact order: ' + database)
    return observed


def count_fingerprint(tables, counts):
    payload = [{'table': table, 'rows': counts[table]} for table in tables]
    return hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()


def dump_to_file(database, path, *, data_only=False, schema_only=False):
    run_command(mysql_argv(database, dump=True, data_only=data_only, schema_only=schema_only),
                label=('data-only dump ' if data_only else 'schema-only dump ' if schema_only else 'full database dump ') + database,
                output_path=path, timeout=900)
    return path.read_bytes()


def normalized_dump_hash(data, database):
    text = data.decode('utf-8', errors='strict')
    text = re.sub(r'(?m)^USE `[^`]+`;\s*$', 'USE `__DATABASE__`;', text)
    text = re.sub(r'(?m)^-- Current Database: `[^`]+`\s*$', '', text)
    return hashlib.sha256(text.encode()).hexdigest()


def normalized_schema_dump_hash(data, database):
    text = data.decode('utf-8', errors='strict')
    text = re.sub(r'(?m)^USE `[^`]+`;\s*$', 'USE `__DATABASE__`;', text)
    text = re.sub(r'(?m)^-- Current Database: `[^`]+`\s*$', '', text)
    text = re.sub(r' CHARACTER SET utf8mb4(?= COLLATE )', '', text)
    return hashlib.sha256(text.encode()).hexdigest()


def normalized_content_dump(data):
    return re.sub(rb'(?m)^USE `[^`]+`;(?=\r?$)', b'USE `__DATABASE__`;', data)


def expected_content_after_exception(source_path, backup_dir):
    source_bytes = Path(source_path).read_bytes()
    lines = source_bytes.splitlines(keepends=True)
    removed = {}
    for table in SPLIT_TABLES:
        backup = (Path(backup_dir) / (table + '.sql')).read_bytes()
        matches = list(re.finditer(rb'(?m)^INSERT INTO `([^`]+)`(?: \([^\r\n]*\))? VALUES .+;$', backup))
        if len(matches) != 1 or matches[0].group(1).decode('ascii') != table:
            raise RuntimeError('exact per-table backup does not contain one complete INSERT')
        statement = matches[0].group(0)
        indexes = [index for index, line in enumerate(lines) if line is not None and line.rstrip(b'\r\n') == statement]
        if len(indexes) != 1:
            raise RuntimeError('backed-up readiness row is not unique in the source content dump')
        removed[table] = hashlib.sha256(statement).hexdigest()
        lines[indexes[0]] = None
    expected = b''.join(line for line in lines if line is not None)
    return expected, removed


def status_enum_columns(database):
    rows = query(
        "SELECT TABLE_NAME,COLUMN_TYPE,CHARACTER_SET_NAME,COLLATION_NAME,IS_NULLABLE "
        "FROM information_schema.COLUMNS WHERE TABLE_SCHEMA='" + database + "' "
        "AND TABLE_NAME IN ('integration_identity_mapping','integration_identity_mapping_operation') "
        "AND COLUMN_NAME='status' ORDER BY TABLE_NAME",
        'verify exact identity mapping ENUM metadata ' + database).splitlines()
    if len(rows) != len(MAPPING_ENUM_CONTRACT) or any(len(row.split('\t')) != 5 for row in rows):
        raise RuntimeError('identity mapping status metadata rows have an unexpected shape')
    return rows


def exception_queries(database):
    t = SPLIT['tenant_id']
    card = SPLIT['card_id']
    aggregate = SPLIT['aggregate_id']
    manifest = SPLIT['manifest_id']
    segment = SPLIT['segment_id']
    return [
        "SELECT pointer_id,tenant_id,card_id,aggregate_type,aggregate_id,current_generation,manifest_id,event_id,operation_id,HEX(semantic_hash),HEX(dependency_hash),compiler_version,status,cas_version,last_error,created_at,updated_at,revoke_fence,revoke_fence_proven FROM `" + database + "`.authorization_projection_current WHERE pointer_id=" + str(SPLIT['pointer_id']) + " AND tenant_id=" + str(t) + " AND card_id=" + str(card) + " AND aggregate_type='USER_CARD' AND aggregate_id=" + str(aggregate),
        "SELECT reference_id,manifest_id,segment_id,tenant_id,card_id,aggregate_type,aggregate_id,generation,segment_ordinal,HEX(content_digest),event_id,operation_id,status,created_at FROM `" + database + "`.authorization_projection_manifest_segment WHERE tenant_id=" + str(t) + " AND card_id=" + str(card) + " AND aggregate_type='USER_CARD' AND aggregate_id=" + str(aggregate) + " AND manifest_id=" + str(manifest) + " AND segment_id=" + str(segment),
        "SELECT manifest_id,tenant_id,card_id,aggregate_type,aggregate_id,generation,source_generation,projected_generation,event_id,operation_id,HEX(semantic_hash),HEX(dependency_hash),compiler_version,HEX(manifest_digest),status,cas_version,lease_owner,HEX(lease_token_hash),lease_expires_at,last_error,created_at,updated_at,parent_manifest_id,revoke_fence FROM `" + database + "`.authorization_projection_manifest WHERE tenant_id=" + str(t) + " AND card_id=" + str(card) + " AND aggregate_type='USER_CARD' AND aggregate_id=" + str(aggregate) + " AND manifest_id=" + str(manifest),
        "SELECT segment_id,tenant_id,card_id,aggregate_type,aggregate_id,HEX(content_digest),HEX(semantic_hash),HEX(dependency_hash),compiler_version,segment_format,row_count,byte_size,HEX(SHA2(segment_payload,256)),status,cas_version,created_at,updated_at FROM `" + database + "`.authorization_projection_segment WHERE tenant_id=" + str(t) + " AND card_id=" + str(card) + " AND aggregate_type='USER_CARD' AND aggregate_id=" + str(aggregate) + " AND segment_id=" + str(segment),
    ]


def exact_exception_fields(rows):
    if len(rows) != len(SPLIT_TABLES) or any(not row or '\n' in row or '\r' in row for row in rows):
        raise RuntimeError('readiness exception does not contain exactly one row per allowlisted table')
    fields = [row.split('\t') for row in rows]
    expected = {
        'authorization_projection_current': {0: str(SPLIT['pointer_id']), 1: str(SPLIT['tenant_id']),
            2: str(SPLIT['card_id']), 3: 'USER_CARD', 4: str(SPLIT['aggregate_id']), 5: '2',
            6: str(SPLIT['manifest_id']), 7: SPLIT['event_id'], 8: SPLIT['operation_id'], 12: 'READY'},
        'authorization_projection_manifest_segment': {1: str(SPLIT['manifest_id']), 2: str(SPLIT['segment_id']),
            3: str(SPLIT['tenant_id']), 4: str(SPLIT['card_id']), 5: 'USER_CARD', 6: str(SPLIT['aggregate_id']),
            7: '1', 10: SPLIT['event_id'], 11: SPLIT['operation_id'], 12: 'READY'},
        'authorization_projection_manifest': {0: str(SPLIT['manifest_id']), 1: str(SPLIT['tenant_id']),
            2: str(SPLIT['card_id']), 3: 'USER_CARD', 4: str(SPLIT['aggregate_id']), 5: '1',
            6: '1', 7: '1', 8: SPLIT['event_id'], 9: SPLIT['operation_id'], 14: 'COMMITTED'},
        'authorization_projection_segment': {0: str(SPLIT['segment_id']), 1: str(SPLIT['tenant_id']),
            2: str(SPLIT['card_id']), 3: 'USER_CARD', 4: str(SPLIT['aggregate_id']), 13: 'READY'},
    }
    for table, values in zip(SPLIT_TABLES, fields):
        if any(values[index] != value for index, value in expected[table].items()):
            raise RuntimeError('readiness exception identity differs from the approved exact row')
    if not fields[1][0].isdigit():
        raise RuntimeError('readiness exception reference id is invalid')
    return fields


def backup_clone_exception(database, tables, approved_source_rows, source_counts, data_check):
    if any(table not in tables for table in SPLIT_TABLES):
        raise RuntimeError('readiness exception tables are missing')
    before = [query(sql, 'read exact inherited exception') for sql in exception_queries(database)]
    if before != approved_source_rows:
        raise RuntimeError('clone exception rows differ byte-for-byte from reviewed source rows')
    row_fields = exact_exception_fields(before)
    backup_dir = BASE / 'backup' / (database + '-readiness-exception')
    backup_dir.mkdir(mode=0o700)
    backup = BASE / 'backup' / (database + '-readiness-exception.sql')
    backup_where = {
        'authorization_projection_current': "pointer_id=" + str(SPLIT['pointer_id']) + ' AND tenant_id=' + str(SPLIT['tenant_id']) + ' AND card_id=' + str(SPLIT['card_id']) + " AND aggregate_type='USER_CARD' AND aggregate_id=" + str(SPLIT['aggregate_id']) + ' AND current_generation=2 AND manifest_id=' + str(SPLIT['manifest_id']) + " AND event_id='" + SPLIT['event_id'] + "' AND operation_id='" + SPLIT['operation_id'] + "'",
        'authorization_projection_manifest_segment': 'reference_id=' + row_fields[1][0] + ' AND manifest_id=' + str(SPLIT['manifest_id']) + ' AND segment_id=' + str(SPLIT['segment_id']) + ' AND tenant_id=' + str(SPLIT['tenant_id']) + ' AND card_id=' + str(SPLIT['card_id']) + " AND aggregate_type='USER_CARD' AND aggregate_id=" + str(SPLIT['aggregate_id']) + ' AND generation=1',
        'authorization_projection_manifest': 'manifest_id=' + str(SPLIT['manifest_id']) + ' AND tenant_id=' + str(SPLIT['tenant_id']) + ' AND card_id=' + str(SPLIT['card_id']) + " AND aggregate_type='USER_CARD' AND aggregate_id=" + str(SPLIT['aggregate_id']) + " AND generation=1 AND event_id='" + SPLIT['event_id'] + "' AND operation_id='" + SPLIT['operation_id'] + "' AND status='COMMITTED'",
        'authorization_projection_segment': 'segment_id=' + str(SPLIT['segment_id']) + ' AND tenant_id=' + str(SPLIT['tenant_id']) + ' AND card_id=' + str(SPLIT['card_id']) + " AND aggregate_type='USER_CARD' AND aggregate_id=" + str(SPLIT['aggregate_id']) + " AND status='READY'",
    }
    parts = []
    per_table = {}
    for table in SPLIT_TABLES:
        path = backup_dir / (table + '.sql')
        run_command(mysql_argv(database, dump=True, data_only=True, where=backup_where[table], tables=(table,)),
                    label='backup exact readiness row ' + database + '.' + table,
                    output_path=path, timeout=300)
        data = path.read_bytes()
        if not data or b'CREATE DATABASE' in data or re.search(rb'(?mi)^USE\s+', data):
            raise RuntimeError('readiness backup is empty or contains database-selection DDL')
        matches = re.findall(rb'(?m)^INSERT INTO `([^`]+)`(?: \([^\r\n]*\))? VALUES (.+);$', data)
        if len(matches) != 1 or matches[0][0].decode('ascii') != table or matches[0][1].count(b'),(') != 0:
            raise RuntimeError('readiness table backup must contain exactly one row in its allowlist table')
        parts.append(data)
        per_table[table] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    with backup.open('xb') as stream:
        stream.write(b''.join(parts))
    combined = backup.read_bytes()
    combined_matches = re.findall(rb'(?m)^INSERT INTO `([^`]+)`(?: \([^\r\n]*\))? VALUES (.+);$', combined)
    if ([name.decode('ascii') for name, _ in combined_matches] != list(SPLIT_TABLES) or
            hashlib.sha256(combined).hexdigest() != hashlib.sha256(b''.join(parts)).hexdigest()):
        raise RuntimeError('combined readiness backup has an invalid table set or hash')
    backup_hash = hashlib.sha256(combined).hexdigest()

    t = str(SPLIT['tenant_id'])
    card = str(SPLIT['card_id'])
    aggregate = str(SPLIT['aggregate_id'])
    manifest = str(SPLIT['manifest_id'])
    segment = str(SPLIT['segment_id'])
    event = SPLIT['event_id']
    operation = SPLIT['operation_id']
    reference = row_fields[1][0]
    statements = [
        'START TRANSACTION',
        'SET @readiness_pointer = NULL',
        'SELECT pointer_id INTO @readiness_pointer FROM `' + database + '`.authorization_projection_current WHERE pointer_id=' + str(SPLIT['pointer_id']) + ' AND tenant_id=' + t + ' AND card_id=' + card + " AND aggregate_type='USER_CARD' AND aggregate_id=" + aggregate + ' AND current_generation=2 AND manifest_id=' + manifest + " AND event_id='" + event + "' AND operation_id='" + operation + "' AND status='READY' FOR UPDATE",
        'SET @readiness_manifest = NULL',
        'SELECT manifest_id INTO @readiness_manifest FROM `' + database + '`.authorization_projection_manifest WHERE manifest_id=' + manifest + ' AND tenant_id=' + t + ' AND card_id=' + card + " AND aggregate_type='USER_CARD' AND aggregate_id=" + aggregate + " AND generation=1 AND event_id='" + event + "' AND operation_id='" + operation + "' AND status='COMMITTED' FOR UPDATE",
        'SET @readiness_reference = NULL',
        'SELECT reference_id INTO @readiness_reference FROM `' + database + '`.authorization_projection_manifest_segment WHERE reference_id=' + reference + ' AND manifest_id=' + manifest + ' AND segment_id=' + segment + ' AND tenant_id=' + t + ' AND card_id=' + card + " AND aggregate_type='USER_CARD' AND aggregate_id=" + aggregate + ' AND generation=1 AND event_id=' + "'" + event + "' AND operation_id='" + operation + "' AND status='READY' FOR UPDATE",
        'SET @readiness_segment = NULL',
        'SELECT segment_id INTO @readiness_segment FROM `' + database + '`.authorization_projection_segment WHERE segment_id=' + segment + ' AND tenant_id=' + t + ' AND card_id=' + card + " AND aggregate_type='USER_CARD' AND aggregate_id=" + aggregate + " AND status='READY' FOR UPDATE",
        'SELECT @readiness_pointer',
        'SELECT @readiness_manifest',
        'SELECT @readiness_reference',
        'SELECT @readiness_segment',
        'CREATE TEMPORARY TABLE readiness_cleanup_guard (ok TINYINT NOT NULL CHECK (ok = 1)) ENGINE=InnoDB',
        'INSERT INTO readiness_cleanup_guard VALUES (IF(@readiness_pointer=' + str(SPLIT['pointer_id']) + ' AND @readiness_manifest=' + manifest + ' AND @readiness_reference=' + reference + ' AND @readiness_segment=' + segment + ',1,0))',
        'SELECT pointer_id FROM `' + database + '`.authorization_projection_current WHERE pointer_id=' + str(SPLIT['pointer_id']) + ' AND tenant_id=' + t + ' AND card_id=' + card + " AND aggregate_type='USER_CARD' AND aggregate_id=" + aggregate,
        'DELETE FROM `' + database + '`.authorization_projection_current WHERE pointer_id=@readiness_pointer AND @readiness_pointer=' + str(SPLIT['pointer_id']),
        'SET @deleted_pointer = ROW_COUNT()',
        'INSERT INTO readiness_cleanup_guard VALUES (IF(@deleted_pointer=1,1,0))',
        'DELETE FROM `' + database + '`.authorization_projection_manifest_segment WHERE reference_id=@readiness_reference AND @readiness_reference=' + reference,
        'SET @deleted_reference = ROW_COUNT()',
        'INSERT INTO readiness_cleanup_guard VALUES (IF(@deleted_reference=1,1,0))',
        'DELETE FROM `' + database + '`.authorization_projection_manifest WHERE manifest_id=@readiness_manifest AND @readiness_manifest=' + manifest,
        'SET @deleted_manifest = ROW_COUNT()',
        'INSERT INTO readiness_cleanup_guard VALUES (IF(@deleted_manifest=1,1,0))',
        'DELETE FROM `' + database + '`.authorization_projection_segment WHERE segment_id=@readiness_segment AND @readiness_segment=' + segment,
        'SET @deleted_segment = ROW_COUNT()',
        'INSERT INTO readiness_cleanup_guard VALUES (IF(@deleted_segment=1,1,0))',
        'INSERT INTO readiness_cleanup_guard SELECT COUNT(*)=0 FROM `' + database + '`.authorization_projection_current WHERE pointer_id=' + str(SPLIT['pointer_id']) + ' AND tenant_id=' + t + ' AND card_id=' + card + " AND aggregate_type='USER_CARD' AND aggregate_id=" + aggregate,
        'INSERT INTO readiness_cleanup_guard SELECT COUNT(*)=0 FROM `' + database + '`.authorization_projection_manifest_segment WHERE reference_id=' + reference + ' AND tenant_id=' + t + ' AND card_id=' + card + " AND aggregate_type='USER_CARD' AND aggregate_id=" + aggregate,
        'INSERT INTO readiness_cleanup_guard SELECT COUNT(*)=0 FROM `' + database + '`.authorization_projection_manifest WHERE manifest_id=' + manifest + ' AND tenant_id=' + t + ' AND card_id=' + card + " AND aggregate_type='USER_CARD' AND aggregate_id=" + aggregate,
        'INSERT INTO readiness_cleanup_guard SELECT COUNT(*)=0 FROM `' + database + '`.authorization_projection_segment WHERE segment_id=' + segment + ' AND tenant_id=' + t + ' AND card_id=' + card + " AND aggregate_type='USER_CARD' AND aggregate_id=" + aggregate,
        'SELECT CONCAT(@deleted_pointer,CHAR(9),@deleted_reference,CHAR(9),@deleted_manifest,CHAR(9),@deleted_segment)',
        'SELECT COUNT(*) FROM `' + database + '`.authorization_projection_current WHERE pointer_id=' + str(SPLIT['pointer_id']) + ' AND tenant_id=' + t + ' AND card_id=' + card + " AND aggregate_type='USER_CARD' AND aggregate_id=" + aggregate,
        'SELECT COUNT(*) FROM `' + database + '`.authorization_projection_manifest_segment WHERE reference_id=' + reference + ' AND tenant_id=' + t + ' AND card_id=' + card + " AND aggregate_type='USER_CARD' AND aggregate_id=" + aggregate,
        'SELECT COUNT(*) FROM `' + database + '`.authorization_projection_manifest WHERE manifest_id=' + manifest + ' AND tenant_id=' + t + ' AND card_id=' + card + " AND aggregate_type='USER_CARD' AND aggregate_id=" + aggregate,
        'SELECT COUNT(*) FROM `' + database + '`.authorization_projection_segment WHERE segment_id=' + segment + ' AND tenant_id=' + t + ' AND card_id=' + card + " AND aggregate_type='USER_CARD' AND aggregate_id=" + aggregate,
        'DROP TEMPORARY TABLE readiness_cleanup_guard',
        'COMMIT',
    ]
    transaction_sql = '; '.join(statements) + ';'
    output = run_command(mysql_argv(database), label='remove exact backed-up readiness exception from clone ' + database,
                         input_bytes=(transaction_sql + '\n').encode(), timeout=120).splitlines()
    expected_output = [str(SPLIT['pointer_id']), manifest, reference, segment,
                       str(SPLIT['pointer_id']), '1\t1\t1\t1', '0', '0', '0', '0']
    if output != expected_output:
        raise RuntimeError('readiness cleanup lock/CAS/delete/postcondition result was not exact')
    post_counts = row_counts(database, tables)
    expected_counts = dict(source_counts)
    for table in SPLIT_TABLES:
        expected_counts[table] -= 1
    if post_counts != expected_counts:
        raise RuntimeError('clone cleanup changed rows outside the four approved readiness records')
    expected_content, removed_statement_hashes = expected_content_after_exception(
        data_check, backup_dir)
    after_data_path = BASE / 'backup' / (database + '-content-after-exception.sql')
    after_data = dump_to_file(database, after_data_path, data_only=True)
    if normalized_content_dump(after_data) != normalized_content_dump(expected_content):
        raise RuntimeError('clone data dump differs beyond the four exact backed-up readiness rows')
    return {
        'before_row_sha256': {table: hashlib.sha256(row.encode()).hexdigest() for table, row in zip(SPLIT_TABLES, before)},
        'removed_insert_sha256': removed_statement_hashes,
        'backup_path': str(backup), 'backup_bytes': len(combined), 'backup_sha256': backup_hash,
        'after_content_sha256': hashlib.sha256(after_data).hexdigest(),
        'per_table_backup_hashes': per_table, 'after_row_counts': dict.fromkeys(SPLIT_TABLES, 0),
        'post_cleanup_row_counts_sha256': count_fingerprint(tables, post_counts),
        'status': 'PASS',
    }


def provision_clone(source, target, purpose, full_dump, source_info, approved_exception_rows):
    target_pattern = ORDINARY_CLONE_NAME if source == ORDINARY_SOURCE else DEDICATED_CLONE_NAME
    source_database_names = {ORDINARY_SOURCE, MAPPING_SOURCE, 'astral_rehearsal', 'astral_test',
                             'sdk_identity_mapping_test_gate20261007'}
    if (source not in ACTIVE_SOURCES or not target_pattern.fullmatch(target) or target in source_database_names):
        raise ValueError('invalid or non-isolated clone target')
    if not DATABASE_NAME.fullmatch(source_info['charset']) or not DATABASE_NAME.fullmatch(source_info['collation']):
        raise ValueError('invalid source schema character-set metadata')
    exists = query("SELECT COUNT(*) FROM information_schema.SCHEMATA WHERE SCHEMA_NAME='" + target + "'",
                   'CAS-check clone target absence ' + target).strip()
    if exists != '0':
        raise RuntimeError('refusing to create or overwrite an existing clone ' + target)
    body, substitutions = re.subn(rb'(?m)^USE `' + source.encode() + rb'`;\r?$',
                                  b'USE `' + target.encode() + b'`;', full_dump)
    if substitutions != 1 or re.search(rb'(?mi)^\s*(CREATE|DROP)\s+(DATABASE|SCHEMA)\b', body):
        raise RuntimeError('source backup has unsafe database DDL or non-unique schema selector')
    if re.search(rb'(?mi)^\s*USE\s+', body.replace(b'USE `' + target.encode() + b'`;', b'')):
        raise RuntimeError('source backup contains an additional schema selector')
    query(f'CREATE DATABASE `{target}` CHARACTER SET {source_info["charset"]} COLLATE {source_info["collation"]}',
          'create exact run-owned clone ' + target)
    restore_body = b'SET FOREIGN_KEY_CHECKS=0;' + bytes([10]) + body + bytes([10]) + b'SET FOREIGN_KEY_CHECKS=1;' + bytes([10])
    run_command(mysql_argv(target), label='restore run-owned clone ' + target, input_bytes=restore_body, timeout=900)

    tables = list_tables(target)
    if tables != source_info['tables']:
        raise RuntimeError('clone base-table inventory differs from the exact source inventory')
    restored_counts = row_counts(target, tables)
    if restored_counts != source_info['counts'] or count_fingerprint(tables, restored_counts) != source_info['row_counts_sha256']:
        raise RuntimeError('clone row-count baseline differs from the source snapshot')
    if status_enum_columns(target) != source_info['enum_columns']:
        raise RuntimeError('clone identity mapping schema contract differs from source')
    full_check = BASE / 'backup' / (target + '-full-verify.sql')
    clone_full = dump_to_file(target, full_check)
    if normalized_schema_dump_hash(clone_full, target) != normalized_schema_dump_hash(full_dump, source):
        raise RuntimeError('clone schema/data SQL dump hash differs from source')
    data_check = BASE / 'backup' / (target + '-data-verify.sql')
    clone_data = dump_to_file(target, data_check, data_only=True)
    if normalized_dump_hash(clone_data, target) != source_info['content_hash']:
        raise RuntimeError('clone row-content hash differs from source')
    schema_check = BASE / 'backup' / (target + '-schema-verify.sql')
    clone_schema = dump_to_file(target, schema_check, schema_only=True)
    if normalized_schema_dump_hash(clone_schema, target) != normalized_schema_dump_hash(source_info['schema_dump'], source):
        raise RuntimeError('clone schema dump differs from the exact source DDL')
    ledger = query('SELECT MAX(version),COUNT(*),SUM(success) FROM `' + target + '`.`_sqlx_migrations`',
                   'verify no migration after clone restore ' + target).strip()
    if ledger != source_info['migration']:
        raise RuntimeError('clone migration ledger differs from source baseline')
    active_leases = query('SELECT COUNT(*) FROM `' + target + '`.authorization_projection_manifest WHERE lease_owner IS NOT NULL AND lease_expires_at>UTC_TIMESTAMP(6)',
                          'verify no active manifest lease ' + target).strip()
    if active_leases != '0':
        raise RuntimeError('fresh clone contains an active projection lease')

    exception = None
    if source == ORDINARY_SOURCE:
        exception = backup_clone_exception(target, tables, approved_exception_rows, source_info['counts'], data_check)
    final_counts = row_counts(target, tables)
    migration_after = query('SELECT MAX(version),COUNT(*),SUM(success) FROM `' + target + '`.`_sqlx_migrations`',
                            'verify final clone migration ledger ' + target).strip()
    if migration_after != source_info['migration']:
        raise RuntimeError('clone migration state changed during exact exception cleanup')
    expected_final_counts = dict(source_info['counts'])
    if source == ORDINARY_SOURCE:
        for table in SPLIT_TABLES:
            expected_final_counts[table] -= 1
    if final_counts != expected_final_counts:
        raise RuntimeError('clone post-cleanup counts differ outside the exact approved cleanup rows')
    if source == ORDINARY_SOURCE:
        state['timing']['first_clone_postcondition_monotonic'] = round(time.monotonic() - started_monotonic, 3)
    save()
    state['clones'].append({
        'source': source, 'target': target, 'purpose': purpose, 'tables': len(tables),
        'row_counts_sha256_before_cleanup': count_fingerprint(tables, restored_counts),
        'row_counts_sha256_after_cleanup': count_fingerprint(tables, final_counts),
        'row_counts_after_cleanup': final_counts,
        'source_content_sha256_before_cleanup': source_info['content_hash'],
        'clone_content_sha256_before_cleanup': hashlib.sha256(clone_data).hexdigest(),
        'clone_content_sha256_after_cleanup': exception['after_content_sha256'] if exception else hashlib.sha256(clone_data).hexdigest(),
        'source_full_dump_sha256': hashlib.sha256(full_dump).hexdigest(),
        'clone_full_dump_sha256': hashlib.sha256(clone_full).hexdigest(),
        'source_schema_sha256': source_info['schema_sha256'],
        'clone_schema_sha256': hashlib.sha256(clone_schema).hexdigest(),
        'migration_summary': ledger,
        'identity_mapping_status_columns': source_info['enum_columns'],
        'historical_readiness_exception': exception,
        'active_manifest_leases_after_cleanup': '0',
        'no_migration_dispatched': True,
        'status': 'PASS',
    })
    save()


def preflight_source(database):
    tables = list_tables(database)
    if len(tables) != 153:
        raise RuntimeError(f'{database}: expected 153 base tables; found {len(tables)}')
    counts = row_counts(database, tables)
    fingerprint = count_fingerprint(tables, counts)
    if fingerprint != EXPECTED_ROW_COUNT_HASHES[database]:
        raise RuntimeError(f'{database}: original row-count fingerprint changed')
    migration = query('SELECT MAX(version),COUNT(*),SUM(success) FROM `' + database + '`.`_sqlx_migrations`',
                      'verify pre-migrated source ' + database).strip()
    if migration != '20261005000001\t62\t62':
        raise RuntimeError(f'{database}: source migration ledger differs from reviewed baseline')
    defaults = query("SELECT DEFAULT_CHARACTER_SET_NAME,DEFAULT_COLLATION_NAME FROM information_schema.SCHEMATA WHERE SCHEMA_NAME='" + database + "'",
                     'read source schema default ' + database).strip().split('\t')
    if len(defaults) != 2 or not all(DATABASE_NAME.fullmatch(value) for value in defaults):
        raise RuntimeError('unexpected source schema character set/collation')
    unsupported = {}
    for object_name, metadata_table, schema_column in (
        ('triggers', 'TRIGGERS', 'TRIGGER_SCHEMA'),
        ('routines', 'ROUTINES', 'ROUTINE_SCHEMA'),
        ('events', 'EVENTS', 'EVENT_SCHEMA'),
    ):
        unsupported[object_name] = int(query('SELECT COUNT(*) FROM information_schema.' + metadata_table +
            " WHERE " + schema_column + "='" + database + "'", 'verify source ' + object_name + ' ' + database).strip())
    if any(unsupported.values()):
        raise RuntimeError('source contains a trigger, routine or event outside the backup protocol')
    enum_columns = status_enum_columns(database)
    if enum_columns != MAPPING_ENUM_CONTRACT:
        raise RuntimeError('source identity mapping exact ENUM schema contract differs')
    full_path = BASE / 'backup' / (database + '-source.sql')
    full_dump = dump_to_file(database, full_path)
    expected_use = b'USE `' + database.encode() + b'`;'
    use_count = len(re.findall(rb'(?m)^USE `' + database.encode() + rb'`;\r?$', full_dump))
    if (use_count != 1 or re.search(rb'(?mi)^\s*(CREATE|DROP)\s+(DATABASE|SCHEMA)\b', full_dump) or
            re.search(rb'(?mi)^\s*USE\s+', full_dump.replace(expected_use, b''))):
        raise RuntimeError('source dump has ambiguous schema selection or database-level DDL')
    data_path = BASE / 'backup' / (database + '-content.sql')
    content_dump = dump_to_file(database, data_path, data_only=True)
    schema_path = BASE / 'backup' / (database + '-schema.sql')
    schema_dump = dump_to_file(database, schema_path, schema_only=True)
    exception_rows = None
    if database == ORDINARY_SOURCE:
        exception_rows = [query(sql, 'snapshot approved source readiness row') for sql in exception_queries(database)]
        exact_exception_fields(exception_rows)
        pointer = query(
            "SELECT pointer_id,tenant_id,card_id,aggregate_type,aggregate_id,current_generation,manifest_id,event_id,operation_id,status "
            "FROM `" + database + "`.authorization_projection_current WHERE tenant_id=" + str(SPLIT['tenant_id']) +
            " AND card_id=" + str(SPLIT['card_id']) + " AND aggregate_type='USER_CARD' AND aggregate_id=" + str(SPLIT['aggregate_id']),
            'prove exact inherited split pointer identity in source').split('\t')
        expected_pointer = [str(SPLIT['pointer_id']), str(SPLIT['tenant_id']), str(SPLIT['card_id']), 'USER_CARD',
            str(SPLIT['aggregate_id']), '2', str(SPLIT['manifest_id']), SPLIT['event_id'], SPLIT['operation_id'], 'READY']
        if pointer != expected_pointer:
            raise RuntimeError('source has an unexpected projection pointer for the reviewed exception')
        archive_rows = query(
            "SELECT 'outbox',COUNT(*) FROM `" + database + "`.authorization_archive_outbox WHERE tenant_id=" + str(SPLIT['tenant_id']) +
            " AND card_id=" + str(SPLIT['card_id']) + " AND aggregate_type='USER_CARD' AND aggregate_id=" + str(SPLIT['aggregate_id']) +
            " AND manifest_id=" + str(SPLIT['manifest_id']) + " AND event_id='" + SPLIT['event_id'] + "' AND operation_id='" + SPLIT['operation_id'] +
            "' UNION ALL SELECT 'archive_manifest',COUNT(*) FROM `" + database + "`.authorization_archive_manifest WHERE tenant_id=" + str(SPLIT['tenant_id']) +
            " AND card_id=" + str(SPLIT['card_id']) + " AND aggregate_type='USER_CARD' AND aggregate_id=" + str(SPLIT['aggregate_id']) +
            " AND manifest_id=" + str(SPLIT['manifest_id']) + " AND event_id='" + SPLIT['event_id'] + "' AND operation_id='" + SPLIT['operation_id'] + "'",
            'verify exact archive sidecar counts for inherited readiness exception').splitlines()
        archive_counts = {name: int(count) for name, count in (row.split('\t') for row in archive_rows)}
        if set(archive_counts) != {'outbox', 'archive_manifest'} or any(archive_counts.values()):
            raise RuntimeError('historical readiness exception has archive sidecars outside the approved four-row cleanup')
    return {
        'database': database, 'tables': tables, 'counts': counts, 'row_counts_sha256': fingerprint,
        'migration': migration, 'charset': defaults[0], 'collation': defaults[1],
        'unsupported_objects': unsupported, 'enum_columns': enum_columns,
        'full_path': str(full_path), 'full_dump': full_dump,
        'content_hash': normalized_dump_hash(content_dump, database),
        'schema_sha256': hashlib.sha256(schema_dump).hexdigest(),
        'schema_dump': schema_dump, 'exception_rows': exception_rows,
    }


try:
    state['phase'] = 'preflight'
    save()
    credentials()
    container = run_command(['docker', 'inspect', '--format',
        '{{.Id}} {{.Config.Image}} {{.State.StartedAt}} {{.State.Health.Status}}', MYSQL],
        label='verify existing MySQL container identity', timeout=60).strip().split()
    if len(container) != 4 or container[3] != 'healthy':
        raise RuntimeError('MySQL container health/identity differs from reviewed preflight')
    state['mysql_container'] = {'id': container[0], 'image': container[1],
                                'started_at': container[2], 'health': container[3]}
    sources = {database: preflight_source(database) for database in ACTIVE_SOURCES}
    target_names = [target for _, target, _ in CLONES]
    if len(set(target_names)) != len(target_names):
        raise RuntimeError('duplicate clone targets in selected provision phase')
    for _, target, _ in CLONES:
        if query("SELECT COUNT(*) FROM information_schema.SCHEMATA WHERE SCHEMA_NAME='" + target + "'",
                 'CAS-check target absence ' + target).strip() != '0':
            raise RuntimeError('run-scoped clone target already exists; refusing overwrite: ' + target)
    if PHASE == 'identity-retest':
        for _, target, _ in PHASES['full-campaign'][2]:
            if query("SELECT COUNT(*) FROM information_schema.SCHEMATA WHERE SCHEMA_NAME='" + target + "'",
                     'prove deferred full-run target absent ' + target).strip() != '0':
                raise RuntimeError('full-run clone exists before the single-suite gate: ' + target)
    elif not RETEST_PROOF:
        raise RuntimeError('full-run phase lacks the exact item, collection and database proof gate')
    state['source_baselines'] = {
        database: {
            'tables': len(info['tables']), 'row_counts_sha256': info['row_counts_sha256'],
            'migration': info['migration'], 'charset': info['charset'], 'collation': info['collation'],
            'unsupported_objects': info['unsupported_objects'], 'enum_columns': info['enum_columns'],
            'content_sha256': info['content_hash'], 'schema_sha256': info['schema_sha256'],
        }
        for database, info in sources.items()
    }
    state['targets_absent_before_first_create'] = True
    state['timing']['preflight_completed_monotonic'] = round(time.monotonic() - started_monotonic, 3)
    state['timing']['clone_creation_started_monotonic'] = state['timing']['preflight_completed_monotonic']
    save()
    for source, target, purpose in CLONES:
        state['phase'] = 'clone:' + target
        save()
        provision_clone(source, target, purpose, sources[source]['full_dump'], sources[source],
                        sources[source]['exception_rows'])
    for database, info in sources.items():
        if list_tables(database) != info['tables'] or row_counts(database, info['tables']) != info['counts']:
            raise RuntimeError('source table inventory/row counts changed during clone preparation')
        final_data_path = BASE / 'backup' / (database + '-content-final.sql')
        final_data_dump = dump_to_file(database, final_data_path, data_only=True)
        if normalized_dump_hash(final_data_dump, database) != info['content_hash']:
            raise RuntimeError('source row content changed during clone preparation')
        if database == ORDINARY_SOURCE:
            state['timing']['source_reconciliation_monotonic'] = round(time.monotonic() - started_monotonic, 3)
            save()
            final_exception = [query(sql, 'final source readiness exception reconciliation')
                              for sql in exception_queries(database)]
            if final_exception != info['exception_rows']:
                raise RuntimeError('original source exception changed during clone preparation')
            final_archive_rows = query(
                "SELECT 'outbox',COUNT(*) FROM `" + database + "`.authorization_archive_outbox WHERE tenant_id=" + str(SPLIT['tenant_id']) +
                " AND card_id=" + str(SPLIT['card_id']) + " AND aggregate_type='USER_CARD' AND aggregate_id=" + str(SPLIT['aggregate_id']) +
                " AND manifest_id=" + str(SPLIT['manifest_id']) + " AND event_id='" + SPLIT['event_id'] + "' AND operation_id='" + SPLIT['operation_id'] +
                "' UNION ALL SELECT 'archive_manifest',COUNT(*) FROM `" + database + "`.authorization_archive_manifest WHERE tenant_id=" + str(SPLIT['tenant_id']) +
                " AND card_id=" + str(SPLIT['card_id']) + " AND aggregate_type='USER_CARD' AND aggregate_id=" + str(SPLIT['aggregate_id']) +
                " AND manifest_id=" + str(SPLIT['manifest_id']) + " AND event_id='" + SPLIT['event_id'] + "' AND operation_id='" + SPLIT['operation_id'] + "'",
                'reconcile original source archive sidecars final state').splitlines()
            if set(final_archive_rows) != {"archive_manifest\t0", "outbox\t0"}:
                raise RuntimeError('original source archive sidecar state changed during clone preparation')

    state['original_sources_unchanged'] = True
    state['phase'] = 'clones-ready'
    state['status'] = 'PASS'
except BaseException as error:
    state['status'] = 'UNKNOWN' if isinstance(error, (OSError, subprocess.TimeoutExpired)) else 'FAIL'
    state['error'] = f'{type(error).__name__}: {error}'
    raise
finally:
    state['finished_at'] = now()
    state['elapsed_seconds'] = round(time.monotonic() - started_monotonic, 3)
    state['log_integrity'] = 'complete'
    save()
    lock_file.close()

print(json.dumps({key: state[key] for key in ('status', 'phase', 'source_baselines', 'clones',
                                             'original_sources_unchanged', 'identity_retest_proof',
                                             'elapsed_seconds')}, indent=2, ensure_ascii=False))
