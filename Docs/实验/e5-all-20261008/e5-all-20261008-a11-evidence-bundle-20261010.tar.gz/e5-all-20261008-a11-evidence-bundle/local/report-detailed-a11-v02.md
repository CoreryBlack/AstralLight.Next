# E5 全量战役逐项详细数据 — run e5-all-20261008-a11-v02

- 状态: PASS | verify_items: true | 源冻结: 82336d6b6c3750cb59ae6253ef0a68792df952ee8d35454dfd710a24c4c777e4
- 启动: 2026-10-09T09:25:55.924119+00:00 | 完成: 2026-10-09T12:08:49.405375+00:00 | 总耗时: 9773.477s
- cwd: /home/astrallight/astral-test-runs/e5-all-20261008-a10-evidence/source-a10-v03/tree
- provisioning: none; pre-migrated approved dependencies only
- preflight: {"status": "PASS", "issues": []}
- 全部 120 条记录: retries=0, stream_disconnect=false, log_integrity=complete

## 逐项 items（60 项）

### 1. campaign-contracts
- taskId: `e5-all-20261008-a11-v02:items:campaign-contracts`
- profile: native-kernel | scope: component | owner: scripts | series: CORE, M4, E4
- production_services: [] | test_services: []
- boundary: runner/manifest assertions and stub subprocesses only; no DB, Docker or live fault
- argv: `python -B -m unittest discover -s scripts/tests -p test_*.py`
- started: 2026-10-09T09:25:56.060677+00:00 | finished: 2026-10-09T09:25:59.968444+00:00 | elapsed: 3.764s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: unittest
- actual_postcondition / reason: offline Python assertions executed
- tests: {"executed": 78}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/campaign-contracts.stdout.log` (sha256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/campaign-contracts.stderr.log` (sha256 57ddaf35ee4d440672d4b6545bb38cf2ac1bde7bd22be8698e47521b3c67b2e7)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 2. shell-runner-contracts
- taskId: `e5-all-20261008-a11-v02:items:shell-runner-contracts`
- profile: native-kernel | scope: component | owner: scripts | series: CORE, E4
- production_services: [] | test_services: []
- boundary: mock Cargo/Docker orchestration only; no integration proof
- argv: `bash scripts/tests/test-run-tests.sh`
- started: 2026-10-09T09:26:00.099046+00:00 | finished: 2026-10-09T09:26:00.627992+00:00 | elapsed: 0.403s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: command
- actual_postcondition / reason: scoped command completed; see its component proof boundary
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/shell-runner-contracts.stdout.log` (sha256 d3bd757c22a48729f4092e2da42c8c8e7c7b0cc1d2a7b0bd2e2a904a692602ce)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/shell-runner-contracts.stderr.log` (sha256 f7984587660d832b9fef9e08b5c41c6f6ed674bb151622f963d5a43af9af53db)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 3. workspace-check
- taskId: `e5-all-20261008-a11-v02:items:workspace-check`
- profile: native-kernel | scope: component | owner: workspace | series: CORE
- production_services: [] | test_services: []
- boundary: current workspace members compile; excluded crates separate
- argv: `cargo check --workspace --locked`
- started: 2026-10-09T09:26:00.762514+00:00 | finished: 2026-10-09T09:26:01.595516+00:00 | elapsed: 0.704s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: command
- actual_postcondition / reason: scoped command completed; see its component proof boundary
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/workspace-check.stdout.log` (sha256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/workspace-check.stderr.log` (sha256 80a72ab0b6d57f57833fbff08eb4f1c216d4bb98fd0953be701bdd8ef1a25c8e)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 4. workspace-clippy
- taskId: `e5-all-20261008-a11-v02:items:workspace-clippy`
- profile: native-kernel | scope: component | owner: workspace | series: CORE
- production_services: [] | test_services: []
- boundary: required workspace lint; compiler-specific failures are not suppressed
- argv: `cargo clippy --workspace --locked -- -D warnings`
- started: 2026-10-09T09:26:01.724025+00:00 | finished: 2026-10-09T09:26:02.604403+00:00 | elapsed: 0.754s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: command
- actual_postcondition / reason: scoped command completed; see its component proof boundary
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/workspace-clippy.stdout.log` (sha256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/workspace-clippy.stderr.log` (sha256 7ea9ff7442106040f95bc079f85de985b086e1fed897d88dec87dd8425c35ee1)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 5. workspace-fmt
- taskId: `e5-all-20261008-a11-v02:items:workspace-fmt`
- profile: native-kernel | scope: component | owner: workspace | series: CORE
- production_services: [] | test_services: []
- boundary: read-only formatting assertion
- argv: `cargo fmt --all -- --check`
- started: 2026-10-09T09:26:02.733438+00:00 | finished: 2026-10-09T09:26:07.074607+00:00 | elapsed: 4.214s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: command
- actual_postcondition / reason: scoped command completed; see its component proof boundary
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/workspace-fmt.stdout.log` (sha256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/workspace-fmt.stderr.log` (sha256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 6. workspace-tests
- taskId: `e5-all-20261008-a11-v02:items:workspace-tests`
- profile: native-kernel | scope: component | owner: workspace | series: CORE
- production_services: [] | test_services: []
- boundary: workspace non-ignored tests; ignored/SKIP counted separately, never real integration PASS
- argv: `cargo test --workspace --locked`
- started: 2026-10-09T09:26:07.203561+00:00 | finished: 2026-10-09T09:29:22.083149+00:00 | elapsed: 194.751s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped non-ignored Rust assertions executed; ignored checks remain outside selection
- tests: {"passed": 2778, "failed": 0, "ignored": 97, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/workspace-tests.stdout.log` (sha256 801bb65be908447361613312eb4364152f44c8c4d6e4258f8161d53980d3aa23)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/workspace-tests.stderr.log` (sha256 7edf60898c87d07f8cc043b55504a22772f592d3a83e943e87dde9d1f58ce569)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 7. native-dependency-tree
- taskId: `e5-all-20261008-a11-v02:items:native-dependency-tree`
- profile: native-kernel | scope: component | owner: astral-single-node | series: CORE, E4, M4
- production_services: [] | test_services: []
- boundary: default compiled dependency tree has no Redis; not an actual deployed-config inspection
- argv: `cargo tree -p astral-single-node --locked --prefix none`
- started: 2026-10-09T09:29:22.211954+00:00 | finished: 2026-10-09T09:29:22.844580+00:00 | elapsed: 0.505s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: dependency-tree
- actual_postcondition / reason: scoped command completed; see its component proof boundary
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/native-dependency-tree.stdout.log` (sha256 62f5d372f238c4b7cdc8404ca10a00885dc75cbc1b88078043514d0a30dc40f9)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/native-dependency-tree.stderr.log` (sha256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 8. strict-tenant-isolation
- taskId: `e5-all-20261008-a11-v02:items:strict-tenant-isolation`
- profile: native-kernel | scope: component | owner: policy-engine | series: M3, M5, MT-E1, RQ2
- production_services: [] | test_services: []
- boundary: strict published-evidence injected fixture; final reload/scope/legacy-port assertions, no durable DB
- argv: `cargo test -p policy-engine --test tenant_isolation_tests --locked -- --nocapture`
- started: 2026-10-09T09:29:22.975354+00:00 | finished: 2026-10-09T09:29:23.507247+00:00 | elapsed: 0.403s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 16, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/strict-tenant-isolation.stdout.log` (sha256 6e1ddb76f563a95ca1c77a8af80297d7c54d8661ba536601903bf6e35b035684)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/strict-tenant-isolation.stderr.log` (sha256 99cd997c909853aff25788245b5e26a999117101aef679f9caab3139c0f2f704)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 9. gateway-contracts
- taskId: `e5-all-20261008-a11-v02:items:gateway-contracts`
- profile: native-kernel | scope: component | owner: astral-common | series: E1, M5
- production_services: [] | test_services: []
- boundary: signed gateway middleware fixture; not deployed host full mediation
- argv: `cargo test -p astral-common --test gateway_contract_tests --locked`
- started: 2026-10-09T09:29:23.635118+00:00 | finished: 2026-10-09T09:29:24.265981+00:00 | elapsed: 0.504s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 7, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/gateway-contracts.stdout.log` (sha256 5c86d00d0c1f703d86985a313085055cc9aa8e6ea1dc5ed4544482122227426c)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/gateway-contracts.stderr.log` (sha256 c50e97bb8e7db79c45ff05bb2c5d3274017cf90bc6aff771b0426cfe8da42595)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 10. redis-free-config
- taskId: `e5-all-20261008-a11-v02:items:redis-free-config`
- profile: native-kernel | scope: component | owner: testsuite | series: E4, M4
- production_services: [] | test_services: []
- boundary: AppConfig adapter capability assertion; not private composite startup validation
- argv: `cargo test -p testsuite --test premise_redis_free_composite --locked`
- started: 2026-10-09T09:29:24.399039+00:00 | finished: 2026-10-09T09:29:25.132202+00:00 | elapsed: 0.604s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 2, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/redis-free-config.stdout.log` (sha256 1985e32c0b087c954ee754715d9bd954f32ab2028904992e8818e0d4c45635e4)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/redis-free-config.stderr.log` (sha256 d2ebe66ef2b6aa8c5c2a70f611ec364f122414a26a6b678fad48438b8f2bd774)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 11. strict-policy-targets-check
- taskId: `e5-all-20261008-a11-v02:items:strict-policy-targets-check`
- profile: native-kernel | scope: component | owner: policy-engine | series: CORE, PERF
- production_services: [] | test_services: []
- boundary: test and benchmark type checking; no measured performance data
- argv: `cargo check -p policy-engine --tests --benches --locked`
- started: 2026-10-09T09:29:25.261351+00:00 | finished: 2026-10-09T09:29:25.793824+00:00 | elapsed: 0.403s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: command
- actual_postcondition / reason: scoped command completed; see its component proof boundary
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/strict-policy-targets-check.stdout.log` (sha256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/strict-policy-targets-check.stderr.log` (sha256 eb9cc26f98066772d2ee0959e521d10008cc691a65f688ec4f06c6d62d3d596f)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 12. native-lifecycle-build
- taskId: `e5-all-20261008-a11-v02:items:native-lifecycle-build`
- profile: native-kernel | scope: component | owner: testsuite | series: CORE, M1, M2, M3
- production_services: [] | test_services: []
- boundary: compile the ignored MySQL lifecycle target only; no real integration run
- argv: `cargo check -p testsuite --test native_projection_lifecycle --locked`
- started: 2026-10-09T09:29:25.924549+00:00 | finished: 2026-10-09T09:29:26.657256+00:00 | elapsed: 0.604s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: command
- actual_postcondition / reason: scoped command completed; see its component proof boundary
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/native-lifecycle-build.stdout.log` (sha256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/native-lifecycle-build.stderr.log` (sha256 ec3275bd7cdb61fe7edc4fadcb9a7a8d1c03aef38d75c8a6d05652c57a1d448e)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 13. native-lifecycle-cleanup-contract
- taskId: `e5-all-20261008-a11-v02:items:native-lifecycle-cleanup-contract`
- profile: native-kernel | scope: component | owner: testsuite | series: CORE, E3, E4
- production_services: [] | test_services: []
- boundary: cleanup admission only; failure/timeout retains fixtures; no database integration
- argv: `cargo test -p testsuite --test native_projection_lifecycle cleanup_requires_successful_lifecycle_and_joined_owners --locked -- --exact --nocapture`
- started: 2026-10-09T09:29:26.786792+00:00 | finished: 2026-10-09T09:29:27.519562+00:00 | elapsed: 0.604s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 2}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/native-lifecycle-cleanup-contract.stdout.log` (sha256 11568bbe5959ce3cd4aa61940b50a6ec21368bbeed25d284d2099cf6e193746a)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/native-lifecycle-cleanup-contract.stderr.log` (sha256 cf3926c21142fed82e950d0301d6ab2d8b6db8d72205a40fbbd8f5d6d2e1c64a)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 14. native-lifecycle-drain-contract
- taskId: `e5-all-20261008-a11-v02:items:native-lifecycle-drain-contract`
- profile: native-kernel | scope: component | owner: testsuite | series: CORE, E3, E4
- production_services: [] | test_services: []
- boundary: bus occupancy wait requires empty count and byte budgets; no worker completion or database integration proof
- argv: `cargo test -p testsuite --test native_projection_lifecycle projection_bus_drain_wait_requires_empty_occupancy --locked -- --exact --nocapture`
- started: 2026-10-09T09:29:27.649489+00:00 | finished: 2026-10-09T09:29:28.479727+00:00 | elapsed: 0.704s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 2}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/native-lifecycle-drain-contract.stdout.log` (sha256 2f0385526f41330e4fcd9ac947ac95c488b50b8e358e96d16237122760ee0907)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/native-lifecycle-drain-contract.stderr.log` (sha256 0bc86b242cceeda3979a3cd6bfa5fc4bbe6d4221426f62703c127da6012983ec)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 15. strict-benchmark-smoke
- taskId: `e5-all-20261008-a11-v02:items:strict-benchmark-smoke`
- profile: native-kernel | scope: component | owner: policy-engine | series: CORE, PERF
- production_services: [] | test_services: []
- boundary: Criterion test mode verifies fixture decisions and setup only; no statistical timing
- argv: `cargo test -p policy-engine --bench policy_bench --bench tenant_isolation_bench --locked -- --test`
- started: 2026-10-09T09:29:28.606123+00:00 | finished: 2026-10-09T09:29:29.390548+00:00 | elapsed: 0.655s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: criterion-smoke
- actual_postcondition / reason: complete benchmark fixture smoke
- performance: fixture smoke only, cases 17
  - engine/published_ready_allow
  - engine/published_ready_empty_deny
  - engine/published_unavailable_pending
  - engine/published_ready_nonmatching_set
  - engine/published_tenant_gradient_32
  - condition/component_time_range
  - condition/component_ipv4_range
  - condition/component_scope
  - tenant_isolation/published_single_tenant_10_rules
  - tenant_isolation/published_concurrent_10_tenants
  - tenant_isolation/published_concurrent_50_tenants
  - tenant_isolation/published_concurrent_100_tenants
  - tenant_isolation/data_scope_resolve
  - tenant_isolation/data_scope_resolve_personal
  - tenant_isolation/published_cross_tenant_100x50
  - tenant_isolation/published_empty_deny
  - tenant_isolation/published_unavailable_pending
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/strict-benchmark-smoke.stdout.log` (sha256 fa9cf7e025a6d3c43dbc6133a730b47a668b8334d6615636a3d7ffd1450259b9)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/strict-benchmark-smoke.stderr.log` (sha256 ed3c128fdbdcff4e57e62a0275ac921d1313a0d53d34754dc115592baaa7f11f)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 16. e2-pending-probe
- taskId: `e5-all-20261008-a11-v02:items:e2-pending-probe`
- profile: native-kernel | scope: component | owner: astral-db | series: E2, M3
- production_services: [] | test_services: []
- boundary: pending_probe controlled omission; no live production bypass
- argv: `cargo test -p astral-db --lib evidence_cache::tests::e2_pending_probe_omission_accepts_stale_candidate_while_full_contract_reloads --locked -- --exact --nocapture`
- started: 2026-10-09T09:29:29.517367+00:00 | finished: 2026-10-09T09:29:30.205598+00:00 | elapsed: 0.554s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 858}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/e2-pending-probe.stdout.log` (sha256 740e287aa2c8bd7db6a69aa2e056b192ede7642b4c1c67c3cc5f491cb88a6a85)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/e2-pending-probe.stderr.log` (sha256 88d26dc748717dae0ab8922b301c568c1604812ba41ffb5e74205c2bd1b86a8b)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 17. e2-post-recheck
- taskId: `e5-all-20261008-a11-v02:items:e2-post-recheck`
- profile: native-kernel | scope: component | owner: astral-db | series: E2, M3
- production_services: [] | test_services: []
- boundary: post_recheck cache bracket controlled omission
- argv: `cargo test -p astral-db --lib evidence_cache::tests::e2_post_recheck_omission_accepts_interleaving_while_full_contract_reloads --locked -- --exact --nocapture`
- started: 2026-10-09T09:29:30.334628+00:00 | finished: 2026-10-09T09:29:31.020617+00:00 | elapsed: 0.554s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 858}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/e2-post-recheck.stdout.log` (sha256 81cfc40b36b9ea14bc9cd32b3a7bc0f6cd6ac9310e3469343cfe99fbc566ab3b)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/e2-post-recheck.stderr.log` (sha256 88d26dc748717dae0ab8922b301c568c1604812ba41ffb5e74205c2bd1b86a8b)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 18. e2-final-reload
- taskId: `e5-all-20261008-a11-v02:items:e2-final-reload`
- profile: native-kernel | scope: component | owner: policy-engine | series: E2, M3, M5
- production_services: [] | test_services: []
- boundary: final_reload exact controlled omission; candidate removal cannot survive reload
- argv: `cargo test -p policy-engine --lib engine::tests::e2_final_reload_omission_accepts_removed_candidate_while_full_contract_reloads --locked -- --exact --nocapture`
- started: 2026-10-09T09:29:31.147325+00:00 | finished: 2026-10-09T09:29:31.682915+00:00 | elapsed: 0.404s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 293}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/e2-final-reload.stdout.log` (sha256 7d244319a2847bf3a980b06ccab1bfe03fbae4699b2ff085efd83377269c2121)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/e2-final-reload.stderr.log` (sha256 92b56d8eaeefea8df6bb54ed067184504269235cdc4d4cc68f3037c8ae6b8ca2)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 19. e2-exact-identity
- taskId: `e5-all-20261008-a11-v02:items:e2-exact-identity`
- profile: native-kernel | scope: component | owner: policy-engine | series: E2, M3, M5
- production_services: [] | test_services: []
- boundary: exact_identity original candidate versus successor revision; no host bypass switch
- argv: `cargo test -p policy-engine --lib engine::tests::test_strict_successor_revision_cannot_replace_original_candidate --locked -- --exact --nocapture`
- started: 2026-10-09T09:29:31.810225+00:00 | finished: 2026-10-09T09:29:32.344166+00:00 | elapsed: 0.403s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 293}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/e2-exact-identity.stdout.log` (sha256 906bf3b1894307284383ec9c78be6588d2cebb8dbf22bca431c5b42d6c8b728e)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/e2-exact-identity.stderr.log` (sha256 88d424e160c06554a5bf6c1ef68054fc6ebcdd0a6e48a95c296f446d794a61c1)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 20. e2-generation-revoke-fence
- taskId: `e5-all-20261008-a11-v02:items:e2-generation-revoke-fence`
- profile: native-kernel | scope: component | owner: astral-db | series: E2, M2, M3
- production_services: [] | test_services: []
- boundary: generation_revoke_fence controlled omission and stale candidate rejection
- argv: `cargo test -p astral-db --lib evidence_cache::tests::e2_generation_revoke_fence_omission_accepts_stale_candidate --locked -- --exact --nocapture`
- started: 2026-10-09T09:29:32.479594+00:00 | finished: 2026-10-09T09:29:33.160721+00:00 | elapsed: 0.554s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 858}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/e2-generation-revoke-fence.stdout.log` (sha256 6c3b52d59ace4d3bba04748a0988b92531aa381af93859a82a839d9513be0477)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/e2-generation-revoke-fence.stderr.log` (sha256 88d26dc748717dae0ab8922b301c568c1604812ba41ffb5e74205c2bd1b86a8b)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 21. observability-feature-check
- taskId: `e5-all-20261008-a11-v02:items:observability-feature-check`
- profile: native-kernel | scope: component | owner: astral-trustgraph | series: CORE, E1, E3, E4
- production_services: [] | test_services: []
- boundary: experiment feature target compilation only; no live fault or deployed observation proof
- argv: `cargo check -p astral-trustgraph --all-targets --features e1-observability,e3-observability,e4-observability --locked`
- started: 2026-10-09T09:29:33.291217+00:00 | finished: 2026-10-09T09:29:34.022840+00:00 | elapsed: 0.603s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: command
- actual_postcondition / reason: scoped command completed; see its component proof boundary
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/observability-feature-check.stdout.log` (sha256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/observability-feature-check.stderr.log` (sha256 4618eeba4e21359898995b7f544b56cd4d474efe9641525e1447388aaa8fabe6)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 22. observability-feature-clippy
- taskId: `e5-all-20261008-a11-v02:items:observability-feature-clippy`
- profile: native-kernel | scope: component | owner: astral-trustgraph | series: CORE, E1, E3, E4
- production_services: [] | test_services: []
- boundary: all-target lint for experiment features; no integration acceptance
- argv: `cargo clippy -p astral-trustgraph --all-targets --features e1-observability,e3-observability,e4-observability --locked -- -D warnings`
- started: 2026-10-09T09:29:34.153745+00:00 | finished: 2026-10-09T09:29:35.035502+00:00 | elapsed: 0.754s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: command
- actual_postcondition / reason: scoped command completed; see its component proof boundary
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/observability-feature-clippy.stdout.log` (sha256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/observability-feature-clippy.stderr.log` (sha256 deb6cb4a6c3e79707fe01a80013f10f53ed028864b8a94992b33872d11736be8)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 23. policy-observability-tests
- taskId: `e5-all-20261008-a11-v02:items:policy-observability-tests`
- profile: native-kernel | scope: component | owner: policy-engine | series: E1, M5
- production_services: [] | test_services: []
- boundary: e1-observability library fixtures only; not a signed HTTP race
- argv: `cargo test -p policy-engine --lib --features e1-observability --locked`
- started: 2026-10-09T09:29:35.165003+00:00 | finished: 2026-10-09T09:29:36.148294+00:00 | elapsed: 0.856s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 295, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/policy-observability-tests.stdout.log` (sha256 9e43e3d48b56959b7f6d6acb635223a9fb735d14b881196abd694b331f30faa4)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/policy-observability-tests.stderr.log` (sha256 edaa5668a6d38cd9a965c203b8ebd07d8b10bd4bb6a049c6525e67612605d23d)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 24. db-observability-tests
- taskId: `e5-all-20261008-a11-v02:items:db-observability-tests`
- profile: native-kernel | scope: component | owner: astral-db | series: E1, M2, M3
- production_services: [] | test_services: []
- boundary: e1 evidence/observation fixtures; ignored integration/CPU checks not selected
- argv: `cargo test -p astral-db --lib --features e1-observability --locked`
- started: 2026-10-09T09:29:36.277689+00:00 | finished: 2026-10-09T09:31:47.815004+00:00 | elapsed: 131.408s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped non-ignored Rust assertions executed; ignored checks remain outside selection
- tests: {"passed": 857, "failed": 0, "ignored": 2, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/db-observability-tests.stdout.log` (sha256 768ef7af6623f0b118254ad0047f7b179def3577afa28214718d4998668ac68d)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/db-observability-tests.stderr.log` (sha256 1a503d465f751479628935ee48a466031bac8d3ceceb87449417889a0b7f9045)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 25. trustgraph-observability-tests
- taskId: `e5-all-20261008-a11-v02:items:trustgraph-observability-tests`
- profile: native-kernel | scope: component | owner: astral-trustgraph | series: E1, E3, E4, M4
- production_services: [] | test_services: []
- boundary: local instrumented worker/reducer fixtures; not external fault injection
- argv: `cargo test -p astral-trustgraph --lib --features e1-observability,e3-observability,e4-observability --locked`
- started: 2026-10-09T09:31:47.944415+00:00 | finished: 2026-10-09T09:34:16.734206+00:00 | elapsed: 148.659s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped non-ignored Rust assertions executed; ignored checks remain outside selection
- tests: {"passed": 838, "failed": 0, "ignored": 5, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/trustgraph-observability-tests.stdout.log` (sha256 eacac2028c7c40cbeeb40b42d37ca32484cebaaa538d2239f1b19c647803fdc9)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/trustgraph-observability-tests.stderr.log` (sha256 913b353ae3c0575c86327ad4f45a724d4ade1982d5c457d8b8a1e3336171ea72)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 26. offline-validation-tools
- taskId: `e5-all-20261008-a11-v02:items:offline-validation-tools`
- profile: offline-validation | scope: offline-model | owner: authorization-validation | series: E1, E2, E3, E4, E5, M4, M5
- production_services: [] | test_services: []
- boundary: standard-library unit/model/protocol fixtures; no actual fault injection or deployed decision proof
- argv: `python -B -m unittest discover -s Docs/authorization-validation/tools -p test_*.py`
- started: 2026-10-09T09:34:16.865550+00:00 | finished: 2026-10-09T09:50:35.992720+00:00 | elapsed: 978.976s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: unittest
- actual_postcondition / reason: offline Python assertions executed
- tests: {"executed": 502}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/offline-validation-tools.stdout.log` (sha256 cd292a49807e6ce6f3f3d9d8f7370e92880f7305e37db9dd612b4329af426d2d)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/offline-validation-tools.stderr.log` (sha256 4918080ff0e8df0980f7917b6968e0e9b509fbc54f7687ba73548b6a3d59d699)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 27. e5-bounded-single
- taskId: `e5-all-20261008-a11-v02:items:e5-bounded-single`
- profile: offline-validation | scope: offline-model | owner: authorization-validation | series: E5, M1, M2, M3, M5
- production_services: [] | test_services: []
- boundary: full abstract contract only; omission counterexamples are expected, not deployment failure
- argv: `python -B Docs/authorization-validation/tools/e5_model_check.py --max-steps 28 --json`
- started: 2026-10-09T09:50:36.123009+00:00 | finished: 2026-10-09T09:50:48.840226+00:00 | elapsed: 12.588s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: model-json
- actual_postcondition / reason: complete abstract contract; omission counterexamples are independent
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/e5-bounded-single.stdout.log` (sha256 a5fac8a38b13bc9909d5b1cecf36939c32e1d8a134a41139e1412f5e2c5517ad)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/e5-bounded-single.stderr.log` (sha256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 28. e5-bounded-two-mutations
- taskId: `e5-all-20261008-a11-v02:items:e5-bounded-two-mutations`
- profile: offline-validation | scope: offline-model | owner: authorization-validation | series: E5, M1, M2, M3, M5
- production_services: [] | test_services: []
- boundary: two-mutation bounded abstract protocol; CLI emits JSON without a --json option
- argv: `python -B Docs/authorization-validation/tools/e5_model_check_two_mutations.py --workers 12`
- started: 2026-10-09T09:50:48.969585+00:00 | finished: 2026-10-09T10:05:23.548346+00:00 | elapsed: 874.445s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: model-json
- actual_postcondition / reason: complete abstract contract; omission counterexamples are independent
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/e5-bounded-two-mutations.stdout.log` (sha256 f7afbdccd62dc146e90c5c8b442cbf0364d23b2ab2c1fd7a3af76e08c83de491)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/e5-bounded-two-mutations.stderr.log` (sha256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 29. e5-universal-bounded
- taskId: `e5-all-20261008-a11-v02:items:e5-universal-bounded`
- profile: offline-validation | scope: offline-model | owner: authorization-validation | series: E5, M1, M2, M3, M5
- production_services: [] | test_services: []
- boundary: universal hypotheses over the explicitly bounded abstract models, not unbounded system proof
- argv: `python -B Docs/authorization-validation/tools/universal_hypotheses_check.py --model both --workers 12 --json`
- started: 2026-10-09T10:05:23.679705+00:00 | finished: 2026-10-09T10:22:11.880782+00:00 | elapsed: 1008.068s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: model-json
- actual_postcondition / reason: U1-U10 complete for both bounded models; not deployment evidence
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/e5-universal-bounded.stdout.log` (sha256 36fa4025b63a86c734ffea7902bbce0dbd86118a82f04e382cca9e75214ddbde)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/e5-universal-bounded.stderr.log` (sha256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 30. offline-tenant-model
- taskId: `e5-all-20261008-a11-v02:items:offline-tenant-model`
- profile: offline-validation | scope: offline-model | owner: authorization-validation | series: E5, M3, MT-E1
- production_services: [] | test_services: []
- boundary: abstract tenant isolation hypotheses; no MySQL or policy runtime
- argv: `python -B Docs/authorization-validation/tools/tenant_isolation_model.py --json`
- started: 2026-10-09T10:22:12.011926+00:00 | finished: 2026-10-09T10:22:12.246834+00:00 | elapsed: 0.102s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: model-json
- actual_postcondition / reason: complete abstract hypothesis registry
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/offline-tenant-model.stdout.log` (sha256 8a2521c551571138f8ed240ac468cbaebe4bc3f2b3a3c6bc160b329214bba09c)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/offline-tenant-model.stderr.log` (sha256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 31. native-projection-lifecycle
- taskId: `e5-all-20261008-a11-v02:items:native-projection-lifecycle`
- profile: native-single-node | scope: integration | owner: testsuite + astral-trustgraph | series: M1, M2, M3, E3, E4, RQ3
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: production source commit/local dispatch/publication pipeline/evaluate with worker owner; sync publisher attribution is not exclusive; not signed HTTP host campaign
- argv: `cargo test -p testsuite --test native_projection_lifecycle --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T10:22:12.390309+00:00 | finished: 2026-10-09T10:22:23.098547+00:00 | elapsed: 10.579s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 2}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/native-projection-lifecycle.stdout.log` (sha256 c34bfad592b40d524b074f739146a3e5855d670b1f541698251ac5c90db369bc)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/native-projection-lifecycle.stderr.log` (sha256 fa588b6390d87320dfbe2ed8225e65b4f5316d2adca9040807ad5516fb8b728b)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 32. db-authorization-projection
- taskId: `e5-all-20261008-a11-v02:items:db-authorization-projection`
- profile: native-single-node | scope: integration | owner: astral-db | series: M1, M2, M3, E3, RQ3
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: durable projection/source/CAS/lineage tests; not complete deployed campaign
- argv: `cargo test -p astral-db --test authorization_projection_integration --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T10:22:23.226529+00:00 | finished: 2026-10-09T10:23:20.116031+00:00 | elapsed: 56.731s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 10, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/db-authorization-projection.stdout.log` (sha256 e5578837a59b62a46dbca1144ac02ff0e97eadbe98de6403982d88bfaa062dde)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/db-authorization-projection.stderr.log` (sha256 2be382e15c1f18f322b3835532a827a149b364e23743e63a27ef0b904cd3ffae)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 33. db-integration
- taskId: `e5-all-20261008-a11-v02:items:db-integration`
- profile: native-single-node | scope: integration | owner: astral-db | series: CORE, M1, M3
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: real MySQL repository contracts and legacy no-fallback guards
- argv: `cargo test -p astral-db --test integration --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T10:23:20.246367+00:00 | finished: 2026-10-09T10:23:27.557018+00:00 | elapsed: 7.179s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 2, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/db-integration.stdout.log` (sha256 7b4049d8eb7119b25a5e0de3705a2d052dfee749773358391337b7be2180fa9f)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/db-integration.stderr.log` (sha256 7434979a06732a4610266e6b7bf3411df8383972ecedff3ef4461159cd6b6c2b)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 34. db-tenant-isolation
- taskId: `e5-all-20261008-a11-v02:items:db-tenant-isolation`
- profile: native-single-node | scope: integration | owner: astral-db | series: M3, MT-E1
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: three-tenant SQL binding and retired snapshot guards
- argv: `cargo test -p astral-db --test multi_tenant_isolation --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T10:23:27.735567+00:00 | finished: 2026-10-09T10:23:48.667013+00:00 | elapsed: 20.208s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 7, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/db-tenant-isolation.stdout.log` (sha256 98bd8492098eadca66fd32d19a183e91903150b6fa9013a928444ebffb405633)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/db-tenant-isolation.stderr.log` (sha256 fc16d30481c29dadfcdba4fd238944c3f82826f6014b498e5fb54d733915e483)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 35. db-org-scope
- taskId: `e5-all-20261008-a11-v02:items:db-org-scope`
- profile: native-single-node | scope: integration | owner: astral-db | series: M2, M3, MT-E1
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: organization topology/evidence contracts; production ORG_SCOPE default remains off
- argv: `cargo test -p astral-db --test org_scope_integration --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T10:23:48.799413+00:00 | finished: 2026-10-09T10:24:31.906003+00:00 | elapsed: 42.973s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 15, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/db-org-scope.stdout.log` (sha256 a5fd6f3556dd4160d00a5f51459741ba63a0f71713bbfde4dd79e5e1d0ec0d05)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/db-org-scope.stderr.log` (sha256 0492c67450b9abc66a4eb951c578f58e21b459a46958bd438be1deb4b160293b)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 36. db-partition-lease
- taskId: `e5-all-20261008-a11-v02:items:db-partition-lease`
- profile: native-single-node | scope: integration | owner: astral-db | series: M2, E3, E4
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: durable partition ownership/CAS/reclaim contracts
- argv: `cargo test -p astral-db --test partition_lease_integration --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T10:24:32.038394+00:00 | finished: 2026-10-09T10:24:37.718212+00:00 | elapsed: 5.52s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 7, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/db-partition-lease.stdout.log` (sha256 bbd934dcab59a910fc6e0542e7de3e56b01ece8f7c6302325920bbce680017f8)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/db-partition-lease.stderr.log` (sha256 f5a350924372f22414fe60d6a9998c099850a3225cc6ffe867ba11909b75a476)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 37. db-quarantine
- taskId: `e5-all-20261008-a11-v02:items:db-quarantine`
- profile: native-single-node | scope: integration | owner: astral-db | series: M4, E3, E4
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: real durable quarantine terminal and retry boundaries
- argv: `cargo test -p astral-db --test quarantine_integration --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T10:24:37.859758+00:00 | finished: 2026-10-09T10:24:46.971532+00:00 | elapsed: 8.981s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 7, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/db-quarantine.stdout.log` (sha256 94641eb4503e184fd602a7bb54440f9ab8e8edd48b570b43b60c47ab16892486)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/db-quarantine.stderr.log` (sha256 9bff4d8f508444efe570dc9fefd1a2d7b2bcab7d25ee1d4073edee63b142711f)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 38. identity-integration
- taskId: `e5-all-20261008-a11-v02:items:identity-integration`
- profile: native-single-node | scope: integration | owner: astral-identity | series: CORE, M5
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: real identity/session/card contracts; no legacy role bypass
- argv: `cargo test -p astral-identity --test integration --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T10:24:47.101809+00:00 | finished: 2026-10-09T10:25:53.414183+00:00 | elapsed: 66.18s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 8, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/identity-integration.stdout.log` (sha256 0ce2d18286d5d25a01f3bd6b7e2966eeb44f21e33a4de8f14d890da1c408c912)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/identity-integration.stderr.log` (sha256 697c37c81ea9e3bf3950b6f5f990b3a87a1a224a2f6a6314adfef373e8c27902)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 39. trustgraph-integration
- taskId: `e5-all-20261008-a11-v02:items:trustgraph-integration`
- profile: native-single-node | scope: integration | owner: astral-trustgraph | series: CORE, M1, M2, M3
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: source repository and cascade fail-closed contracts with production origin region
- argv: `cargo test -p astral-trustgraph --test integration --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T10:25:53.549892+00:00 | finished: 2026-10-09T10:28:04.229337+00:00 | elapsed: 130.547s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 11, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/trustgraph-integration.stdout.log` (sha256 cd939fb7b0419fb44e8a9530bb37d408ba663593993208e6822d92fdb3b8bdd4)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/trustgraph-integration.stderr.log` (sha256 0f5d039300fc2d85db0b622d996cdcb7d8b805cf1ebb8b80549ebbdc0e602ac1)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 40. trustgraph-org-projector
- taskId: `e5-all-20261008-a11-v02:items:trustgraph-org-projector`
- profile: native-single-node | scope: integration | owner: astral-trustgraph | series: M2, E3
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: real dual-worker competition and organization projection contracts
- argv: `cargo test -p astral-trustgraph --test org_scope_projector_integration --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T10:28:04.359859+00:00 | finished: 2026-10-09T10:28:09.460695+00:00 | elapsed: 4.969s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/trustgraph-org-projector.stdout.log` (sha256 9421f207513414ae94f2bd39e229294b9ce731e934b225f02f60d9a115b3b05f)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/trustgraph-org-projector.stderr.log` (sha256 0277c9be2ae1135dda0d390a93d60bea24df7bc4ec77b7b424bc5029580effbf)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 41. monitor-integration
- taskId: `e5-all-20261008-a11-v02:items:monitor-integration`
- profile: native-single-node | scope: integration | owner: astral-monitor | series: CORE
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: monitor database contracts; no tenant-isolation claim
- argv: `cargo test -p astral-monitor --test integration --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T10:28:09.591668+00:00 | finished: 2026-10-09T10:28:19.261894+00:00 | elapsed: 9.537s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 5, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/monitor-integration.stdout.log` (sha256 40e4eac99607358001e58d443ff8da3e067875c14e1fd834807cf37fc866e183)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/monitor-integration.stderr.log` (sha256 2bedcc1ca5f44835f1e6f5da9512476f433029a8a66aca28ba94e32a79f4a52a)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 42. hub-invalidation-premise
- taskId: `e5-all-20261008-a11-v02:items:hub-invalidation-premise`
- profile: native-single-node | scope: integration | owner: testsuite | series: M3, E4
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: commit-proven publication mirror and invalidation freshness gate; not whole source/worker lifecycle
- argv: `cargo test -p testsuite --test premise_hub_invalidation --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T10:28:19.395249+00:00 | finished: 2026-10-09T10:28:23.947011+00:00 | elapsed: 4.418s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/hub-invalidation-premise.stdout.log` (sha256 8b33ee27a6f5fb8bfa724261effea630f5473adba780bfcc49b90497c19dc3f5)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/hub-invalidation-premise.stderr.log` (sha256 f76bb0148cf87aa61044d1b503cdc33735fe657ef0ff93c903b39a025a6bf6db)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 43. single-writer-premise
- taskId: `e5-all-20261008-a11-v02:items:single-writer-premise`
- profile: native-single-node | scope: integration | owner: testsuite | series: M2, E4
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: same-session MySQL advisory lock, explicit close and bounded reacquisition
- argv: `cargo test -p testsuite --test premise_single_writer_lease --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T10:28:24.079061+00:00 | finished: 2026-10-09T10:28:28.880496+00:00 | elapsed: 4.619s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/single-writer-premise.stdout.log` (sha256 1423195bc2d5ba5d68260139a650c02009e8f726ba9067cde6c1d9e187e6db99)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/single-writer-premise.stderr.log` (sha256 b60685b94ef3907c8afb2a008d2e50bf1a59ada01965189ab6a432fc173b8239)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 44. identity-mapping-premise
- taskId: `e5-all-20261008-a11-v02:items:identity-mapping-premise`
- profile: native-single-node | scope: integration | owner: testsuite | series: M5, E4
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: real mapping/app_id isolation and absent mapping refusal; exact-byte MySQL ENUM decoding with strict schema validation
- argv: `cargo test -p testsuite --test premise_identity_mapping --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T10:28:29.012187+00:00 | finished: 2026-10-09T10:28:36.988127+00:00 | elapsed: 7.844s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 2, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/identity-mapping-premise.stdout.log` (sha256 2147416bf04c4b732de80fa266b6ce0dc87ebcd8f021d82d702f52cab7d3200d)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/identity-mapping-premise.stderr.log` (sha256 b01004820c2d3658239d950fc96535317b6ef2122c83a5670a0980e5acea994e)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 45. dedicated-identity-mapping
- taskId: `e5-all-20261008-a11-v02:items:dedicated-identity-mapping`
- profile: native-single-node | scope: integration | owner: astral-db | series: M5, E4
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: dedicated sdk_identity_mapping_test_* migrated database; guard is not relaxed
- argv: `cargo test -p astral-db --test integration_identity_mapping --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T10:28:37.218455+00:00 | finished: 2026-10-09T10:28:42.700248+00:00 | elapsed: 4.406s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 2, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/dedicated-identity-mapping.stdout.log` (sha256 95b9e2ada1bc55a1535ea19a89b7c7800ab1a13d173b4500a3740f99c9d10c93)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/dedicated-identity-mapping.stderr.log` (sha256 e286646ae76303a376fc6d2b2c2854849f996345a5bf993fd5f2b34b2df6fd7b)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 46. mt-isolation
- taskId: `e5-all-20261008-a11-v02:items:mt-isolation`
- profile: native-single-node | scope: integration | owner: testsuite | series: MT-E1, M3, RQ2
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: tenant-scoped canonical publication/evidence isolation; not HTTP performance
- argv: `cargo test -p testsuite --test mt_extreme_isolation --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T10:28:42.866415+00:00 | finished: 2026-10-09T10:28:51.772073+00:00 | elapsed: 7.825s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/mt-isolation.stdout.log` (sha256 f31773d6230639c6224a942c15eee4e35beb80af822034119484052674b85b36)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/mt-isolation.stderr.log` (sha256 ba0a114e144bed893fa13d88f6e4ae932866e2e50fdcea855dd07d8767dd6d01)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 47. mt-churn
- taskId: `e5-all-20261008-a11-v02:items:mt-churn`
- profile: native-single-node | scope: integration | owner: testsuite | series: MT-E3, M2, RQ3, RQ4
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: successive CAS pointer add/revoke/restore generations; not three-node propagation
- argv: `cargo test -p testsuite --test mt_extreme_churn --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T10:28:51.903391+00:00 | finished: 2026-10-09T10:28:57.554316+00:00 | elapsed: 5.518s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/mt-churn.stdout.log` (sha256 0ae3602f105b6fe46bec687efeaa0c5be2b4cb53872c77aa215908d5bb143bf0)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/mt-churn.stderr.log` (sha256 cbdba9250c365c9f065355bbddc5b718c1ed0a4193b692953daa12fc30a16ab4)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 48. mt-cross-storm
- taskId: `e5-all-20261008-a11-v02:items:mt-cross-storm`
- profile: native-single-node | scope: integration | owner: testsuite | series: MT-E4, M3, RQ4
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: cross-tenant invalidation/evidence fixture; not a distributed message storm
- argv: `cargo test -p testsuite --test mt_extreme_cross_storm --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T10:28:57.685858+00:00 | finished: 2026-10-09T10:29:03.036456+00:00 | elapsed: 5.219s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/mt-cross-storm.stdout.log` (sha256 fa07c0ac67af90bf8b4f93ad656346b0a1ed2000f27fe1c4427d87c6451114f9)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/mt-cross-storm.stderr.log` (sha256 161953cccdfab20cb8fae69889060412d739d07d239bc2066c72c2df49782852)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 49. mt-capacity
- taskId: `e5-all-20261008-a11-v02:items:mt-capacity`
- profile: native-single-node | scope: integration | owner: testsuite | series: MT-E5, RQ2
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: bounded MySQL tenant/card capacity; not engine/HTTP throughput
- argv: `cargo test -p testsuite --test mt_extreme_capacity --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T10:29:03.333339+00:00 | finished: 2026-10-09T10:29:19.727415+00:00 | elapsed: 15.865s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/mt-capacity.stdout.log` (sha256 69e83dc28cddc4bfb7f60ffc2eb12aa99086f2823826157fbb64e950a0ab32f2)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/mt-capacity.stderr.log` (sha256 c192b76ef4e649335d0f25d1954a1a6829b5ccb69e4a865685518a7a5e8c3abd)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 50. mt-failclosed
- taskId: `e5-all-20261008-a11-v02:items:mt-failclosed`
- profile: native-single-node | scope: integration | owner: testsuite | series: MT-E6, M3, M4, E4
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: typed NotReady/Pending, no arbitrary database-error-as-denial acceptance
- argv: `cargo test -p testsuite --test mt_extreme_failclosed --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T10:29:19.866800+00:00 | finished: 2026-10-09T10:29:25.143005+00:00 | elapsed: 4.723s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/mt-failclosed.stdout.log` (sha256 f93cd2a731d8d73b7255c3ce3fdfa7f1d8c10a5c88d49b6fdf708ae17fa602fe)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/mt-failclosed.stderr.log` (sha256 5307ecd81cb498cf53251a70268c4f35d96fc2f9d61fe1cd063dd96d3716280b)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 51. rabbit-audit-replay
- taskId: `e5-all-20261008-a11-v02:items:rabbit-audit-replay`
- profile: standalone-rabbit | scope: integration | owner: astral-trustgraph | series: M1, M2, E3, E4
- production_services: ['mysql', 'rabbitmq'] | test_services: ['mysql', 'rabbitmq']
- boundary: real Rabbit confirm + MySQL mq_idempotent_log/audit_log/completed lease; no Redis
- argv: `cargo test -p astral-trustgraph --test audit_replay_integration --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T10:29:25.291120+00:00 | finished: 2026-10-09T10:29:33.163723+00:00 | elapsed: 7.678s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 3}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/rabbit-audit-replay.stdout.log` (sha256 7164e9baa9b05bf0b6d0f304a9ac1b896fe28e86f40b324291a4148c4fc7bc01)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/rabbit-audit-replay.stderr.log` (sha256 2a8ea13b4eabfc247467f35ceefbacb1880c94ab6a6b22521067a6730f2fa8f0)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RABBITMQ_URL, RUST_INTEGRATION_REQUIRED

### 52. redis-evidence-compat
- taskId: `e5-all-20261008-a11-v02:items:redis-evidence-compat`
- profile: redis-compat | scope: integration | owner: astral-db | series: COMPAT, E4
- production_services: ['mysql', 'redis'] | test_services: ['mysql', 'redis']
- boundary: explicit adapter window only; cannot establish native evidence path acceptance
- argv: `cargo test -p astral-db --features redis-compat --test evidence_cache_redis_integration --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T10:29:33.294929+00:00 | finished: 2026-10-09T10:31:00.109051+00:00 | elapsed: 86.682s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 25, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/redis-evidence-compat.stdout.log` (sha256 118b81af30bbfb2e3c256c032b9a592696f3ef9c4cf15a1d4a65ca513683df4a)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/redis-evidence-compat.stderr.log` (sha256 9081b9dd6b8b187e2fb158705077ffc44d4a11f843ea7c36bf2997d0b26e1983)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, REDIS_URL, RUST_INTEGRATION_REQUIRED

### 53. strict-policy-benchmark
- taskId: `e5-all-20261008-a11-v02:items:strict-policy-benchmark`
- profile: performance-kernel | scope: component | owner: policy-engine | series: PERF, RQ1, RQ5
- production_services: [] | test_services: []
- boundary: strict fixture decision and condition CPU timing, preasserted ALLOW/DENY/PENDING; no MySQL/HTTP
- argv: `cargo bench -p policy-engine --bench policy_bench --locked -- --color never`
- started: 2026-10-09T10:31:00.242231+00:00 | finished: 2026-10-09T10:33:11.296289+00:00 | elapsed: 130.917s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: criterion
- actual_postcondition / reason: complete measured CPU Criterion cases; no HTTP/DB claim
- performance: CPU component only, cases 8
  - engine/published_ready_allow
  - engine/published_ready_empty_deny
  - engine/published_unavailable_pending
  - engine/published_ready_nonmatching_set
  - engine/published_tenant_gradient_32
  - condition/component_time_range
  - condition/component_ipv4_range
  - condition/component_scope
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/strict-policy-benchmark.stdout.log` (sha256 abd6a9871a168cce100bf2a64df8f38b93c5f17189981e24e19163d564d22988)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/strict-policy-benchmark.stderr.log` (sha256 be47e5602d633252bfbd240123e7d18025a50a9c6523e707f28a30071141bb72)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 54. strict-tenant-benchmark
- taskId: `e5-all-20261008-a11-v02:items:strict-tenant-benchmark`
- profile: performance-kernel | scope: component | owner: policy-engine | series: PERF, RQ2, RQ5, MT-E1
- production_services: [] | test_services: []
- boundary: strict scope-aware positive identities and checked join/decisions; CPU-only
- argv: `cargo bench -p policy-engine --bench tenant_isolation_bench --locked -- --color never`
- started: 2026-10-09T10:33:11.426675+00:00 | finished: 2026-10-09T10:34:57.534107+00:00 | elapsed: 105.974s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: criterion
- actual_postcondition / reason: complete measured CPU Criterion cases; no HTTP/DB claim
- performance: CPU component only, cases 9
  - tenant_isolation/published_single_tenant_10_rules
  - tenant_isolation/published_concurrent_10_tenants
  - tenant_isolation/published_concurrent_50_tenants
  - tenant_isolation/published_concurrent_100_tenants
  - tenant_isolation/data_scope_resolve
  - tenant_isolation/data_scope_resolve_personal
  - tenant_isolation/published_cross_tenant_100x50
  - tenant_isolation/published_empty_deny
  - tenant_isolation/published_unavailable_pending
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/strict-tenant-benchmark.stdout.log` (sha256 e2035f7621b62a900ab311db7103c0b8e918bfe84321c03c06e440861d9b2941)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/strict-tenant-benchmark.stderr.log` (sha256 36e53462b59cd79132bc3363988f847795ee4bef76a23c7fce1d5376b3946649)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 55. compiler-benchmark
- taskId: `e5-all-20261008-a11-v02:items:compiler-benchmark`
- profile: performance-kernel | scope: component | owner: policy-engine | series: PERF, RQ2, RQ3
- production_services: [] | test_services: []
- boundary: production compiler incremental/full parity, exact/wildcard/multi-delta CPU benchmark
- argv: `cargo bench -p policy-engine --bench authorization_compiler_bench --locked -- --color never`
- started: 2026-10-09T10:34:57.665143+00:00 | finished: 2026-10-09T10:40:26.110045+00:00 | elapsed: 328.311s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: criterion
- actual_postcondition / reason: complete measured CPU Criterion cases; no HTTP/DB claim
- performance: CPU component only, cases 30
  - compiler/incremental_exact_add/n=100
  - compiler/full_exact_add/n=100
  - compiler/incremental_exact_remove/n=100
  - compiler/full_exact_remove/n=100
  - compiler/incremental_windowed_add/n=100
  - compiler/full_windowed_add/n=100
  - compiler/incremental_wildcard_add/n=100
  - compiler/full_wildcard_add/n=100
  - compiler/batch50_incremental/n=100
  - compiler/batch50_full/n=100
  - compiler/incremental_exact_add/n=1000
  - compiler/full_exact_add/n=1000
  - compiler/incremental_exact_remove/n=1000
  - compiler/full_exact_remove/n=1000
  - compiler/incremental_windowed_add/n=1000
  - compiler/full_windowed_add/n=1000
  - compiler/incremental_wildcard_add/n=1000
  - compiler/full_wildcard_add/n=1000
  - compiler/batch50_incremental/n=1000
  - compiler/batch50_full/n=1000
  - compiler/incremental_exact_add/n=4050
  - compiler/full_exact_add/n=4050
  - compiler/incremental_exact_remove/n=4050
  - compiler/full_exact_remove/n=4050
  - compiler/incremental_windowed_add/n=4050
  - compiler/full_windowed_add/n=4050
  - compiler/incremental_wildcard_add/n=4050
  - compiler/full_wildcard_add/n=4050
  - compiler/batch50_incremental/n=4050
  - compiler/batch50_full/n=4050
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/compiler-benchmark.stdout.log` (sha256 9e39447077da4cfeac934598a0282818e5a9a7cb518954ccc216f7a1d4b83d68)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/compiler-benchmark.stderr.log` (sha256 170e603da973373111fb4f5e61a0dd17465f30a3a657e8ffde4361cccbddbcce)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 56. compiler-allocation-contracts
- taskId: `e5-all-20261008-a11-v02:items:compiler-allocation-contracts`
- profile: performance-kernel | scope: component | owner: policy-engine | series: PERF, RQ2, RQ3
- production_services: [] | test_services: []
- boundary: compiler allocation contract assertions, not service capacity
- argv: `cargo test -p policy-engine --test authorization_compiler_alloc --locked`
- started: 2026-10-09T10:40:26.241067+00:00 | finished: 2026-10-09T10:40:30.538166+00:00 | elapsed: 4.166s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 4, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/compiler-allocation-contracts.stdout.log` (sha256 7aaf4b740a299d9279d0febd42e01ee2f048b124e8c2c4c7889b97f3492aad33)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/compiler-allocation-contracts.stderr.log` (sha256 1b8394e86fc3783a9fe18393af063a3ff8306a747dea7c01b4dc07b7c84976a0)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 57. compiler-allocation-benchmark
- taskId: `e5-all-20261008-a11-v02:items:compiler-allocation-benchmark`
- profile: performance-kernel | scope: component | owner: policy-engine | series: PERF, RQ2, RQ3
- production_services: [] | test_services: []
- boundary: production compiler allocation microbenchmark; no external services
- argv: `cargo bench -p policy-engine --bench authorization_compiler_alloc --locked`
- started: 2026-10-09T10:40:30.669245+00:00 | finished: 2026-10-09T10:40:51.680571+00:00 | elapsed: 20.879s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: divan
- actual_postcondition / reason: complete CPU allocation benchmark; no service-capacity claim
- performance: CPU/allocation component only; instrumented timing, cases 6
  - private_add_grant
  - private_build
  - shared_add_grant
  - shared_build
  - shared_clone
  - shared_entry_count_proof
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/compiler-allocation-benchmark.stdout.log` (sha256 5b5bd92557e7451debf90feac82686a661dedda19c5d74084822b2e7e094f7ac)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/compiler-allocation-benchmark.stderr.log` (sha256 572f03773044999c349e2edb598207a92827e77c72b96b3b041e267efb3545d1)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 58. memory-hub-performance
- taskId: `e5-all-20261008-a11-v02:items:memory-hub-performance`
- profile: performance-kernel | scope: component | owner: astral-db | series: PERF, RQ5
- production_services: [] | test_services: []
- boundary: CPU evidence read matrix: cold/hot/token/clock/concurrency/pressure; not SQL/HTTP latency
- argv: `cargo test -p astral-db --lib memory_evidence_no_regression_matrix --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T10:40:51.814748+00:00 | finished: 2026-10-09T10:46:15.940330+00:00 | elapsed: 323.993s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: complete CPU performance matrix measured; no HTTP/DB claim
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 858}
- performance: CPU component only, cases 82
  - case `evidence/1/cold/validate-false`
  - case `evidence/1/cold/validate-true`
  - case `evidence/1/hot-fixed/validate-false`
  - case `evidence/1/hot-fixed/validate-true`
  - case `evidence/1/cross-second/validate-false`
  - case `evidence/1/cross-second/validate-true`
  - case `evidence/1/token-change/validate-false`
  - case `evidence/1/token-change/validate-true`
  - case `evidence/1/real-clock/validate-false`
  - case `evidence/1/real-clock/validate-true`
  - case `evidence/8/cold/validate-false`
  - case `evidence/8/cold/validate-true`
  - case `evidence/8/hot-fixed/validate-false`
  - case `evidence/8/hot-fixed/validate-true`
  - case `evidence/8/cross-second/validate-false`
  - case `evidence/8/cross-second/validate-true`
  - case `evidence/8/token-change/validate-false`
  - case `evidence/8/token-change/validate-true`
  - case `evidence/8/real-clock/validate-false`
  - case `evidence/8/real-clock/validate-true`
  - case `evidence/128/cold/validate-false`
  - case `evidence/128/cold/validate-true`
  - case `evidence/128/hot-fixed/validate-false`
  - case `evidence/128/hot-fixed/validate-true`
  - case `evidence/128/cross-second/validate-false`
  - case `evidence/128/cross-second/validate-true`
  - case `evidence/128/token-change/validate-false`
  - case `evidence/128/token-change/validate-true`
  - case `evidence/128/real-clock/validate-false`
  - case `evidence/128/real-clock/validate-true`
  - case `evidence/512/cold/validate-false`
  - case `evidence/512/cold/validate-true`
  - case `evidence/512/hot-fixed/validate-false`
  - case `evidence/512/hot-fixed/validate-true`
  - case `evidence/512/cross-second/validate-false`
  - case `evidence/512/cross-second/validate-true`
  - case `evidence/512/token-change/validate-false`
  - case `evidence/512/token-change/validate-true`
  - case `evidence/512/real-clock/validate-false`
  - case `evidence/512/real-clock/validate-true`
  - case `evidence/2048/cold/validate-false`
  - case `evidence/2048/cold/validate-true`
  - case `evidence/2048/hot-fixed/validate-false`
  - case `evidence/2048/hot-fixed/validate-true`
  - case `evidence/2048/cross-second/validate-false`
  - case `evidence/2048/cross-second/validate-true`
  - case `evidence/2048/token-change/validate-false`
  - case `evidence/2048/token-change/validate-true`
  - case `evidence/2048/real-clock/validate-false`
  - case `evidence/2048/real-clock/validate-true`
  - case `concurrent/1/threads-1/staggered-false/real-false`
  - case `concurrent/1/threads-1/staggered-false/real-true`
  - case `concurrent/1/threads-1/staggered-true/real-false`
  - case `concurrent/1/threads-1/staggered-true/real-true`
  - case `concurrent/1/threads-4/staggered-false/real-false`
  - case `concurrent/1/threads-4/staggered-false/real-true`
  - case `concurrent/1/threads-4/staggered-true/real-false`
  - case `concurrent/1/threads-4/staggered-true/real-true`
  - case `concurrent/1/threads-8/staggered-false/real-false`
  - case `concurrent/1/threads-8/staggered-false/real-true`
  - case `concurrent/1/threads-8/staggered-true/real-false`
  - case `concurrent/1/threads-8/staggered-true/real-true`
  - case `concurrent/512/threads-1/staggered-false/real-false`
  - case `concurrent/512/threads-1/staggered-false/real-true`
  - case `concurrent/512/threads-1/staggered-true/real-false`
  - case `concurrent/512/threads-1/staggered-true/real-true`
  - case `concurrent/512/threads-4/staggered-false/real-false`
  - case `concurrent/512/threads-4/staggered-false/real-true`
  - case `concurrent/512/threads-4/staggered-true/real-false`
  - case `concurrent/512/threads-4/staggered-true/real-true`
  - case `concurrent/512/threads-8/staggered-false/real-false`
  - case `concurrent/512/threads-8/staggered-false/real-true`
  - case `concurrent/512/threads-8/staggered-true/real-false`
  - case `concurrent/512/threads-8/staggered-true/real-true`
  - case `pressure/64/hot-cold-false`
  - case `pressure/64/hot-cold-true`
  - case `pressure/512/hot-cold-false`
  - case `pressure/512/hot-cold-true`
  - case `pressure/1000/hot-cold-false`
  - case `pressure/1000/hot-cold-true`
  - case `pressure/1100/hot-cold-false`
  - case `pressure/1100/hot-cold-true`
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/memory-hub-performance.stdout.log` (sha256 aade472a67c49880b6d226c4ad5deabc32967058d6c73f263f428eca8c97a6df)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/memory-hub-performance.stderr.log` (sha256 064b1dd712177272a8a4c2bbbe6f98d7f2e501b2630b610589b9ec5a9747045b)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 59. stage-plan-performance
- taskId: `e5-all-20261008-a11-v02:items:stage-plan-performance`
- profile: performance-kernel | scope: component | owner: astral-trustgraph | series: PERF, RQ3
- production_services: [] | test_services: []
- boundary: CPU complete stage-plan matrix; no durable projector throughput claim
- argv: `cargo test -p astral-trustgraph --lib complete_stage_plan_no_regression_matrix --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T10:46:16.071308+00:00 | finished: 2026-10-09T10:51:11.858206+00:00 | elapsed: 295.649s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: complete CPU performance matrix measured; no HTTP/DB claim
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 842}
- performance: CPU component only, cases 15
  - case `stage/1/hit`
  - case `stage/1/miss`
  - case `stage/1/duplicate`
  - case `stage/8/hit`
  - case `stage/8/miss`
  - case `stage/8/duplicate`
  - case `stage/128/hit`
  - case `stage/128/miss`
  - case `stage/128/duplicate`
  - case `stage/512/hit`
  - case `stage/512/miss`
  - case `stage/512/duplicate`
  - case `stage/2048/hit`
  - case `stage/2048/miss`
  - case `stage/2048/duplicate`
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/stage-plan-performance.stdout.log` (sha256 ed057efd73d72527041a3c1d65e0e37ff23f7c5fa236fb3d037185e423fdedc2)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/stage-plan-performance.stderr.log` (sha256 265a7079c02e241e3b94ea8c5371ecfc855d1afbdf613d4d73c0ce415af280f1)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 60. parent-lookup-performance
- taskId: `e5-all-20261008-a11-v02:items:parent-lookup-performance`
- profile: performance-kernel | scope: component | owner: astral-trustgraph | series: PERF, RQ3
- production_services: [] | test_services: []
- boundary: CPU stable-parent-ordinal lookup matrix; no SQL/worker throughput claim
- argv: `cargo test -p astral-trustgraph --lib parent_lookup_no_regression_matrix --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T10:51:11.996184+00:00 | finished: 2026-10-09T10:52:49.211751+00:00 | elapsed: 97.08s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: complete CPU performance matrix measured; no HTTP/DB claim
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 842}
- performance: CPU component only, cases 40
  - case `lookup/0/hit`
  - case `lookup/0/miss`
  - case `lookup/0/mixed`
  - case `lookup/0/duplicate`
  - case `lookup/1/hit`
  - case `lookup/1/miss`
  - case `lookup/1/mixed`
  - case `lookup/1/duplicate`
  - case `lookup/8/hit`
  - case `lookup/8/miss`
  - case `lookup/8/mixed`
  - case `lookup/8/duplicate`
  - case `lookup/32/hit`
  - case `lookup/32/miss`
  - case `lookup/32/mixed`
  - case `lookup/32/duplicate`
  - case `lookup/64/hit`
  - case `lookup/64/miss`
  - case `lookup/64/mixed`
  - case `lookup/64/duplicate`
  - case `lookup/128/hit`
  - case `lookup/128/miss`
  - case `lookup/128/mixed`
  - case `lookup/128/duplicate`
  - case `lookup/256/hit`
  - case `lookup/256/miss`
  - case `lookup/256/mixed`
  - case `lookup/256/duplicate`
  - case `lookup/512/hit`
  - case `lookup/512/miss`
  - case `lookup/512/mixed`
  - case `lookup/512/duplicate`
  - case `lookup/2048/hit`
  - case `lookup/2048/miss`
  - case `lookup/2048/mixed`
  - case `lookup/2048/duplicate`
  - case `lookup/imbalanced-1-2048-tail-false`
  - case `lookup/imbalanced-1-2048-tail-true`
  - case `lookup/imbalanced-8-2048-tail-false`
  - case `lookup/imbalanced-2048-8-tail-true`
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/parent-lookup-performance.stdout.log` (sha256 d5862f1011b8fab2efd9b17edfe01aca83182b0b1ab7648653647f066cbccbab)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/items/parent-lookup-performance.stderr.log` (sha256 91d6bb8975af3a2fb0943a2bbb69a996a522943d9d63360370155d6ecfd8fe4a)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

## collection 独立重跑（60 项）

### 1. campaign-contracts
- taskId: `e5-all-20261008-a11-v02:collection:campaign-contracts`
- profile: native-kernel | scope: component | owner: scripts | series: CORE, M4, E4
- production_services: [] | test_services: []
- boundary: runner/manifest assertions and stub subprocesses only; no DB, Docker or live fault
- argv: `python -B -m unittest discover -s scripts/tests -p test_*.py`
- started: 2026-10-09T10:52:49.346818+00:00 | finished: 2026-10-09T10:52:53.346791+00:00 | elapsed: 3.864s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: unittest
- actual_postcondition / reason: offline Python assertions executed
- tests: {"executed": 78}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/campaign-contracts.stdout.log` (sha256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/campaign-contracts.stderr.log` (sha256 c2cb0f1abdea0d61e6e3ce8ee8b59fe95d6e9b698f00e3058ce5cf32da4b7b89)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 2. shell-runner-contracts
- taskId: `e5-all-20261008-a11-v02:collection:shell-runner-contracts`
- profile: native-kernel | scope: component | owner: scripts | series: CORE, E4
- production_services: [] | test_services: []
- boundary: mock Cargo/Docker orchestration only; no integration proof
- argv: `bash scripts/tests/test-run-tests.sh`
- started: 2026-10-09T10:52:53.481678+00:00 | finished: 2026-10-09T10:52:54.019106+00:00 | elapsed: 0.403s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: command
- actual_postcondition / reason: scoped command completed; see its component proof boundary
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/shell-runner-contracts.stdout.log` (sha256 d3bd757c22a48729f4092e2da42c8c8e7c7b0cc1d2a7b0bd2e2a904a692602ce)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/shell-runner-contracts.stderr.log` (sha256 e4fe9466e4dd8897a431596f65d490bff35f7cef75fec3270594aa667d185f48)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 3. workspace-check
- taskId: `e5-all-20261008-a11-v02:collection:workspace-check`
- profile: native-kernel | scope: component | owner: workspace | series: CORE
- production_services: [] | test_services: []
- boundary: current workspace members compile; excluded crates separate
- argv: `cargo check --workspace --locked`
- started: 2026-10-09T10:52:54.152630+00:00 | finished: 2026-10-09T10:52:55.140930+00:00 | elapsed: 0.855s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: command
- actual_postcondition / reason: scoped command completed; see its component proof boundary
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/workspace-check.stdout.log` (sha256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/workspace-check.stderr.log` (sha256 d9533554809e0846c6113df1671caf5d74f2a7b9763b0232786a0b652704164a)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 4. workspace-clippy
- taskId: `e5-all-20261008-a11-v02:collection:workspace-clippy`
- profile: native-kernel | scope: component | owner: workspace | series: CORE
- production_services: [] | test_services: []
- boundary: required workspace lint; compiler-specific failures are not suppressed
- argv: `cargo clippy --workspace --locked -- -D warnings`
- started: 2026-10-09T10:52:55.276043+00:00 | finished: 2026-10-09T10:52:56.417526+00:00 | elapsed: 1.005s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: command
- actual_postcondition / reason: scoped command completed; see its component proof boundary
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/workspace-clippy.stdout.log` (sha256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/workspace-clippy.stderr.log` (sha256 93a9750a90ebd973ec3f714d39e412b44eb5ed423aade70d185ebcb11081f183)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 5. workspace-fmt
- taskId: `e5-all-20261008-a11-v02:collection:workspace-fmt`
- profile: native-kernel | scope: component | owner: workspace | series: CORE
- production_services: [] | test_services: []
- boundary: read-only formatting assertion
- argv: `cargo fmt --all -- --check`
- started: 2026-10-09T10:52:56.554548+00:00 | finished: 2026-10-09T10:53:00.902854+00:00 | elapsed: 4.214s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: command
- actual_postcondition / reason: scoped command completed; see its component proof boundary
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/workspace-fmt.stdout.log` (sha256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/workspace-fmt.stderr.log` (sha256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 6. workspace-tests
- taskId: `e5-all-20261008-a11-v02:collection:workspace-tests`
- profile: native-kernel | scope: component | owner: workspace | series: CORE
- production_services: [] | test_services: []
- boundary: workspace non-ignored tests; ignored/SKIP counted separately, never real integration PASS
- argv: `cargo test --workspace --locked`
- started: 2026-10-09T10:53:01.036987+00:00 | finished: 2026-10-09T10:56:17.257777+00:00 | elapsed: 196.089s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped non-ignored Rust assertions executed; ignored checks remain outside selection
- tests: {"passed": 2778, "failed": 0, "ignored": 97, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/workspace-tests.stdout.log` (sha256 fa435b41a66431d2cb503cb0808f1cc89922478d0924f90d86c3f98e228d6670)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/workspace-tests.stderr.log` (sha256 b94818d273bac7918c5a33d8c0b9995f282ba591bdeb1f4f8b3157080f3a2bf9)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 7. native-dependency-tree
- taskId: `e5-all-20261008-a11-v02:collection:native-dependency-tree`
- profile: native-kernel | scope: component | owner: astral-single-node | series: CORE, E4, M4
- production_services: [] | test_services: []
- boundary: default compiled dependency tree has no Redis; not an actual deployed-config inspection
- argv: `cargo tree -p astral-single-node --locked --prefix none`
- started: 2026-10-09T10:56:17.388430+00:00 | finished: 2026-10-09T10:56:18.024383+00:00 | elapsed: 0.504s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: dependency-tree
- actual_postcondition / reason: scoped command completed; see its component proof boundary
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/native-dependency-tree.stdout.log` (sha256 62f5d372f238c4b7cdc8404ca10a00885dc75cbc1b88078043514d0a30dc40f9)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/native-dependency-tree.stderr.log` (sha256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 8. strict-tenant-isolation
- taskId: `e5-all-20261008-a11-v02:collection:strict-tenant-isolation`
- profile: native-kernel | scope: component | owner: policy-engine | series: M3, M5, MT-E1, RQ2
- production_services: [] | test_services: []
- boundary: strict published-evidence injected fixture; final reload/scope/legacy-port assertions, no durable DB
- argv: `cargo test -p policy-engine --test tenant_isolation_tests --locked -- --nocapture`
- started: 2026-10-09T10:56:18.156568+00:00 | finished: 2026-10-09T10:56:18.691766+00:00 | elapsed: 0.403s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 16, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/strict-tenant-isolation.stdout.log` (sha256 be0d57924369ad5358041f5c006112b08cc7e32ccb230487533a61da5b7d7645)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/strict-tenant-isolation.stderr.log` (sha256 4b28549bfa0e720e64215a823c55bcd51030c6176b3f2889aaa936fd73171224)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 9. gateway-contracts
- taskId: `e5-all-20261008-a11-v02:collection:gateway-contracts`
- profile: native-kernel | scope: component | owner: astral-common | series: E1, M5
- production_services: [] | test_services: []
- boundary: signed gateway middleware fixture; not deployed host full mediation
- argv: `cargo test -p astral-common --test gateway_contract_tests --locked`
- started: 2026-10-09T10:56:18.824094+00:00 | finished: 2026-10-09T10:56:19.459086+00:00 | elapsed: 0.504s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 7, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/gateway-contracts.stdout.log` (sha256 48751008d6145a58b67e6de6da26dfcecc5605fa715c61f39cfdcdd1e201d842)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/gateway-contracts.stderr.log` (sha256 24967303f2a335ab999af337e47e62220814160acb2ac0e3d17f3fbc1938eee7)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 10. redis-free-config
- taskId: `e5-all-20261008-a11-v02:collection:redis-free-config`
- profile: native-kernel | scope: component | owner: testsuite | series: E4, M4
- production_services: [] | test_services: []
- boundary: AppConfig adapter capability assertion; not private composite startup validation
- argv: `cargo test -p testsuite --test premise_redis_free_composite --locked`
- started: 2026-10-09T10:56:19.590120+00:00 | finished: 2026-10-09T10:56:20.326053+00:00 | elapsed: 0.604s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 2, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/redis-free-config.stdout.log` (sha256 1985e32c0b087c954ee754715d9bd954f32ab2028904992e8818e0d4c45635e4)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/redis-free-config.stderr.log` (sha256 8d48e2a1a5dba15a8011eb7abcaccdee840b7a0327b8b884b0238da5b4ca6e1f)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 11. strict-policy-targets-check
- taskId: `e5-all-20261008-a11-v02:collection:strict-policy-targets-check`
- profile: native-kernel | scope: component | owner: policy-engine | series: CORE, PERF
- production_services: [] | test_services: []
- boundary: test and benchmark type checking; no measured performance data
- argv: `cargo check -p policy-engine --tests --benches --locked`
- started: 2026-10-09T10:56:20.459277+00:00 | finished: 2026-10-09T10:56:20.995375+00:00 | elapsed: 0.403s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: command
- actual_postcondition / reason: scoped command completed; see its component proof boundary
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/strict-policy-targets-check.stdout.log` (sha256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/strict-policy-targets-check.stderr.log` (sha256 46f64710a07ed53be45772a0f0a6f2a5c7ec2c48a3aed7cd667cd5fc9260ce21)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 12. native-lifecycle-build
- taskId: `e5-all-20261008-a11-v02:collection:native-lifecycle-build`
- profile: native-kernel | scope: component | owner: testsuite | series: CORE, M1, M2, M3
- production_services: [] | test_services: []
- boundary: compile the ignored MySQL lifecycle target only; no real integration run
- argv: `cargo check -p testsuite --test native_projection_lifecycle --locked`
- started: 2026-10-09T10:56:21.128267+00:00 | finished: 2026-10-09T10:56:21.917143+00:00 | elapsed: 0.654s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: command
- actual_postcondition / reason: scoped command completed; see its component proof boundary
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/native-lifecycle-build.stdout.log` (sha256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/native-lifecycle-build.stderr.log` (sha256 c54bca416b8a09e3c2018b0ada16771065b3b9b5469242539af42bc53077e2cf)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 13. native-lifecycle-cleanup-contract
- taskId: `e5-all-20261008-a11-v02:collection:native-lifecycle-cleanup-contract`
- profile: native-kernel | scope: component | owner: testsuite | series: CORE, E3, E4
- production_services: [] | test_services: []
- boundary: cleanup admission only; failure/timeout retains fixtures; no database integration
- argv: `cargo test -p testsuite --test native_projection_lifecycle cleanup_requires_successful_lifecycle_and_joined_owners --locked -- --exact --nocapture`
- started: 2026-10-09T10:56:22.049397+00:00 | finished: 2026-10-09T10:56:22.786917+00:00 | elapsed: 0.604s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 2}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/native-lifecycle-cleanup-contract.stdout.log` (sha256 11568bbe5959ce3cd4aa61940b50a6ec21368bbeed25d284d2099cf6e193746a)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/native-lifecycle-cleanup-contract.stderr.log` (sha256 bd8aa7766ffeb66ece3df2697c99853d0e22fa812bc1cb1af604d2e0131820b1)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 14. native-lifecycle-drain-contract
- taskId: `e5-all-20261008-a11-v02:collection:native-lifecycle-drain-contract`
- profile: native-kernel | scope: component | owner: testsuite | series: CORE, E3, E4
- production_services: [] | test_services: []
- boundary: bus occupancy wait requires empty count and byte budgets; no worker completion or database integration proof
- argv: `cargo test -p testsuite --test native_projection_lifecycle projection_bus_drain_wait_requires_empty_occupancy --locked -- --exact --nocapture`
- started: 2026-10-09T10:56:22.921044+00:00 | finished: 2026-10-09T10:56:23.811583+00:00 | elapsed: 0.755s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 2}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/native-lifecycle-drain-contract.stdout.log` (sha256 2f0385526f41330e4fcd9ac947ac95c488b50b8e358e96d16237122760ee0907)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/native-lifecycle-drain-contract.stderr.log` (sha256 59ea2d50789a8a1ed5403e3727f8a58f1675c23aa57e03e0c1f47fe2dd47cfe7)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 15. strict-benchmark-smoke
- taskId: `e5-all-20261008-a11-v02:collection:strict-benchmark-smoke`
- profile: native-kernel | scope: component | owner: policy-engine | series: CORE, PERF
- production_services: [] | test_services: []
- boundary: Criterion test mode verifies fixture decisions and setup only; no statistical timing
- argv: `cargo test -p policy-engine --bench policy_bench --bench tenant_isolation_bench --locked -- --test`
- started: 2026-10-09T10:56:23.944557+00:00 | finished: 2026-10-09T10:56:24.733090+00:00 | elapsed: 0.654s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: criterion-smoke
- actual_postcondition / reason: complete benchmark fixture smoke
- performance: fixture smoke only, cases 17
  - engine/published_ready_allow
  - engine/published_ready_empty_deny
  - engine/published_unavailable_pending
  - engine/published_ready_nonmatching_set
  - engine/published_tenant_gradient_32
  - condition/component_time_range
  - condition/component_ipv4_range
  - condition/component_scope
  - tenant_isolation/published_single_tenant_10_rules
  - tenant_isolation/published_concurrent_10_tenants
  - tenant_isolation/published_concurrent_50_tenants
  - tenant_isolation/published_concurrent_100_tenants
  - tenant_isolation/data_scope_resolve
  - tenant_isolation/data_scope_resolve_personal
  - tenant_isolation/published_cross_tenant_100x50
  - tenant_isolation/published_empty_deny
  - tenant_isolation/published_unavailable_pending
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/strict-benchmark-smoke.stdout.log` (sha256 fa9cf7e025a6d3c43dbc6133a730b47a668b8334d6615636a3d7ffd1450259b9)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/strict-benchmark-smoke.stderr.log` (sha256 b26f548cbaa982fe3c2b51ef43a3b3b9a3be8c63bb5fe4f902d2eefafebf3955)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 16. e2-pending-probe
- taskId: `e5-all-20261008-a11-v02:collection:e2-pending-probe`
- profile: native-kernel | scope: component | owner: astral-db | series: E2, M3
- production_services: [] | test_services: []
- boundary: pending_probe controlled omission; no live production bypass
- argv: `cargo test -p astral-db --lib evidence_cache::tests::e2_pending_probe_omission_accepts_stale_candidate_while_full_contract_reloads --locked -- --exact --nocapture`
- started: 2026-10-09T10:56:24.868014+00:00 | finished: 2026-10-09T10:56:25.551533+00:00 | elapsed: 0.554s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 858}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/e2-pending-probe.stdout.log` (sha256 740e287aa2c8bd7db6a69aa2e056b192ede7642b4c1c67c3cc5f491cb88a6a85)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/e2-pending-probe.stderr.log` (sha256 88d26dc748717dae0ab8922b301c568c1604812ba41ffb5e74205c2bd1b86a8b)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 17. e2-post-recheck
- taskId: `e5-all-20261008-a11-v02:collection:e2-post-recheck`
- profile: native-kernel | scope: component | owner: astral-db | series: E2, M3
- production_services: [] | test_services: []
- boundary: post_recheck cache bracket controlled omission
- argv: `cargo test -p astral-db --lib evidence_cache::tests::e2_post_recheck_omission_accepts_interleaving_while_full_contract_reloads --locked -- --exact --nocapture`
- started: 2026-10-09T10:56:25.682800+00:00 | finished: 2026-10-09T10:56:26.369912+00:00 | elapsed: 0.554s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 858}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/e2-post-recheck.stdout.log` (sha256 81cfc40b36b9ea14bc9cd32b3a7bc0f6cd6ac9310e3469343cfe99fbc566ab3b)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/e2-post-recheck.stderr.log` (sha256 88d26dc748717dae0ab8922b301c568c1604812ba41ffb5e74205c2bd1b86a8b)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 18. e2-final-reload
- taskId: `e5-all-20261008-a11-v02:collection:e2-final-reload`
- profile: native-kernel | scope: component | owner: policy-engine | series: E2, M3, M5
- production_services: [] | test_services: []
- boundary: final_reload exact controlled omission; candidate removal cannot survive reload
- argv: `cargo test -p policy-engine --lib engine::tests::e2_final_reload_omission_accepts_removed_candidate_while_full_contract_reloads --locked -- --exact --nocapture`
- started: 2026-10-09T10:56:26.502066+00:00 | finished: 2026-10-09T10:56:27.040058+00:00 | elapsed: 0.403s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 293}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/e2-final-reload.stdout.log` (sha256 7d244319a2847bf3a980b06ccab1bfe03fbae4699b2ff085efd83377269c2121)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/e2-final-reload.stderr.log` (sha256 88d424e160c06554a5bf6c1ef68054fc6ebcdd0a6e48a95c296f446d794a61c1)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 19. e2-exact-identity
- taskId: `e5-all-20261008-a11-v02:collection:e2-exact-identity`
- profile: native-kernel | scope: component | owner: policy-engine | series: E2, M3, M5
- production_services: [] | test_services: []
- boundary: exact_identity original candidate versus successor revision; no host bypass switch
- argv: `cargo test -p policy-engine --lib engine::tests::test_strict_successor_revision_cannot_replace_original_candidate --locked -- --exact --nocapture`
- started: 2026-10-09T10:56:27.171725+00:00 | finished: 2026-10-09T10:56:27.708497+00:00 | elapsed: 0.403s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 293}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/e2-exact-identity.stdout.log` (sha256 906bf3b1894307284383ec9c78be6588d2cebb8dbf22bca431c5b42d6c8b728e)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/e2-exact-identity.stderr.log` (sha256 88d424e160c06554a5bf6c1ef68054fc6ebcdd0a6e48a95c296f446d794a61c1)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 20. e2-generation-revoke-fence
- taskId: `e5-all-20261008-a11-v02:collection:e2-generation-revoke-fence`
- profile: native-kernel | scope: component | owner: astral-db | series: E2, M2, M3
- production_services: [] | test_services: []
- boundary: generation_revoke_fence controlled omission and stale candidate rejection
- argv: `cargo test -p astral-db --lib evidence_cache::tests::e2_generation_revoke_fence_omission_accepts_stale_candidate --locked -- --exact --nocapture`
- started: 2026-10-09T10:56:27.842743+00:00 | finished: 2026-10-09T10:56:28.526093+00:00 | elapsed: 0.554s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 858}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/e2-generation-revoke-fence.stdout.log` (sha256 6c3b52d59ace4d3bba04748a0988b92531aa381af93859a82a839d9513be0477)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/e2-generation-revoke-fence.stderr.log` (sha256 9fb0d0a05b18e7a9906740d335f2926ddeb9244e8a71e4f67c72e4d3e306a8d5)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 21. observability-feature-check
- taskId: `e5-all-20261008-a11-v02:collection:observability-feature-check`
- profile: native-kernel | scope: component | owner: astral-trustgraph | series: CORE, E1, E3, E4
- production_services: [] | test_services: []
- boundary: experiment feature target compilation only; no live fault or deployed observation proof
- argv: `cargo check -p astral-trustgraph --all-targets --features e1-observability,e3-observability,e4-observability --locked`
- started: 2026-10-09T10:56:28.656108+00:00 | finished: 2026-10-09T10:56:29.492358+00:00 | elapsed: 0.704s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: command
- actual_postcondition / reason: scoped command completed; see its component proof boundary
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/observability-feature-check.stdout.log` (sha256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/observability-feature-check.stderr.log` (sha256 0b9c85a57402765a9638848a90eec54abbd9a68f42a071a97aaa9d8acc5ba131)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 22. observability-feature-clippy
- taskId: `e5-all-20261008-a11-v02:collection:observability-feature-clippy`
- profile: native-kernel | scope: component | owner: astral-trustgraph | series: CORE, E1, E3, E4
- production_services: [] | test_services: []
- boundary: all-target lint for experiment features; no integration acceptance
- argv: `cargo clippy -p astral-trustgraph --all-targets --features e1-observability,e3-observability,e4-observability --locked -- -D warnings`
- started: 2026-10-09T10:56:29.625734+00:00 | finished: 2026-10-09T10:56:30.514340+00:00 | elapsed: 0.756s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: command
- actual_postcondition / reason: scoped command completed; see its component proof boundary
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/observability-feature-clippy.stdout.log` (sha256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/observability-feature-clippy.stderr.log` (sha256 deb6cb4a6c3e79707fe01a80013f10f53ed028864b8a94992b33872d11736be8)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 23. policy-observability-tests
- taskId: `e5-all-20261008-a11-v02:collection:policy-observability-tests`
- profile: native-kernel | scope: component | owner: policy-engine | series: E1, M5
- production_services: [] | test_services: []
- boundary: e1-observability library fixtures only; not a signed HTTP race
- argv: `cargo test -p policy-engine --lib --features e1-observability --locked`
- started: 2026-10-09T10:56:30.646487+00:00 | finished: 2026-10-09T10:56:31.634419+00:00 | elapsed: 0.856s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 295, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/policy-observability-tests.stdout.log` (sha256 de88a57d8f95ca894a1f9ec34c02e44ac19e7f8a8762e9a471e91741dc6325cb)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/policy-observability-tests.stderr.log` (sha256 edaa5668a6d38cd9a965c203b8ebd07d8b10bd4bb6a049c6525e67612605d23d)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 24. db-observability-tests
- taskId: `e5-all-20261008-a11-v02:collection:db-observability-tests`
- profile: native-kernel | scope: component | owner: astral-db | series: E1, M2, M3
- production_services: [] | test_services: []
- boundary: e1 evidence/observation fixtures; ignored integration/CPU checks not selected
- argv: `cargo test -p astral-db --lib --features e1-observability --locked`
- started: 2026-10-09T10:56:31.768024+00:00 | finished: 2026-10-09T10:58:45.574649+00:00 | elapsed: 133.672s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped non-ignored Rust assertions executed; ignored checks remain outside selection
- tests: {"passed": 857, "failed": 0, "ignored": 2, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/db-observability-tests.stdout.log` (sha256 6bbb9a809b28d3831cd4c93e393d9f891e312c4e7f83e7ed523f51a8f989b629)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/db-observability-tests.stderr.log` (sha256 1a503d465f751479628935ee48a466031bac8d3ceceb87449417889a0b7f9045)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 25. trustgraph-observability-tests
- taskId: `e5-all-20261008-a11-v02:collection:trustgraph-observability-tests`
- profile: native-kernel | scope: component | owner: astral-trustgraph | series: E1, E3, E4, M4
- production_services: [] | test_services: []
- boundary: local instrumented worker/reducer fixtures; not external fault injection
- argv: `cargo test -p astral-trustgraph --lib --features e1-observability,e3-observability,e4-observability --locked`
- started: 2026-10-09T10:58:45.708385+00:00 | finished: 2026-10-09T10:58:49.759443+00:00 | elapsed: 3.919s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped non-ignored Rust assertions executed; ignored checks remain outside selection
- tests: {"passed": 838, "failed": 0, "ignored": 5, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/trustgraph-observability-tests.stdout.log` (sha256 306f80470ed8898a1150fa078feaa78b16b192781af56677f9f83e75be40ecdd)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/trustgraph-observability-tests.stderr.log` (sha256 ea14b596db046b0e22b79713cf16c03ba949a04d4ad27b37dfa68bdaf0281d61)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 26. offline-validation-tools
- taskId: `e5-all-20261008-a11-v02:collection:offline-validation-tools`
- profile: offline-validation | scope: offline-model | owner: authorization-validation | series: E1, E2, E3, E4, E5, M4, M5
- production_services: [] | test_services: []
- boundary: standard-library unit/model/protocol fixtures; no actual fault injection or deployed decision proof
- argv: `python -B -m unittest discover -s Docs/authorization-validation/tools -p test_*.py`
- started: 2026-10-09T10:58:49.889288+00:00 | finished: 2026-10-09T11:14:54.382439+00:00 | elapsed: 964.36s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: unittest
- actual_postcondition / reason: offline Python assertions executed
- tests: {"executed": 502}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/offline-validation-tools.stdout.log` (sha256 cd292a49807e6ce6f3f3d9d8f7370e92880f7305e37db9dd612b4329af426d2d)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/offline-validation-tools.stderr.log` (sha256 e72b588200c34aa92e2ed5c5655c9be7124fe604f0e8ce46d50bd6ca338c7b22)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 27. e5-bounded-single
- taskId: `e5-all-20261008-a11-v02:collection:e5-bounded-single`
- profile: offline-validation | scope: offline-model | owner: authorization-validation | series: E5, M1, M2, M3, M5
- production_services: [] | test_services: []
- boundary: full abstract contract only; omission counterexamples are expected, not deployment failure
- argv: `python -B Docs/authorization-validation/tools/e5_model_check.py --max-steps 28 --json`
- started: 2026-10-09T11:14:54.514224+00:00 | finished: 2026-10-09T11:15:07.286824+00:00 | elapsed: 12.64s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: model-json
- actual_postcondition / reason: complete abstract contract; omission counterexamples are independent
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/e5-bounded-single.stdout.log` (sha256 a5fac8a38b13bc9909d5b1cecf36939c32e1d8a134a41139e1412f5e2c5517ad)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/e5-bounded-single.stderr.log` (sha256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 28. e5-bounded-two-mutations
- taskId: `e5-all-20261008-a11-v02:collection:e5-bounded-two-mutations`
- profile: offline-validation | scope: offline-model | owner: authorization-validation | series: E5, M1, M2, M3, M5
- production_services: [] | test_services: []
- boundary: two-mutation bounded abstract protocol; CLI emits JSON without a --json option
- argv: `python -B Docs/authorization-validation/tools/e5_model_check_two_mutations.py --workers 12`
- started: 2026-10-09T11:15:07.416601+00:00 | finished: 2026-10-09T11:29:43.307381+00:00 | elapsed: 875.757s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: model-json
- actual_postcondition / reason: complete abstract contract; omission counterexamples are independent
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/e5-bounded-two-mutations.stdout.log` (sha256 f7afbdccd62dc146e90c5c8b442cbf0364d23b2ab2c1fd7a3af76e08c83de491)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/e5-bounded-two-mutations.stderr.log` (sha256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 29. e5-universal-bounded
- taskId: `e5-all-20261008-a11-v02:collection:e5-universal-bounded`
- profile: offline-validation | scope: offline-model | owner: authorization-validation | series: E5, M1, M2, M3, M5
- production_services: [] | test_services: []
- boundary: universal hypotheses over the explicitly bounded abstract models, not unbounded system proof
- argv: `python -B Docs/authorization-validation/tools/universal_hypotheses_check.py --model both --workers 12 --json`
- started: 2026-10-09T11:29:43.438329+00:00 | finished: 2026-10-09T11:46:34.566132+00:00 | elapsed: 1010.992s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: model-json
- actual_postcondition / reason: U1-U10 complete for both bounded models; not deployment evidence
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/e5-universal-bounded.stdout.log` (sha256 17e8ef176fda0d2fec2132282892a714589331a8d464fd9d185d003e228c44a1)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/e5-universal-bounded.stderr.log` (sha256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 30. offline-tenant-model
- taskId: `e5-all-20261008-a11-v02:collection:offline-tenant-model`
- profile: offline-validation | scope: offline-model | owner: authorization-validation | series: E5, M3, MT-E1
- production_services: [] | test_services: []
- boundary: abstract tenant isolation hypotheses; no MySQL or policy runtime
- argv: `python -B Docs/authorization-validation/tools/tenant_isolation_model.py --json`
- started: 2026-10-09T11:46:34.697155+00:00 | finished: 2026-10-09T11:46:34.932576+00:00 | elapsed: 0.103s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: model-json
- actual_postcondition / reason: complete abstract hypothesis registry
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/offline-tenant-model.stdout.log` (sha256 8a2521c551571138f8ed240ac468cbaebe4bc3f2b3a3c6bc160b329214bba09c)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/offline-tenant-model.stderr.log` (sha256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 31. native-projection-lifecycle
- taskId: `e5-all-20261008-a11-v02:collection:native-projection-lifecycle`
- profile: native-single-node | scope: integration | owner: testsuite + astral-trustgraph | series: M1, M2, M3, E3, E4, RQ3
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: production source commit/local dispatch/publication pipeline/evaluate with worker owner; sync publisher attribution is not exclusive; not signed HTTP host campaign
- argv: `cargo test -p testsuite --test native_projection_lifecycle --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T11:46:35.065172+00:00 | finished: 2026-10-09T11:46:44.925396+00:00 | elapsed: 9.728s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 2}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/native-projection-lifecycle.stdout.log` (sha256 98bd896b8957368897ffeebe8bd7b1614e762a49ea0dc3d2d6189d2fb76fecab)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/native-projection-lifecycle.stderr.log` (sha256 cc914ca459d7121fa2ede996856ec5db5bbb3dc5fae89e7ed7d21809eef38eb3)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 32. db-authorization-projection
- taskId: `e5-all-20261008-a11-v02:collection:db-authorization-projection`
- profile: native-single-node | scope: integration | owner: astral-db | series: M1, M2, M3, E3, RQ3
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: durable projection/source/CAS/lineage tests; not complete deployed campaign
- argv: `cargo test -p astral-db --test authorization_projection_integration --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T11:46:45.058221+00:00 | finished: 2026-10-09T11:47:10.109613+00:00 | elapsed: 24.922s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 10, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/db-authorization-projection.stdout.log` (sha256 b6693cc8f9763b6a2a6c352e5e4679a2b89f3a59899728f4408c65956856f929)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/db-authorization-projection.stderr.log` (sha256 c01a371179096ef4cca66ca5dce1b3388ad7143820743761c85ffe2e7382936a)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 33. db-integration
- taskId: `e5-all-20261008-a11-v02:collection:db-integration`
- profile: native-single-node | scope: integration | owner: astral-db | series: CORE, M1, M3
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: real MySQL repository contracts and legacy no-fallback guards
- argv: `cargo test -p astral-db --test integration --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T11:47:10.241803+00:00 | finished: 2026-10-09T11:47:15.841883+00:00 | elapsed: 5.467s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 2, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/db-integration.stdout.log` (sha256 e0a92d300218994a087ef6711da148dd8c806bf8ed548c08c2f3ba0350070ded)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/db-integration.stderr.log` (sha256 ff9ad66dc988fccd9473c1a6239aeffd52704ecef2c16828f7d26bd09c2c5b98)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 34. db-tenant-isolation
- taskId: `e5-all-20261008-a11-v02:collection:db-tenant-isolation`
- profile: native-single-node | scope: integration | owner: astral-db | series: M3, MT-E1
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: three-tenant SQL binding and retired snapshot guards
- argv: `cargo test -p astral-db --test multi_tenant_isolation --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T11:47:15.975559+00:00 | finished: 2026-10-09T11:47:34.156666+00:00 | elapsed: 18.051s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 7, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/db-tenant-isolation.stdout.log` (sha256 5c1b64928618c424bf2bd5a0dd06fc17f37d06fbb8cc4f7b8c4a130c5d424db0)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/db-tenant-isolation.stderr.log` (sha256 6d81fdb55d3582c73c981ede35b138cace1425dceb6284485a719a2d77c4b929)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 35. db-org-scope
- taskId: `e5-all-20261008-a11-v02:collection:db-org-scope`
- profile: native-single-node | scope: integration | owner: astral-db | series: M2, M3, MT-E1
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: organization topology/evidence contracts; production ORG_SCOPE default remains off
- argv: `cargo test -p astral-db --test org_scope_integration --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T11:47:34.285142+00:00 | finished: 2026-10-09T11:48:13.676118+00:00 | elapsed: 39.26s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 15, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/db-org-scope.stdout.log` (sha256 04ccece61cc79fdb3e6b30f8f9ca079415d629e7b4f9fdd95d95d87067afe6c8)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/db-org-scope.stderr.log` (sha256 45bfb9e4d5766362ff128b3eafad4e00715f7e2b798a8b4ef57804719828cdff)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 36. db-partition-lease
- taskId: `e5-all-20261008-a11-v02:collection:db-partition-lease`
- profile: native-single-node | scope: integration | owner: astral-db | series: M2, E3, E4
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: durable partition ownership/CAS/reclaim contracts
- argv: `cargo test -p astral-db --test partition_lease_integration --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T11:48:13.807260+00:00 | finished: 2026-10-09T11:48:17.501240+00:00 | elapsed: 3.563s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 7, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/db-partition-lease.stdout.log` (sha256 06ee061c5c0fcc98b7662c589eb69be5f64fd4c50cef196c49730594570cf1a2)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/db-partition-lease.stderr.log` (sha256 c1d17852ab980d15343b3a37d97248ee47b7ac5a72d6b362bf1af0f5a0f80f25)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 37. db-quarantine
- taskId: `e5-all-20261008-a11-v02:collection:db-quarantine`
- profile: native-single-node | scope: integration | owner: astral-db | series: M4, E3, E4
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: real durable quarantine terminal and retry boundaries
- argv: `cargo test -p astral-db --test quarantine_integration --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T11:48:17.631429+00:00 | finished: 2026-10-09T11:48:24.837199+00:00 | elapsed: 7.074s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 7, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/db-quarantine.stdout.log` (sha256 94641eb4503e184fd602a7bb54440f9ab8e8edd48b570b43b60c47ab16892486)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/db-quarantine.stderr.log` (sha256 a83d7d1811e4720fad65911e8fb260ed80edf8dce12c166600ea11c0265b8f92)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 38. identity-integration
- taskId: `e5-all-20261008-a11-v02:collection:identity-integration`
- profile: native-single-node | scope: integration | owner: astral-identity | series: CORE, M5
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: real identity/session/card contracts; no legacy role bypass
- argv: `cargo test -p astral-identity --test integration --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T11:48:24.970013+00:00 | finished: 2026-10-09T11:48:26.106775+00:00 | elapsed: 1.005s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 8, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/identity-integration.stdout.log` (sha256 0af1b541be3b3c3ecdc8abbc3f7e3fb1b447cc2cefbce1c87d92ce80c06ce38c)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/identity-integration.stderr.log` (sha256 42c54867ca92736498bd7e65a9b188a804f5e41bb8e4aff65682da55f6f084bc)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 39. trustgraph-integration
- taskId: `e5-all-20261008-a11-v02:collection:trustgraph-integration`
- profile: native-single-node | scope: integration | owner: astral-trustgraph | series: CORE, M1, M2, M3
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: source repository and cascade fail-closed contracts with production origin region
- argv: `cargo test -p astral-trustgraph --test integration --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T11:48:26.240655+00:00 | finished: 2026-10-09T11:48:27.226965+00:00 | elapsed: 0.855s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 11, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/trustgraph-integration.stdout.log` (sha256 cd939fb7b0419fb44e8a9530bb37d408ba663593993208e6822d92fdb3b8bdd4)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/trustgraph-integration.stderr.log` (sha256 59463cfe9925de643baaa005fe15a034130a1717292cfc36d56f34656784fb35)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 40. trustgraph-org-projector
- taskId: `e5-all-20261008-a11-v02:collection:trustgraph-org-projector`
- profile: native-single-node | scope: integration | owner: astral-trustgraph | series: M2, E3
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: real dual-worker competition and organization projection contracts
- argv: `cargo test -p astral-trustgraph --test org_scope_projector_integration --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T11:48:27.358258+00:00 | finished: 2026-10-09T11:48:30.602099+00:00 | elapsed: 3.111s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/trustgraph-org-projector.stdout.log` (sha256 30745b76cf165e1347588bcb76e2d7d3719ccfeab68d430559ff37d9e38773da)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/trustgraph-org-projector.stderr.log` (sha256 b05058d2ff8a4ae970cd9e1b0dcd30856b97b1b2db2eb831c19c2ef1b109f6b1)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 41. monitor-integration
- taskId: `e5-all-20261008-a11-v02:collection:monitor-integration`
- profile: native-single-node | scope: integration | owner: astral-monitor | series: CORE
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: monitor database contracts; no tenant-isolation claim
- argv: `cargo test -p astral-monitor --test integration --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T11:48:30.735790+00:00 | finished: 2026-10-09T11:48:31.673355+00:00 | elapsed: 0.805s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 5, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/monitor-integration.stdout.log` (sha256 50ded6d7dc0880ac9cb74766999aef3dc803c142cce3a2df6262a248620bbac9)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/monitor-integration.stderr.log` (sha256 1f8b615610c6862f985ebe19ff56f1ec631a5345791b228f3cc153bd88103e10)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 42. hub-invalidation-premise
- taskId: `e5-all-20261008-a11-v02:collection:hub-invalidation-premise`
- profile: native-single-node | scope: integration | owner: testsuite | series: M3, E4
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: commit-proven publication mirror and invalidation freshness gate; not whole source/worker lifecycle
- argv: `cargo test -p testsuite --test premise_hub_invalidation --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T11:48:31.806117+00:00 | finished: 2026-10-09T11:48:34.949039+00:00 | elapsed: 3.011s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/hub-invalidation-premise.stdout.log` (sha256 ff6ccb658efd2070186785d1588a9d0e7852a8a8c6269408a295e6a1b7297314)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/hub-invalidation-premise.stderr.log` (sha256 9da1f9c8546781acc08d4b8187190e5c1dacc551ad9f07a742d17ee9fa905907)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 43. single-writer-premise
- taskId: `e5-all-20261008-a11-v02:collection:single-writer-premise`
- profile: native-single-node | scope: integration | owner: testsuite | series: M2, E4
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: same-session MySQL advisory lock, explicit close and bounded reacquisition
- argv: `cargo test -p testsuite --test premise_single_writer_lease --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T11:48:35.080791+00:00 | finished: 2026-10-09T11:48:38.226138+00:00 | elapsed: 3.011s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/single-writer-premise.stdout.log` (sha256 8822845d4736c14db156a66ab90c0f48cc2e3b583d75abf17e4d3e4965c12fd1)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/single-writer-premise.stderr.log` (sha256 8a9c4ed1dd9cdf4bd5f9d0809e2815dc2d4eb04243e685ac068ffc3a8aeb068c)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 44. identity-mapping-premise
- taskId: `e5-all-20261008-a11-v02:collection:identity-mapping-premise`
- profile: native-single-node | scope: integration | owner: testsuite | series: M5, E4
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: real mapping/app_id isolation and absent mapping refusal; exact-byte MySQL ENUM decoding with strict schema validation
- argv: `cargo test -p testsuite --test premise_identity_mapping --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T11:48:38.359096+00:00 | finished: 2026-10-09T11:48:43.961587+00:00 | elapsed: 5.467s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 2, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/identity-mapping-premise.stdout.log` (sha256 82553395908e733fd6fe4cdb655f642c55fa3fd5c0c139648401225eb726e956)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/identity-mapping-premise.stderr.log` (sha256 9c2400605660783aeeec22e3ff9fe20ee480ead6362a5a25cadb2e4013598de9)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 45. dedicated-identity-mapping
- taskId: `e5-all-20261008-a11-v02:collection:dedicated-identity-mapping`
- profile: native-single-node | scope: integration | owner: astral-db | series: M5, E4
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: dedicated sdk_identity_mapping_test_* migrated database; guard is not relaxed
- argv: `cargo test -p astral-db --test integration_identity_mapping --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T11:48:44.093196+00:00 | finished: 2026-10-09T11:48:44.980251+00:00 | elapsed: 0.754s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 2, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/dedicated-identity-mapping.stdout.log` (sha256 ae6a6cbaf5274188d10aa474e7723129685da6858339542c28e391beb804640a)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/dedicated-identity-mapping.stderr.log` (sha256 0c5b42fd80b93962bab94c0b6e3438a1038e10112718d321e93f0dc67b2b0ef6)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 46. mt-isolation
- taskId: `e5-all-20261008-a11-v02:collection:mt-isolation`
- profile: native-single-node | scope: integration | owner: testsuite | series: MT-E1, M3, RQ2
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: tenant-scoped canonical publication/evidence isolation; not HTTP performance
- argv: `cargo test -p testsuite --test mt_extreme_isolation --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T11:48:45.115368+00:00 | finished: 2026-10-09T11:48:51.268999+00:00 | elapsed: 6.019s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/mt-isolation.stdout.log` (sha256 64ea302da91b5784ca00bce1aff06eb6f192f229df59295f2799c14d55426c50)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/mt-isolation.stderr.log` (sha256 581f49960ade9547fc5b65f473688193d87c45d1543d0ad10c5e0e4905a2fb82)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 47. mt-churn
- taskId: `e5-all-20261008-a11-v02:collection:mt-churn`
- profile: native-single-node | scope: integration | owner: testsuite | series: MT-E3, M2, RQ3, RQ4
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: successive CAS pointer add/revoke/restore generations; not three-node propagation
- argv: `cargo test -p testsuite --test mt_extreme_churn --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T11:48:51.420014+00:00 | finished: 2026-10-09T11:48:55.566658+00:00 | elapsed: 4.013s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/mt-churn.stdout.log` (sha256 5008cbd59767744700d92204f0b6abd5127d8f124df0e46a0c8e0aa363ebf64c)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/mt-churn.stderr.log` (sha256 ec9bd29991605ac553913fb1d4f21bc7057939a2d6b9b2655d30203ac319259c)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 48. mt-cross-storm
- taskId: `e5-all-20261008-a11-v02:collection:mt-cross-storm`
- profile: native-single-node | scope: integration | owner: testsuite | series: MT-E4, M3, RQ4
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: cross-tenant invalidation/evidence fixture; not a distributed message storm
- argv: `cargo test -p testsuite --test mt_extreme_cross_storm --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T11:48:55.697913+00:00 | finished: 2026-10-09T11:48:59.444218+00:00 | elapsed: 3.611s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/mt-cross-storm.stdout.log` (sha256 9817c59eb7c551f6a24494b06eb13fb6536b75d6ca316187eb574e97594916f7)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/mt-cross-storm.stderr.log` (sha256 43fa6f946263151f9e279cfb5ecc7ed203c7b7342779c29d64fb999e2c20fad5)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 49. mt-capacity
- taskId: `e5-all-20261008-a11-v02:collection:mt-capacity`
- profile: native-single-node | scope: integration | owner: testsuite | series: MT-E5, RQ2
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: bounded MySQL tenant/card capacity; not engine/HTTP throughput
- argv: `cargo test -p testsuite --test mt_extreme_capacity --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T11:48:59.576810+00:00 | finished: 2026-10-09T11:49:14.146664+00:00 | elapsed: 14.438s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/mt-capacity.stdout.log` (sha256 b2b5fbb3b600553d1e9ed75e6f9d57aac8d45e76f9215a7f6e20416c1cdfee5b)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/mt-capacity.stderr.log` (sha256 9f4af20440a3bd2b6f6f0c2296883f704ac1fb051520057229186a5175f34003)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 50. mt-failclosed
- taskId: `e5-all-20261008-a11-v02:collection:mt-failclosed`
- profile: native-single-node | scope: integration | owner: testsuite | series: MT-E6, M3, M4, E4
- production_services: ['mysql'] | test_services: ['mysql']
- boundary: typed NotReady/Pending, no arbitrary database-error-as-denial acceptance
- argv: `cargo test -p testsuite --test mt_extreme_failclosed --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T11:49:14.280164+00:00 | finished: 2026-10-09T11:49:17.725499+00:00 | elapsed: 3.312s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/mt-failclosed.stdout.log` (sha256 78de7a363340ef0fc4e1ab87b2d989a91fe731f6047cb99b2e32e0f1279aa4e1)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/mt-failclosed.stderr.log` (sha256 3020a1dafb260ac431db76a18fd97dbb145171a9118142eee2bd02cd8e49eadc)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RUST_INTEGRATION_REQUIRED

### 51. rabbit-audit-replay
- taskId: `e5-all-20261008-a11-v02:collection:rabbit-audit-replay`
- profile: standalone-rabbit | scope: integration | owner: astral-trustgraph | series: M1, M2, E3, E4
- production_services: ['mysql', 'rabbitmq'] | test_services: ['mysql', 'rabbitmq']
- boundary: real Rabbit confirm + MySQL mq_idempotent_log/audit_log/completed lease; no Redis
- argv: `cargo test -p astral-trustgraph --test audit_replay_integration --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T11:49:17.857191+00:00 | finished: 2026-10-09T11:49:23.256237+00:00 | elapsed: 5.268s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 3}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/rabbit-audit-replay.stdout.log` (sha256 4f4fa4aa28929d3ca1bca16ce4a38e4efa2a36353f54d53f93a8c621756f2f33)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/rabbit-audit-replay.stderr.log` (sha256 8e6fb45d68b90edb7afe07ac9eb4071eb644387f9e96f1a3a6909b1488a635ed)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, RABBITMQ_URL, RUST_INTEGRATION_REQUIRED

### 52. redis-evidence-compat
- taskId: `e5-all-20261008-a11-v02:collection:redis-evidence-compat`
- profile: redis-compat | scope: integration | owner: astral-db | series: COMPAT, E4
- production_services: ['mysql', 'redis'] | test_services: ['mysql', 'redis']
- boundary: explicit adapter window only; cannot establish native evidence path acceptance
- argv: `cargo test -p astral-db --features redis-compat --test evidence_cache_redis_integration --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T11:49:23.388543+00:00 | finished: 2026-10-09T11:49:58.523321+00:00 | elapsed: 35.001s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 25, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/redis-evidence-compat.stdout.log` (sha256 5fa80cc735fcbe49f3b8309b58a986af0cb7da995a97fa7b525ede10c1ce2b95)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/redis-evidence-compat.stderr.log` (sha256 69ef0ecbe418b72c7c658c07f63f94fd5bc939d84664b34ab2c7e1eae5dc569c)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_MIGRATION_ENV, ASTRAL_REDIS_PROJECTION_COMPAT, ASTRAL_TEST_DATABASE_NAME, DATABASE_URL, REDIS_URL, RUST_INTEGRATION_REQUIRED

### 53. strict-policy-benchmark
- taskId: `e5-all-20261008-a11-v02:collection:strict-policy-benchmark`
- profile: performance-kernel | scope: component | owner: policy-engine | series: PERF, RQ1, RQ5
- production_services: [] | test_services: []
- boundary: strict fixture decision and condition CPU timing, preasserted ALLOW/DENY/PENDING; no MySQL/HTTP
- argv: `cargo bench -p policy-engine --bench policy_bench --locked -- --color never`
- started: 2026-10-09T11:49:58.655690+00:00 | finished: 2026-10-09T11:51:29.709769+00:00 | elapsed: 90.919s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: criterion
- actual_postcondition / reason: complete measured CPU Criterion cases; no HTTP/DB claim
- performance: CPU component only, cases 8
  - engine/published_ready_allow
  - engine/published_ready_empty_deny
  - engine/published_unavailable_pending
  - engine/published_ready_nonmatching_set
  - engine/published_tenant_gradient_32
  - condition/component_time_range
  - condition/component_ipv4_range
  - condition/component_scope
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/strict-policy-benchmark.stdout.log` (sha256 76e465f42dbee8ed9211c331d48b9f85b4cd48d5478fe18f3769a4f96e071424)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/strict-policy-benchmark.stderr.log` (sha256 d72ba278de2fcc3d6d69438b1eb7fa734276d6c67969c48c48ae31889c7274a9)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 54. strict-tenant-benchmark
- taskId: `e5-all-20261008-a11-v02:collection:strict-tenant-benchmark`
- profile: performance-kernel | scope: component | owner: policy-engine | series: PERF, RQ2, RQ5, MT-E1
- production_services: [] | test_services: []
- boundary: strict scope-aware positive identities and checked join/decisions; CPU-only
- argv: `cargo bench -p policy-engine --bench tenant_isolation_bench --locked -- --color never`
- started: 2026-10-09T11:51:29.841661+00:00 | finished: 2026-10-09T11:53:01.899571+00:00 | elapsed: 91.925s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: criterion
- actual_postcondition / reason: complete measured CPU Criterion cases; no HTTP/DB claim
- performance: CPU component only, cases 9
  - tenant_isolation/published_single_tenant_10_rules
  - tenant_isolation/published_concurrent_10_tenants
  - tenant_isolation/published_concurrent_50_tenants
  - tenant_isolation/published_concurrent_100_tenants
  - tenant_isolation/data_scope_resolve
  - tenant_isolation/data_scope_resolve_personal
  - tenant_isolation/published_cross_tenant_100x50
  - tenant_isolation/published_empty_deny
  - tenant_isolation/published_unavailable_pending
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/strict-tenant-benchmark.stdout.log` (sha256 a962366adc2b87a093b414c6058ff6518c5e87d04f84c7fbde8f74ec3d16f3f6)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/strict-tenant-benchmark.stderr.log` (sha256 ef464f08566e71de8a50077ec0ab22f255a2ce5c43bc6d90ccb930c3a020856d)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 55. compiler-benchmark
- taskId: `e5-all-20261008-a11-v02:collection:compiler-benchmark`
- profile: performance-kernel | scope: component | owner: policy-engine | series: PERF, RQ2, RQ3
- production_services: [] | test_services: []
- boundary: production compiler incremental/full parity, exact/wildcard/multi-delta CPU benchmark
- argv: `cargo bench -p policy-engine --bench authorization_compiler_bench --locked -- --color never`
- started: 2026-10-09T11:53:02.031121+00:00 | finished: 2026-10-09T11:58:20.759730+00:00 | elapsed: 318.594s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: criterion
- actual_postcondition / reason: complete measured CPU Criterion cases; no HTTP/DB claim
- performance: CPU component only, cases 30
  - compiler/incremental_exact_add/n=100
  - compiler/full_exact_add/n=100
  - compiler/incremental_exact_remove/n=100
  - compiler/full_exact_remove/n=100
  - compiler/incremental_windowed_add/n=100
  - compiler/full_windowed_add/n=100
  - compiler/incremental_wildcard_add/n=100
  - compiler/full_wildcard_add/n=100
  - compiler/batch50_incremental/n=100
  - compiler/batch50_full/n=100
  - compiler/incremental_exact_add/n=1000
  - compiler/full_exact_add/n=1000
  - compiler/incremental_exact_remove/n=1000
  - compiler/full_exact_remove/n=1000
  - compiler/incremental_windowed_add/n=1000
  - compiler/full_windowed_add/n=1000
  - compiler/incremental_wildcard_add/n=1000
  - compiler/full_wildcard_add/n=1000
  - compiler/batch50_incremental/n=1000
  - compiler/batch50_full/n=1000
  - compiler/incremental_exact_add/n=4050
  - compiler/full_exact_add/n=4050
  - compiler/incremental_exact_remove/n=4050
  - compiler/full_exact_remove/n=4050
  - compiler/incremental_windowed_add/n=4050
  - compiler/full_windowed_add/n=4050
  - compiler/incremental_wildcard_add/n=4050
  - compiler/full_wildcard_add/n=4050
  - compiler/batch50_incremental/n=4050
  - compiler/batch50_full/n=4050
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/compiler-benchmark.stdout.log` (sha256 2e22195e0bb48827fa8dd34a67d8d2e8357f2afca379e1c54342eb4327f8ed4b)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/compiler-benchmark.stderr.log` (sha256 38d454429586efe09095ac4379c719c3ea5114ed630c66b75be371448a34691e)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 56. compiler-allocation-contracts
- taskId: `e5-all-20261008-a11-v02:collection:compiler-allocation-contracts`
- profile: performance-kernel | scope: component | owner: policy-engine | series: PERF, RQ2, RQ3
- production_services: [] | test_services: []
- boundary: compiler allocation contract assertions, not service capacity
- argv: `cargo test -p policy-engine --test authorization_compiler_alloc --locked`
- started: 2026-10-09T11:58:20.891406+00:00 | finished: 2026-10-09T11:58:22.781721+00:00 | elapsed: 1.757s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: scoped Rust assertions executed
- tests: {"passed": 4, "failed": 0, "ignored": 0, "measured": 0, "filtered": 0}
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/compiler-allocation-contracts.stdout.log` (sha256 8168aff4b382104c0b979c939f87a3e7c5229b7b624fc745911fa794db78bce7)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/compiler-allocation-contracts.stderr.log` (sha256 43b3a0ca5ddc0b067ed6232b3fdfb75a20ca89543f6c6c4a48bca91e128fe828)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 57. compiler-allocation-benchmark
- taskId: `e5-all-20261008-a11-v02:collection:compiler-allocation-benchmark`
- profile: performance-kernel | scope: component | owner: policy-engine | series: PERF, RQ2, RQ3
- production_services: [] | test_services: []
- boundary: production compiler allocation microbenchmark; no external services
- argv: `cargo bench -p policy-engine --bench authorization_compiler_alloc --locked`
- started: 2026-10-09T11:58:22.914821+00:00 | finished: 2026-10-09T11:58:38.102009+00:00 | elapsed: 15.055s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: divan
- actual_postcondition / reason: complete CPU allocation benchmark; no service-capacity claim
- performance: CPU/allocation component only; instrumented timing, cases 6
  - private_add_grant
  - private_build
  - shared_add_grant
  - shared_build
  - shared_clone
  - shared_entry_count_proof
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/compiler-allocation-benchmark.stdout.log` (sha256 34fde660e661210170d30c899e361f8384d12a08867e89fd527640a53bceb262)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/compiler-allocation-benchmark.stderr.log` (sha256 0261548b54c4607b172ca7a0dcf4a4c89879fd8f863c5499a01098c90dcb6faa)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 58. memory-hub-performance
- taskId: `e5-all-20261008-a11-v02:collection:memory-hub-performance`
- profile: performance-kernel | scope: component | owner: astral-db | series: PERF, RQ5
- production_services: [] | test_services: []
- boundary: CPU evidence read matrix: cold/hot/token/clock/concurrency/pressure; not SQL/HTTP latency
- argv: `cargo test -p astral-db --lib memory_evidence_no_regression_matrix --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T11:58:38.232647+00:00 | finished: 2026-10-09T12:04:04.432728+00:00 | elapsed: 326.065s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: complete CPU performance matrix measured; no HTTP/DB claim
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 858}
- performance: CPU component only, cases 82
  - case `evidence/1/cold/validate-false`
  - case `evidence/1/cold/validate-true`
  - case `evidence/1/hot-fixed/validate-false`
  - case `evidence/1/hot-fixed/validate-true`
  - case `evidence/1/cross-second/validate-false`
  - case `evidence/1/cross-second/validate-true`
  - case `evidence/1/token-change/validate-false`
  - case `evidence/1/token-change/validate-true`
  - case `evidence/1/real-clock/validate-false`
  - case `evidence/1/real-clock/validate-true`
  - case `evidence/8/cold/validate-false`
  - case `evidence/8/cold/validate-true`
  - case `evidence/8/hot-fixed/validate-false`
  - case `evidence/8/hot-fixed/validate-true`
  - case `evidence/8/cross-second/validate-false`
  - case `evidence/8/cross-second/validate-true`
  - case `evidence/8/token-change/validate-false`
  - case `evidence/8/token-change/validate-true`
  - case `evidence/8/real-clock/validate-false`
  - case `evidence/8/real-clock/validate-true`
  - case `evidence/128/cold/validate-false`
  - case `evidence/128/cold/validate-true`
  - case `evidence/128/hot-fixed/validate-false`
  - case `evidence/128/hot-fixed/validate-true`
  - case `evidence/128/cross-second/validate-false`
  - case `evidence/128/cross-second/validate-true`
  - case `evidence/128/token-change/validate-false`
  - case `evidence/128/token-change/validate-true`
  - case `evidence/128/real-clock/validate-false`
  - case `evidence/128/real-clock/validate-true`
  - case `evidence/512/cold/validate-false`
  - case `evidence/512/cold/validate-true`
  - case `evidence/512/hot-fixed/validate-false`
  - case `evidence/512/hot-fixed/validate-true`
  - case `evidence/512/cross-second/validate-false`
  - case `evidence/512/cross-second/validate-true`
  - case `evidence/512/token-change/validate-false`
  - case `evidence/512/token-change/validate-true`
  - case `evidence/512/real-clock/validate-false`
  - case `evidence/512/real-clock/validate-true`
  - case `evidence/2048/cold/validate-false`
  - case `evidence/2048/cold/validate-true`
  - case `evidence/2048/hot-fixed/validate-false`
  - case `evidence/2048/hot-fixed/validate-true`
  - case `evidence/2048/cross-second/validate-false`
  - case `evidence/2048/cross-second/validate-true`
  - case `evidence/2048/token-change/validate-false`
  - case `evidence/2048/token-change/validate-true`
  - case `evidence/2048/real-clock/validate-false`
  - case `evidence/2048/real-clock/validate-true`
  - case `concurrent/1/threads-1/staggered-false/real-false`
  - case `concurrent/1/threads-1/staggered-false/real-true`
  - case `concurrent/1/threads-1/staggered-true/real-false`
  - case `concurrent/1/threads-1/staggered-true/real-true`
  - case `concurrent/1/threads-4/staggered-false/real-false`
  - case `concurrent/1/threads-4/staggered-false/real-true`
  - case `concurrent/1/threads-4/staggered-true/real-false`
  - case `concurrent/1/threads-4/staggered-true/real-true`
  - case `concurrent/1/threads-8/staggered-false/real-false`
  - case `concurrent/1/threads-8/staggered-false/real-true`
  - case `concurrent/1/threads-8/staggered-true/real-false`
  - case `concurrent/1/threads-8/staggered-true/real-true`
  - case `concurrent/512/threads-1/staggered-false/real-false`
  - case `concurrent/512/threads-1/staggered-false/real-true`
  - case `concurrent/512/threads-1/staggered-true/real-false`
  - case `concurrent/512/threads-1/staggered-true/real-true`
  - case `concurrent/512/threads-4/staggered-false/real-false`
  - case `concurrent/512/threads-4/staggered-false/real-true`
  - case `concurrent/512/threads-4/staggered-true/real-false`
  - case `concurrent/512/threads-4/staggered-true/real-true`
  - case `concurrent/512/threads-8/staggered-false/real-false`
  - case `concurrent/512/threads-8/staggered-false/real-true`
  - case `concurrent/512/threads-8/staggered-true/real-false`
  - case `concurrent/512/threads-8/staggered-true/real-true`
  - case `pressure/64/hot-cold-false`
  - case `pressure/64/hot-cold-true`
  - case `pressure/512/hot-cold-false`
  - case `pressure/512/hot-cold-true`
  - case `pressure/1000/hot-cold-false`
  - case `pressure/1000/hot-cold-true`
  - case `pressure/1100/hot-cold-false`
  - case `pressure/1100/hot-cold-true`
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/memory-hub-performance.stdout.log` (sha256 558c859a60b0ec3d340ab2ca2e8d60b6e47eab9db4cb029a4cb894541a491a94)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/memory-hub-performance.stderr.log` (sha256 88d26dc748717dae0ab8922b301c568c1604812ba41ffb5e74205c2bd1b86a8b)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 59. stage-plan-performance
- taskId: `e5-all-20261008-a11-v02:collection:stage-plan-performance`
- profile: performance-kernel | scope: component | owner: astral-trustgraph | series: PERF, RQ3
- production_services: [] | test_services: []
- boundary: CPU complete stage-plan matrix; no durable projector throughput claim
- argv: `cargo test -p astral-trustgraph --lib complete_stage_plan_no_regression_matrix --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T12:04:04.568478+00:00 | finished: 2026-10-09T12:07:12.648607+00:00 | elapsed: 187.94s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: complete CPU performance matrix measured; no HTTP/DB claim
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 842}
- performance: CPU component only, cases 15
  - case `stage/1/hit`
  - case `stage/1/miss`
  - case `stage/1/duplicate`
  - case `stage/8/hit`
  - case `stage/8/miss`
  - case `stage/8/duplicate`
  - case `stage/128/hit`
  - case `stage/128/miss`
  - case `stage/128/duplicate`
  - case `stage/512/hit`
  - case `stage/512/miss`
  - case `stage/512/duplicate`
  - case `stage/2048/hit`
  - case `stage/2048/miss`
  - case `stage/2048/duplicate`
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/stage-plan-performance.stdout.log` (sha256 b312360d5be6f6a7cb9f57d61413603013083a132dfea03253399d90e23be36e)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/stage-plan-performance.stderr.log` (sha256 91d6bb8975af3a2fb0943a2bbb69a996a522943d9d63360370155d6ecfd8fe4a)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

### 60. parent-lookup-performance
- taskId: `e5-all-20261008-a11-v02:collection:parent-lookup-performance`
- profile: performance-kernel | scope: component | owner: astral-trustgraph | series: PERF, RQ3
- production_services: [] | test_services: []
- boundary: CPU stable-parent-ordinal lookup matrix; no SQL/worker throughput claim
- argv: `cargo test -p astral-trustgraph --lib parent_lookup_no_regression_matrix --locked -- --ignored --nocapture --test-threads=1`
- started: 2026-10-09T12:07:12.784123+00:00 | finished: 2026-10-09T12:08:49.399247+00:00 | elapsed: 96.477s | retries: 0
- exit_code: 0 | status: **PASS** | expected_postcondition: rust
- actual_postcondition / reason: complete CPU performance matrix measured; no HTTP/DB claim
- tests: {"passed": 1, "failed": 0, "ignored": 0, "measured": 0, "filtered": 842}
- performance: CPU component only, cases 40
  - case `lookup/0/hit`
  - case `lookup/0/miss`
  - case `lookup/0/mixed`
  - case `lookup/0/duplicate`
  - case `lookup/1/hit`
  - case `lookup/1/miss`
  - case `lookup/1/mixed`
  - case `lookup/1/duplicate`
  - case `lookup/8/hit`
  - case `lookup/8/miss`
  - case `lookup/8/mixed`
  - case `lookup/8/duplicate`
  - case `lookup/32/hit`
  - case `lookup/32/miss`
  - case `lookup/32/mixed`
  - case `lookup/32/duplicate`
  - case `lookup/64/hit`
  - case `lookup/64/miss`
  - case `lookup/64/mixed`
  - case `lookup/64/duplicate`
  - case `lookup/128/hit`
  - case `lookup/128/miss`
  - case `lookup/128/mixed`
  - case `lookup/128/duplicate`
  - case `lookup/256/hit`
  - case `lookup/256/miss`
  - case `lookup/256/mixed`
  - case `lookup/256/duplicate`
  - case `lookup/512/hit`
  - case `lookup/512/miss`
  - case `lookup/512/mixed`
  - case `lookup/512/duplicate`
  - case `lookup/2048/hit`
  - case `lookup/2048/miss`
  - case `lookup/2048/mixed`
  - case `lookup/2048/duplicate`
  - case `lookup/imbalanced-1-2048-tail-false`
  - case `lookup/imbalanced-1-2048-tail-true`
  - case `lookup/imbalanced-8-2048-tail-false`
  - case `lookup/imbalanced-2048-8-tail-true`
- log_integrity: complete | stream_disconnect: False
- stdout: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/parent-lookup-performance.stdout.log` (sha256 5ebbc2de8665cab62763318af3db71ae55e9caf8cee4365649ffd89110bc63d9)
- stderr: `/home/astrallight/astral-test-runs/e5-all-20261008-a11-evidence/runs/e5-all-20261008-a11-v02/collection/parent-lookup-performance.stderr.log` (sha256 91d6bb8975af3a2fb0943a2bbb69a996a522943d9d63360370155d6ecfd8fe4a)
- environment_names: ASTRAL_MESSAGE_TRANSPORT, ASTRAL_REDIS_PROJECTION_COMPAT

## 选择外套件（10，登记在册未入选）

- rq-current-distributed-campaign: legacy RQ/S15 harness assumes Redis/OPA and protected three-node state; needs current Rabbit-only deployment adapter and approved hashes/routing/postconditions; no legacy argv dispatched
- native-http-campaign: approved run-owned deployment/source bootstrap/signed identity/readiness and durable publication evidence are required; runner does not start services or invent credentials
- native-live-fault-campaign: no approved native live fault controller/deployed observation stream; live injection remains disabled and UNKNOWN is never replayed
- mt-e2-unimplemented: no MT-E2 implementation or approved scenario contract exists
- tlc-admission-model: no pinned checksum-verified TLC executable; runner never downloads tools
- iai-instruction-benchmark: requires explicit Linux/Valgrind tooling and iai feature; not dispatched on the default portable profile
- historical-engine-comparison: comparison harness requires separate comparator/profile validation and image provenance; not part of production-equivalent native gate
- excluded-service-checks: frozen sources require dedicated isolated verification and recorded ignored tests; root workspace gate does not cover them
- excluded-sdk-integrations: dedicated SDK service/test identities and integration deployment contract must be verified separately
- archived-cache-contracts: archive-specific standalone verification only; no implicit reintroduction into native profile

## series 汇总（23 系列）

- CORE: PASS（18 套件，scopes component,integration）
- RQ1: PASS（1 套件，scopes component）
- RQ2: PASS（7 套件，scopes component,integration）
- RQ3: PASS（8 套件，scopes component,integration）
- RQ4: PASS（2 套件，scopes integration）
- RQ5: PASS（3 套件，scopes component）
- M1: PASS（9 套件，scopes component,integration,offline-model）
- M2: PASS（15 套件，scopes component,integration,offline-model）
- M3: PASS（22 套件，scopes component,integration,offline-model）
- M4: PASS（7 套件，scopes component,integration,offline-model）
- M5: PASS（12 套件，scopes component,integration,offline-model）
- E1: PASS（7 套件，scopes component,offline-model）
- E2: PASS（6 套件，scopes component,offline-model）
- E3: PASS（12 套件，scopes component,integration,offline-model）
- E4: PASS（20 套件，scopes component,integration,offline-model）
- E5: PASS（5 套件，scopes offline-model）
- MT-E1: PASS（6 套件，scopes component,integration,offline-model）
- MT-E3: PASS（1 套件，scopes integration）
- MT-E4: PASS（1 套件，scopes integration）
- MT-E5: PASS（1 套件，scopes integration）
- MT-E6: PASS（1 套件，scopes integration）
- PERF: PASS（10 套件，scopes component）
- COMPAT: PASS（1 套件，scopes integration）
