#!/usr/bin/env bash
set -uo pipefail
EV="$HOME/astral-test-runs/e5-all-20261008-a11-evidence"
cd "$HOME/astral-test-runs/e5-all-20261008-a10-evidence/source-a10-v03/tree" || exit 9
set -a
. "$EV/campaign-a11.env"
set +a
SUITE_ARGS=$(python3 - "$EV/selection-a11.json" <<'PY'
import json, sys
selection = json.load(open(sys.argv[1]))['selection']
print(' '.join('--suite ' + suite for suite in selection))
PY
) || exit 9
exec python3 scripts/test_campaign.py --run --verify-items $SUITE_ARGS \
  --run-id e5-all-20261008-a11-v02 \
  --artifact-root "$EV/runs"
