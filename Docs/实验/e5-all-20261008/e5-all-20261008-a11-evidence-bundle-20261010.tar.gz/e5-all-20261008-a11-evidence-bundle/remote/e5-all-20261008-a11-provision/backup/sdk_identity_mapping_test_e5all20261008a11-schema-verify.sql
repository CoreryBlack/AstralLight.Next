
USE `sdk_identity_mapping_test_e5all20261008a11`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `_sqlx_migrations` (
  `version` bigint NOT NULL,
  `description` text NOT NULL,
  `installed_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `success` tinyint(1) NOT NULL,
  `checksum` blob NOT NULL,
  `execution_time` bigint NOT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `al_message_outbox` (
  `message_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `operation_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `message_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordering_key` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tenant_id` bigint DEFAULT NULL,
  `origin_region` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_region` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `schema_version` int NOT NULL,
  `payload_json` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `headers_json` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `payload_sha256` char(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `attempts` int NOT NULL DEFAULT '0',
  `next_attempt_at` datetime(6) DEFAULT NULL,
  `lease_owner` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lease_expires_at` datetime(6) DEFAULT NULL,
  `processed_at` datetime(6) DEFAULT NULL,
  `last_error` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `scope_sequence` bigint DEFAULT NULL COMMENT 'per-scope commit-order sequence allocated in the append transaction; NULL = legacy row or row without ordering_key',
  PRIMARY KEY (`message_id`),
  UNIQUE KEY `uk_al_message_queue_message` (`queue_name`,`message_id`),
  KEY `idx_al_message_pending` (`status`,`next_attempt_at`,`created_at`),
  KEY `idx_al_message_lease` (`status`,`lease_expires_at`,`message_id`),
  KEY `idx_al_message_ordering` (`queue_name`,`ordering_key`,`status`,`created_at`),
  KEY `idx_al_message_operation` (`operation_id`,`message_type`),
  KEY `idx_al_message_tenant` (`tenant_id`,`queue_name`,`created_at`),
  KEY `idx_al_message_scope_order` (`queue_name`,`ordering_key`,`scope_sequence`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `al_message_scope_counter` (
  `scope_key` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'queue_name + 0x1F + ordering_key; see migration header for the size bound',
  `last_sequence` bigint NOT NULL DEFAULT '0' COMMENT 'highest scope_sequence allocated for this scope',
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`scope_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alert_rule` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `metric` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `condition_op` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '>=',
  `threshold` double NOT NULL,
  `duration_seconds` int NOT NULL DEFAULT '60',
  `severity` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'WARNING',
  `enabled` tinyint NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `async_operation` (
  `task_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `task_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `requester_user_id` bigint NOT NULL,
  `requester_card_id` bigint NOT NULL,
  `requester_tenant_id` bigint NOT NULL,
  `requester_domain_id` bigint NOT NULL,
  `authorization_target_card_id` bigint NOT NULL,
  `authorization_target_tenant_id` bigint NOT NULL,
  `authorization_target_domain_id` bigint NOT NULL,
  `target_user_id` bigint NOT NULL,
  `total_items` int unsigned NOT NULL,
  `completed_items` int unsigned NOT NULL DEFAULT '0',
  `owner_instance_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `error_message` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` bigint NOT NULL DEFAULT (unix_timestamp()),
  `updated_at` bigint NOT NULL DEFAULT (unix_timestamp()),
  PRIMARY KEY (`task_id`),
  KEY `idx_async_operation_owner_status` (`requester_user_id`,`status`,`updated_at`),
  KEY `idx_async_operation_anchor` (`authorization_target_card_id`,`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `async_operation_item` (
  `task_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `card_id` bigint NOT NULL,
  `tenant_id` bigint NOT NULL,
  `domain_id` bigint NOT NULL,
  `operation_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `error_message` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` bigint NOT NULL DEFAULT (unix_timestamp()),
  `updated_at` bigint NOT NULL DEFAULT (unix_timestamp()),
  PRIMARY KEY (`task_id`,`card_id`),
  UNIQUE KEY `uk_async_operation_item_operation` (`operation_id`),
  KEY `idx_async_operation_item_status` (`task_id`,`status`,`card_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `action` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `resource` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `decision` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reason` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_id` bigint DEFAULT NULL,
  `detail` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `event_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_ip` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `domain_id` bigint DEFAULT NULL,
  `tenant_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_al_user` (`user_id`),
  KEY `idx_al_action` (`action`),
  KEY `idx_al_created` (`created_at`),
  KEY `idx_al_event_type` (`event_type`),
  KEY `idx_al_tenant` (`tenant_id`),
  KEY `idx_al_card` (`card_id`),
  KEY `idx_al_decision` (`decision`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_quarantine` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `identity_key` binary(32) NOT NULL,
  `message_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `message_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `raw_payload` longblob NOT NULL,
  `source_queue` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_exchange` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_routing_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `retry_count` int unsigned NOT NULL DEFAULT '0',
  `attempts` int unsigned NOT NULL DEFAULT '0',
  `replay_attempts` int unsigned NOT NULL DEFAULT '0',
  `failure_reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'QUARANTINED',
  `replay_lease_owner` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `replay_lease_token_hash` binary(32) DEFAULT NULL,
  `replay_lease_generation` bigint unsigned NOT NULL DEFAULT '0',
  `replay_operation_id_hash` binary(32) DEFAULT NULL,
  `replay_requested_by` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `replay_requested_at` datetime DEFAULT NULL,
  `replay_lease_token` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `replay_lease_expires_at` datetime DEFAULT NULL,
  `first_failed_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_failed_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `quarantined_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `replayed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_aq_identity_key` (`identity_key`),
  KEY `idx_aq_status` (`status`,`quarantined_at`,`id`),
  KEY `idx_aq_replay_lease` (`status`,`replay_lease_expires_at`,`id`),
  KEY `idx_aq_replay_request` (`status`,`replay_requested_at`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_audit_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL COMMENT '操作用户 ID',
  `card_id` bigint DEFAULT NULL COMMENT '当前激活卡片 ID',
  `domain_id` bigint DEFAULT NULL COMMENT '操作所属域 ID',
  `identity_id` bigint DEFAULT NULL COMMENT '关联的 user_identity ID',
  `session_id` bigint DEFAULT NULL COMMENT '关联的 Session ID',
  `event_type` varchar(64) NOT NULL COMMENT '事件类型',
  `resource` varchar(128) DEFAULT NULL COMMENT '操作资源',
  `action` varchar(64) DEFAULT NULL COMMENT '操作动作',
  `target_id` bigint DEFAULT NULL COMMENT '目标实体 ID',
  `result` varchar(16) NOT NULL DEFAULT 'UNKNOWN' COMMENT 'ALLOW / DENY / ERROR',
  `reason` varchar(256) DEFAULT NULL COMMENT '判定原因',
  `provider` varchar(64) DEFAULT NULL COMMENT '第三方提供商',
  `severity` varchar(16) NOT NULL DEFAULT 'INFO' COMMENT 'INFO / WARN / CRITICAL',
  `ip` varchar(64) DEFAULT NULL COMMENT '操作 IP',
  `user_agent` varchar(512) DEFAULT NULL COMMENT 'User-Agent',
  `detail` text COMMENT '结构化事件数据',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_audit_card` (`card_id`),
  KEY `idx_audit_event` (`event_type`),
  KEY `idx_audit_result` (`result`),
  KEY `idx_audit_time` (`created_at`),
  KEY `idx_audit_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=855 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='统一审计日志';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_device_session` (
  `session_id` bigint NOT NULL AUTO_INCREMENT,
  `family_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `device_id` varchar(255) NOT NULL,
  `device_type` varchar(64) DEFAULT NULL,
  `client_app_id` varchar(128) DEFAULT NULL,
  `channel_code` varchar(64) DEFAULT NULL,
  `current_user_card_id` bigint DEFAULT NULL COMMENT '当前激活的用户卡ID（user_card.card_id）',
  `session_state` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'ACTIVE',
  `session_version` bigint NOT NULL DEFAULT '1',
  `session_epoch` bigint NOT NULL DEFAULT '1',
  `refresh_token_hash` varchar(255) NOT NULL,
  `refresh_expires_at` datetime DEFAULT NULL,
  `status` varchar(32) NOT NULL DEFAULT 'ACTIVE',
  `ip_address` varchar(64) DEFAULT NULL,
  `user_agent` varchar(512) DEFAULT NULL,
  `last_seen_at` datetime DEFAULT NULL,
  `revoked_at` datetime DEFAULT NULL,
  `revoked_reason` varchar(512) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `credential_version` bigint DEFAULT NULL,
  PRIMARY KEY (`session_id`),
  UNIQUE KEY `uk_ads_refresh_token` (`refresh_token_hash`),
  KEY `idx_ads_user_device` (`user_id`,`device_id`),
  KEY `idx_ads_card` (`current_user_card_id`),
  KEY `idx_ads_family` (`family_id`),
  KEY `idx_ads_user_credential_version` (`user_id`,`credential_version`,`status`),
  CONSTRAINT `fk_ads_card` FOREIGN KEY (`current_user_card_id`) REFERENCES `user_card` (`card_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ads_family` FOREIGN KEY (`family_id`) REFERENCES `auth_token_family` (`family_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ads_user` FOREIGN KEY (`user_id`) REFERENCES `platform_user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='认证设备会话';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_internal_request_guard` (
  `guard_id` bigint NOT NULL AUTO_INCREMENT,
  `guard_scope` varchar(64) NOT NULL,
  `guard_key` varchar(255) NOT NULL,
  `marker` varchar(128) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`guard_id`),
  UNIQUE KEY `uk_airg_scope_key` (`guard_scope`,`guard_key`),
  KEY `idx_airg_expiry` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_session_jti_index` (
  `jti_id` bigint NOT NULL AUTO_INCREMENT,
  `session_id` bigint NOT NULL,
  `jti` varchar(128) NOT NULL,
  `user_id` bigint NOT NULL,
  `session_epoch` bigint NOT NULL,
  `status` varchar(32) NOT NULL DEFAULT 'ACTIVE',
  `issued_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`jti_id`),
  UNIQUE KEY `uk_asji_jti` (`jti`),
  KEY `idx_asji_session_epoch` (`session_id`,`session_epoch`,`status`),
  KEY `idx_asji_status` (`status`,`expires_at`),
  CONSTRAINT `fk_asji_session` FOREIGN KEY (`session_id`) REFERENCES `auth_device_session` (`session_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_session_operation` (
  `operation_id` varchar(64) NOT NULL,
  `session_id` bigint DEFAULT NULL,
  `user_id` bigint NOT NULL,
  `operation_type` varchar(32) NOT NULL,
  `idempotency_key_hash` char(64) NOT NULL,
  `request_hash` char(64) NOT NULL,
  `refresh_token_hash` char(64) NOT NULL,
  `target_card_id` bigint DEFAULT NULL,
  `status` varchar(32) NOT NULL,
  `response_ciphertext` mediumtext,
  `response_expires_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`operation_id`),
  UNIQUE KEY `uk_aso_user_type_idempotency` (`user_id`,`operation_type`,`idempotency_key_hash`),
  KEY `idx_aso_session` (`session_id`),
  KEY `idx_aso_expiry` (`response_expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_session_outbox` (
  `outbox_id` bigint NOT NULL AUTO_INCREMENT,
  `operation_id` varchar(64) NOT NULL,
  `session_id` bigint DEFAULT NULL,
  `event_type` varchar(16) NOT NULL,
  `sequence_number` int NOT NULL,
  `projection_key` varchar(512) NOT NULL,
  `payload_json` mediumtext,
  `projection_expires_at` datetime DEFAULT NULL,
  `status` varchar(32) NOT NULL DEFAULT 'PENDING',
  `attempts` int NOT NULL DEFAULT '0',
  `next_attempt_at` datetime DEFAULT NULL,
  `lease_owner` varchar(64) DEFAULT NULL,
  `lease_expires_at` datetime DEFAULT NULL,
  `processed_at` datetime DEFAULT NULL,
  `processed_by` varchar(64) DEFAULT NULL,
  `terminal_transitions` int NOT NULL DEFAULT '0',
  `last_error` varchar(128) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`outbox_id`),
  UNIQUE KEY `uk_aso_operation_sequence` (`operation_id`,`sequence_number`),
  KEY `idx_aso_pending` (`status`,`next_attempt_at`,`created_at`),
  KEY `idx_aso_lease` (`status`,`lease_expires_at`,`outbox_id`),
  KEY `idx_aso_session` (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_token_family` (
  `family_id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `family_key` varchar(255) NOT NULL,
  `status` varchar(32) NOT NULL DEFAULT 'ACTIVE',
  `issued_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at` datetime DEFAULT NULL,
  `revoked_at` datetime DEFAULT NULL,
  `revoked_reason` varchar(512) DEFAULT NULL,
  `metadata_json` json DEFAULT NULL,
  PRIMARY KEY (`family_id`),
  UNIQUE KEY `uk_atf_family_key` (`family_key`),
  KEY `idx_atf_status` (`status`),
  KEY `idx_atf_user` (`user_id`),
  CONSTRAINT `fk_atf_user` FOREIGN KEY (`user_id`) REFERENCES `platform_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Token 家族';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authorization_archive_manifest` (
  `archive_manifest_id` bigint NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint NOT NULL,
  `card_id` bigint DEFAULT NULL,
  `aggregate_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `aggregate_id` bigint NOT NULL,
  `manifest_id` bigint NOT NULL,
  `generation` bigint NOT NULL,
  `event_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `operation_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `archive_key` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `archive_digest` binary(32) NOT NULL,
  `semantic_hash` binary(32) NOT NULL,
  `dependency_hash` binary(32) NOT NULL,
  `compiler_version` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'STAGED',
  `cas_version` bigint NOT NULL DEFAULT '0',
  `archived_at` datetime DEFAULT NULL,
  `last_error` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `archived_revoke_fence` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`archive_manifest_id`),
  UNIQUE KEY `uk_aam_generation` (`tenant_id`,`aggregate_type`,`aggregate_id`,`generation`),
  UNIQUE KEY `uk_aam_archive_digest` (`tenant_id`,`archive_digest`),
  KEY `idx_aam_aggregate` (`tenant_id`,`aggregate_type`,`aggregate_id`,`generation`),
  KEY `idx_aam_card` (`tenant_id`,`card_id`,`generation`),
  KEY `idx_aam_status` (`status`,`archived_at`,`archive_manifest_id`),
  KEY `idx_aam_manifest` (`manifest_id`),
  KEY `idx_aam_event` (`event_id`),
  KEY `idx_aam_operation` (`operation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Archive evidence manifest for a generation-scoped projection';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authorization_archive_outbox` (
  `archive_outbox_id` bigint NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint NOT NULL,
  `card_id` bigint DEFAULT NULL,
  `aggregate_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `aggregate_id` bigint NOT NULL,
  `manifest_id` bigint NOT NULL,
  `generation` bigint NOT NULL,
  `event_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `operation_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `archive_key` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `semantic_hash` binary(32) NOT NULL,
  `dependency_hash` binary(32) NOT NULL,
  `compiler_version` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `attempts` int NOT NULL DEFAULT '0',
  `next_attempt_at` datetime DEFAULT NULL,
  `lease_owner` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lease_token_hash` binary(32) DEFAULT NULL,
  `lease_expires_at` datetime DEFAULT NULL,
  `cas_version` bigint NOT NULL DEFAULT '0',
  `archived_at` datetime DEFAULT NULL,
  `last_error` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `archived_revoke_fence` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`archive_outbox_id`),
  UNIQUE KEY `uk_aao_event` (`event_id`),
  UNIQUE KEY `uk_aao_generation` (`tenant_id`,`aggregate_type`,`aggregate_id`,`generation`),
  KEY `idx_aao_aggregate` (`tenant_id`,`aggregate_type`,`aggregate_id`,`generation`),
  KEY `idx_aao_card` (`tenant_id`,`card_id`,`generation`),
  KEY `idx_aao_pending` (`status`,`next_attempt_at`,`created_at`),
  KEY `idx_aao_lease` (`status`,`lease_expires_at`,`archive_outbox_id`),
  KEY `idx_aao_manifest` (`manifest_id`),
  KEY `idx_aao_operation` (`operation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Durable asynchronous archive work item for a projection manifest';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authorization_cross_city_authority_scope` (
  `scope_id` bigint NOT NULL AUTO_INCREMENT,
  `city_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `scope_digest` binary(32) NOT NULL COMMENT 'digest of the authorization scope the city is authoritative for',
  `authoritative` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'only an explicit 1 admits the city for the scope; absent rows are refused',
  `registered_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`scope_id`),
  UNIQUE KEY `uk_accas_city_scope` (`city_id`,`scope_digest`),
  KEY `idx_accas_scope` (`scope_digest`,`authoritative`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Explicit authoritative city-scope registry; missing configuration is refused, never guessed (default-off subsystem)';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authorization_cross_city_city_state` (
  `state_id` bigint NOT NULL AUTO_INCREMENT,
  `operation_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `city_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phase` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PROPOSED' COMMENT 'city-side phase mirror of the operation state set',
  `local_base_digest` binary(32) NOT NULL,
  `commit_digest` binary(32) DEFAULT NULL,
  `pointer_digest` binary(32) DEFAULT NULL,
  `certificate_digest` binary(32) DEFAULT NULL COMMENT 'city vote certificate digest once the city certified',
  `lease_owner` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lease_token_hash` binary(32) DEFAULT NULL,
  `lease_expires_at` datetime DEFAULT NULL,
  `last_error` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`state_id`),
  UNIQUE KEY `uk_accc_operation_city` (`operation_id`,`city_id`),
  KEY `idx_accc_phase_lease` (`phase`,`lease_expires_at`,`state_id`),
  KEY `idx_accc_city` (`city_id`,`operation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Per-city durable phase and lease holder for one cross-city operation';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authorization_cross_city_commit_receipt` (
  `receipt_id` bigint NOT NULL AUTO_INCREMENT,
  `operation_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `city_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `node_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `node_epoch` bigint NOT NULL,
  `decision` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ALLOW only; no default so every recorded decision is explicit',
  `proposal_digest` binary(32) NOT NULL,
  `evidence_digest` binary(32) NOT NULL COMMENT 'digest of the signed node evidence inside this receipt',
  `target_generation` bigint NOT NULL,
  `revoke_fence` bigint NOT NULL DEFAULT '0',
  `coordinator_epoch` bigint NOT NULL,
  `nonce` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `signature` varchar(4096) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'opaque node signature over the evidence digest',
  `observed_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`receipt_id`),
  UNIQUE KEY `uk_acccr_node` (`operation_id`,`city_id`,`node_id`),
  UNIQUE KEY `uk_acccr_nonce` (`operation_id`,`nonce`),
  KEY `idx_acccr_operation_city` (`operation_id`,`city_id`,`decision`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Insert-only signed durable source-apply receipt per city/node; the only activation-mint input (default-off subsystem)';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authorization_cross_city_gate` (
  `gate_id` bigint NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint NOT NULL,
  `aggregate_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `aggregate_id` bigint NOT NULL,
  `operation_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `certificate_digest` binary(32) NOT NULL COMMENT 'agreement/vote certificate digest bound to the gate transition',
  `target_generation` bigint NOT NULL,
  `revoke_fence` bigint NOT NULL DEFAULT '0',
  `state` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'BLOCKED' COMMENT 'SYNCING/ACTIVE/BLOCKED; BLOCKED is the fail-closed default',
  `content_hash` binary(32) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`gate_id`),
  UNIQUE KEY `uk_accg_scope` (`tenant_id`,`aggregate_type`,`aggregate_id`),
  KEY `idx_accg_state` (`state`,`updated_at`,`gate_id`),
  KEY `idx_accg_operation` (`operation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Per-aggregate cross-city synchronization gate; BLOCKED unless explicitly enabled';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authorization_cross_city_inbox` (
  `message_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `operation_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_city_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phase` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload_digest` binary(32) NOT NULL,
  `status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `attempts` int NOT NULL DEFAULT '0',
  `lease_owner` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lease_token_hash` binary(32) DEFAULT NULL,
  `lease_expires_at` datetime DEFAULT NULL,
  `received_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `processed_at` datetime DEFAULT NULL,
  `last_error` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`message_id`),
  KEY `idx_accib_lease` (`status`,`lease_expires_at`,`message_id`),
  KEY `idx_accib_operation` (`operation_id`),
  KEY `idx_accib_source` (`source_city_id`,`phase`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Cross-city inbound durable work item keyed by message id (idempotent receive)';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authorization_cross_city_node_key` (
  `node_key_id` bigint NOT NULL AUTO_INCREMENT,
  `city_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `node_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `node_epoch` bigint NOT NULL COMMENT 'positive epoch of the node software/state',
  `public_key` binary(32) NOT NULL COMMENT 'exact raw Ed25519 public key of this identity',
  `revoked` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1 = key withdrawn; resolver fails closed on revoked identities',
  `registered_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `revoked_at` datetime DEFAULT NULL,
  `revoked_reason` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`node_key_id`),
  UNIQUE KEY `uk_accnk_identity` (`city_id`,`node_id`,`node_epoch`),
  KEY `idx_accnk_revoked` (`revoked`,`node_key_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Durable cross-city node key registry keyed by exact city/node/epoch identity (default-off subsystem)';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authorization_cross_city_operation` (
  `operation_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'canonical cross-city operation_id: lowercase hyphenated UUID',
  `scope_digest` binary(32) NOT NULL,
  `request_digest` binary(32) NOT NULL,
  `mutation_digest` binary(32) NOT NULL,
  `base_frontier_digest` binary(32) NOT NULL,
  `base_source_generation` bigint NOT NULL,
  `base_revoke_fence` bigint NOT NULL DEFAULT '0',
  `target_generation` bigint NOT NULL,
  `target_revoke_fence` bigint NOT NULL DEFAULT '0',
  `proposal_digest` binary(32) NOT NULL,
  `compiler_version` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `policy_version` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `home_city` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `coordinator_epoch` bigint NOT NULL DEFAULT '1' COMMENT 'monotonic coordinator epoch fence',
  `state` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PROPOSED' COMMENT 'closed set owned by astral-types; no CHECK by design',
  `agreement_digest` binary(32) DEFAULT NULL COMMENT 'agreement certificate digest once two cities certified',
  `expires_at` datetime NOT NULL,
  `last_error` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`operation_id`),
  KEY `idx_acco_state_expiry` (`state`,`expires_at`,`operation_id`),
  KEY `idx_acco_home_city` (`home_city`,`state`,`operation_id`),
  KEY `idx_acco_scope_target` (`scope_digest`,`target_generation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Durable cross-city authorization operation root (default-off subsystem)';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authorization_cross_city_operation_activation` (
  `operation_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'canonical cross-city operation_id; one durable mint record per operation',
  `agreement_digest` binary(32) NOT NULL,
  `commit_digest` binary(32) NOT NULL COMMENT 'canonical digest derived from the durable two-city commit receipts at mint time',
  `scope_digest` binary(32) NOT NULL,
  `target_generation` bigint NOT NULL,
  `revoke_fence` bigint NOT NULL DEFAULT '0',
  `coordinator_epoch` bigint NOT NULL,
  `minted_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`operation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Durable idempotency+audit witness of one commit-confirmed activation mint per operation (default-off subsystem)';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authorization_cross_city_outbox` (
  `message_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `operation_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_city_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'sending city; durable routing evidence, mirrors inbox source_city_id',
  `destination_city_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'target city; durable routing evidence',
  `phase` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload_digest` binary(32) NOT NULL,
  `payload` mediumblob NOT NULL,
  `status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `attempts` int NOT NULL DEFAULT '0',
  `next_attempt_at` datetime DEFAULT NULL,
  `lease_owner` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lease_token_hash` binary(32) DEFAULT NULL,
  `lease_expires_at` datetime DEFAULT NULL,
  `last_error` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`message_id`),
  KEY `idx_accob_pending` (`status`,`next_attempt_at`,`created_at`),
  KEY `idx_accob_lease` (`status`,`lease_expires_at`,`message_id`),
  KEY `idx_accob_operation` (`operation_id`),
  KEY `idx_accob_source` (`source_city_id`,`phase`),
  KEY `idx_accob_destination` (`destination_city_id`,`phase`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Cross-city outbound durable work item keyed by message id (explicit source/destination routing)';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authorization_cross_city_vote` (
  `vote_id` bigint NOT NULL AUTO_INCREMENT,
  `operation_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `city_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `node_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `node_epoch` bigint NOT NULL,
  `decision` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ALLOW or DENY; no default so every recorded decision is explicit',
  `proposal_digest` binary(32) NOT NULL,
  `frontier_digest` binary(32) NOT NULL,
  `mutation_digest` binary(32) NOT NULL,
  `evidence_digest` binary(32) NOT NULL,
  `nonce` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `signature` varchar(4096) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'opaque node signature over evidence_digest',
  `expires_at` datetime NOT NULL,
  `observed_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`vote_id`),
  UNIQUE KEY `uk_accv_node` (`operation_id`,`city_id`,`node_id`),
  UNIQUE KEY `uk_accv_nonce` (`operation_id`,`nonce`),
  KEY `idx_accv_decision` (`operation_id`,`decision`,`city_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Insert-only per-node cross-city vote evidence; duplicate keys are durable conflicts, never overwrites';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authorization_cross_city_vote_reservation` (
  `reservation_id` bigint NOT NULL AUTO_INCREMENT,
  `operation_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'operation the evidence was admitted for (audit binding)',
  `city_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `node_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `node_epoch` bigint NOT NULL,
  `nonce` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `evidence_digest` binary(32) NOT NULL,
  `reserved_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`reservation_id`),
  UNIQUE KEY `uk_accvr_replay_key` (`city_id`,`node_id`,`node_epoch`,`nonce`,`evidence_digest`),
  KEY `idx_accvr_operation` (`operation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Durable replay reservation over the exact signature-boundary replay key; committed in the same transaction as the vote insert';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authorization_delta_event` (
  `delta_event_id` bigint NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint NOT NULL,
  `card_id` bigint DEFAULT NULL,
  `aggregate_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `aggregate_id` bigint NOT NULL,
  `grant_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'canonical GrantId: lowercase hyphenated UUID',
  `event_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `operation_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `base_version` bigint NOT NULL,
  `target_version` bigint NOT NULL,
  `source_generation` bigint NOT NULL,
  `revoke_fence` bigint NOT NULL DEFAULT '0',
  `before_image_json` json DEFAULT NULL,
  `before_digest` binary(32) DEFAULT NULL,
  `delta_json` json NOT NULL,
  `semantic_hash` binary(32) NOT NULL,
  `dependency_hash` binary(32) NOT NULL,
  `compiler_version` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `attempts` int NOT NULL DEFAULT '0',
  `next_attempt_at` datetime DEFAULT NULL,
  `lease_owner` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lease_token_hash` binary(32) DEFAULT NULL,
  `lease_expires_at` datetime DEFAULT NULL,
  `cas_version` bigint NOT NULL DEFAULT '0',
  `last_error` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `invalidates_published_evidence` tinyint NOT NULL DEFAULT '1',
  PRIMARY KEY (`delta_event_id`),
  UNIQUE KEY `uk_ade_event` (`event_id`),
  UNIQUE KEY `uk_ade_target_version` (`tenant_id`,`aggregate_type`,`aggregate_id`,`grant_id`,`target_version`),
  KEY `idx_ade_aggregate` (`tenant_id`,`aggregate_type`,`aggregate_id`,`target_version`),
  KEY `idx_ade_card` (`tenant_id`,`card_id`,`target_version`),
  KEY `idx_ade_pending` (`status`,`next_attempt_at`,`created_at`),
  KEY `idx_ade_lease` (`status`,`lease_expires_at`,`delta_event_id`),
  KEY `idx_ade_operation` (`operation_id`),
  KEY `idx_ade_grant_chain` (`tenant_id`,`grant_id`,`status`,`target_version`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Typed grant delta events with version, before-image, digest and CAS state';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authorization_grant_revision` (
  `revision_id` bigint NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint NOT NULL,
  `card_id` bigint DEFAULT NULL,
  `aggregate_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `aggregate_id` bigint NOT NULL,
  `grant_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'canonical GrantId: lowercase hyphenated UUID',
  `revision_no` bigint NOT NULL,
  `operation_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `is_tombstone` tinyint NOT NULL DEFAULT '0',
  `grant_payload` json NOT NULL,
  `semantic_hash` binary(32) NOT NULL,
  `dependency_hash` binary(32) NOT NULL,
  `compiler_version` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`revision_id`),
  UNIQUE KEY `uk_agr_revision_version` (`tenant_id`,`aggregate_type`,`aggregate_id`,`grant_id`,`revision_no`),
  KEY `idx_agr_revision_aggregate` (`tenant_id`,`aggregate_type`,`aggregate_id`,`revision_no`),
  KEY `idx_agr_revision_card` (`tenant_id`,`card_id`,`revision_no`),
  KEY `idx_agr_revision_tombstone` (`tenant_id`,`aggregate_type`,`aggregate_id`,`is_tombstone`,`revision_no`),
  KEY `idx_agr_revision_event` (`event_id`),
  KEY `idx_agr_revision_operation` (`operation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Versioned Rust-owned grant revisions, including tombstones';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authorization_impact_plan` (
  `plan_id` bigint NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint NOT NULL,
  `card_id` bigint DEFAULT NULL,
  `aggregate_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `aggregate_id` bigint NOT NULL,
  `event_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `operation_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `base_generation` bigint NOT NULL,
  `target_generation` bigint NOT NULL,
  `base_version` bigint NOT NULL,
  `target_version` bigint NOT NULL,
  `semantic_hash` binary(32) NOT NULL,
  `dependency_hash` binary(32) NOT NULL,
  `compiler_version` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `attempts` int NOT NULL DEFAULT '0',
  `next_attempt_at` datetime DEFAULT NULL,
  `lease_owner` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lease_token_hash` binary(32) DEFAULT NULL,
  `lease_expires_at` datetime DEFAULT NULL,
  `cas_version` bigint NOT NULL DEFAULT '0',
  `last_error` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`plan_id`),
  UNIQUE KEY `uk_aip_event` (`event_id`),
  UNIQUE KEY `uk_aip_target_generation` (`tenant_id`,`aggregate_type`,`aggregate_id`,`target_generation`),
  KEY `idx_aip_card` (`tenant_id`,`card_id`,`target_generation`),
  KEY `idx_aip_pending` (`status`,`next_attempt_at`,`created_at`),
  KEY `idx_aip_lease` (`status`,`lease_expires_at`,`plan_id`),
  KEY `idx_aip_operation` (`operation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Durable impact-plan root for an incremental projection generation';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authorization_impact_plan_item` (
  `item_id` bigint NOT NULL AUTO_INCREMENT,
  `plan_id` bigint NOT NULL,
  `tenant_id` bigint NOT NULL,
  `card_id` bigint DEFAULT NULL,
  `aggregate_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `aggregate_id` bigint NOT NULL,
  `event_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `operation_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `projection_key` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `grant_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'canonical GrantId: lowercase hyphenated UUID',
  `base_version` bigint NOT NULL,
  `target_version` bigint NOT NULL,
  `before_digest` binary(32) DEFAULT NULL,
  `after_digest` binary(32) DEFAULT NULL,
  `dependency_hash` binary(32) NOT NULL,
  `status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `cas_version` bigint NOT NULL DEFAULT '0',
  `last_error` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`item_id`),
  UNIQUE KEY `uk_aipi_plan_key` (`plan_id`,`projection_key`),
  KEY `idx_aipi_plan_status` (`plan_id`,`status`,`item_id`),
  KEY `idx_aipi_aggregate` (`tenant_id`,`aggregate_type`,`aggregate_id`,`target_version`),
  KEY `idx_aipi_card` (`tenant_id`,`card_id`,`target_version`),
  KEY `idx_aipi_event` (`event_id`),
  KEY `idx_aipi_operation` (`operation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Durable impact-plan items keyed by affected projection identity';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authorization_invalidation_inbox` (
  `node_region` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `node_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `message_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `operation_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `message_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordering_key` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tenant_id` bigint DEFAULT NULL,
  `origin_region` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `schema_version` int NOT NULL,
  `payload_json` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload_sha256` char(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `envelope_created_at` datetime(6) NOT NULL,
  `status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `applied_at` datetime(6) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`node_region`,`node_id`,`message_id`),
  KEY `idx_invalidation_inbox_scope_pending` (`node_region`,`node_id`,`ordering_key`,`status`,`envelope_created_at`,`message_id`),
  KEY `idx_invalidation_inbox_pending` (`node_region`,`node_id`,`status`,`envelope_created_at`),
  KEY `idx_invalidation_inbox_operation` (`node_region`,`node_id`,`operation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authorization_projection_current` (
  `pointer_id` bigint NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint NOT NULL,
  `card_id` bigint DEFAULT NULL,
  `aggregate_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `aggregate_id` bigint NOT NULL,
  `current_generation` bigint NOT NULL,
  `manifest_id` bigint NOT NULL,
  `event_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `operation_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `semantic_hash` binary(32) NOT NULL,
  `dependency_hash` binary(32) NOT NULL,
  `compiler_version` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'READY',
  `cas_version` bigint NOT NULL DEFAULT '0',
  `last_error` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `revoke_fence` bigint NOT NULL DEFAULT '0',
  `revoke_fence_proven` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`pointer_id`),
  UNIQUE KEY `uk_apc_aggregate` (`tenant_id`,`aggregate_type`,`aggregate_id`),
  KEY `idx_apc_generation` (`tenant_id`,`aggregate_type`,`aggregate_id`,`current_generation`),
  KEY `idx_apc_card` (`tenant_id`,`card_id`,`current_generation`),
  KEY `idx_apc_manifest` (`manifest_id`),
  KEY `idx_apc_event` (`event_id`),
  KEY `idx_apc_operation` (`operation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='CAS-updated current projection manifest pointer';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authorization_projection_head` (
  `head_id` bigint NOT NULL AUTO_INCREMENT,
  `aggregate_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `aggregate_id` bigint NOT NULL,
  `source_generation` bigint NOT NULL DEFAULT '0',
  `revoke_fence` bigint NOT NULL DEFAULT '0',
  `last_event_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_error` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`head_id`),
  UNIQUE KEY `uk_aph_aggregate` (`aggregate_type`,`aggregate_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authorization_projection_manifest` (
  `manifest_id` bigint NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint NOT NULL,
  `card_id` bigint DEFAULT NULL,
  `aggregate_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `aggregate_id` bigint NOT NULL,
  `generation` bigint NOT NULL,
  `source_generation` bigint NOT NULL,
  `projected_generation` bigint NOT NULL,
  `event_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `operation_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `semantic_hash` binary(32) NOT NULL,
  `dependency_hash` binary(32) NOT NULL,
  `compiler_version` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `manifest_digest` binary(32) NOT NULL,
  `status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'BUILDING',
  `cas_version` bigint NOT NULL DEFAULT '0',
  `lease_owner` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lease_token_hash` binary(32) DEFAULT NULL,
  `lease_expires_at` datetime DEFAULT NULL,
  `last_error` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `parent_manifest_id` bigint DEFAULT NULL,
  `revoke_fence` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`manifest_id`),
  UNIQUE KEY `uk_apm_generation` (`tenant_id`,`aggregate_type`,`aggregate_id`,`generation`),
  UNIQUE KEY `uk_apm_digest` (`tenant_id`,`manifest_digest`),
  KEY `idx_apm_card` (`tenant_id`,`card_id`,`generation`),
  KEY `idx_apm_status` (`status`,`lease_expires_at`,`manifest_id`),
  KEY `idx_apm_event` (`event_id`),
  KEY `idx_apm_operation` (`operation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Generation-scoped projection manifest and semantic proof';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authorization_projection_manifest_segment` (
  `reference_id` bigint NOT NULL AUTO_INCREMENT,
  `manifest_id` bigint NOT NULL,
  `segment_id` bigint NOT NULL,
  `tenant_id` bigint NOT NULL,
  `card_id` bigint DEFAULT NULL,
  `aggregate_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `aggregate_id` bigint NOT NULL,
  `generation` bigint NOT NULL,
  `segment_ordinal` int NOT NULL,
  `content_digest` binary(32) NOT NULL,
  `event_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `operation_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'READY',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`reference_id`),
  UNIQUE KEY `uk_apms_ordinal` (`manifest_id`,`segment_ordinal`),
  UNIQUE KEY `uk_apms_segment` (`manifest_id`,`segment_id`),
  KEY `idx_apms_manifest` (`tenant_id`,`manifest_id`,`generation`),
  KEY `idx_apms_segment` (`tenant_id`,`segment_id`),
  KEY `idx_apms_aggregate` (`tenant_id`,`aggregate_type`,`aggregate_id`,`generation`),
  KEY `idx_apms_event` (`event_id`),
  KEY `idx_apms_operation` (`operation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Manifest-to-segment references scoped to a projection generation';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authorization_projection_outbox` (
  `outbox_id` bigint NOT NULL AUTO_INCREMENT,
  `event_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `aggregate_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `aggregate_id` bigint NOT NULL,
  `tenant_id` bigint DEFAULT NULL,
  `event_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_generation` bigint NOT NULL,
  `sequence_number` bigint NOT NULL,
  `revoke_fence` bigint NOT NULL DEFAULT '0',
  `payload_json` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `attempts` int NOT NULL DEFAULT '0',
  `next_attempt_at` datetime DEFAULT NULL,
  `lease_owner` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lease_expires_at` datetime DEFAULT NULL,
  `processed_at` datetime DEFAULT NULL,
  `processed_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `terminal_transitions` int NOT NULL DEFAULT '0',
  `last_error` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`outbox_id`),
  UNIQUE KEY `uk_apob_event` (`event_id`),
  UNIQUE KEY `uk_apob_generation_sequence` (`aggregate_type`,`aggregate_id`,`source_generation`,`sequence_number`),
  KEY `idx_apob_pending` (`status`,`next_attempt_at`,`created_at`),
  KEY `idx_apob_lease` (`status`,`lease_expires_at`,`outbox_id`),
  KEY `idx_apob_aggregate` (`aggregate_type`,`aggregate_id`,`source_generation`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authorization_projection_partition_lease` (
  `tenant_id` bigint NOT NULL,
  `aggregate_type` varchar(32) NOT NULL,
  `aggregate_id` bigint NOT NULL,
  `lease_owner` varchar(128) NOT NULL,
  `lease_token_hash` binary(32) NOT NULL,
  `lease_expires_at` datetime(6) NOT NULL,
  `generation` bigint NOT NULL DEFAULT '1',
  `cas_version` bigint NOT NULL DEFAULT '0',
  `acquired_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `last_renewed_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`tenant_id`,`aggregate_type`,`aggregate_id`),
  KEY `idx_appl_expiry` (`lease_expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authorization_projection_segment` (
  `segment_id` bigint NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint NOT NULL,
  `card_id` bigint DEFAULT NULL,
  `aggregate_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `aggregate_id` bigint NOT NULL,
  `content_digest` binary(32) NOT NULL,
  `semantic_hash` binary(32) NOT NULL,
  `dependency_hash` binary(32) NOT NULL,
  `compiler_version` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `segment_format` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `row_count` bigint NOT NULL DEFAULT '0',
  `byte_size` bigint NOT NULL DEFAULT '0',
  `segment_payload` mediumblob NOT NULL,
  `status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'READY',
  `cas_version` bigint NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`segment_id`),
  UNIQUE KEY `uk_aps_content` (`tenant_id`,`content_digest`),
  KEY `idx_aps_aggregate` (`tenant_id`,`aggregate_type`,`aggregate_id`,`segment_id`),
  KEY `idx_aps_card` (`tenant_id`,`card_id`,`segment_id`),
  KEY `idx_aps_semantic` (`tenant_id`,`semantic_hash`,`compiler_version`),
  KEY `idx_aps_status` (`status`,`segment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Content-addressed immutable projection segment';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `badge_definitions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(64) NOT NULL,
  `name` varchar(128) NOT NULL,
  `category` varchar(64) DEFAULT NULL,
  `description` text,
  `rarity` varchar(32) DEFAULT NULL,
  `icon_url` varchar(512) DEFAULT NULL,
  `points_reward` int DEFAULT NULL,
  `unlock_condition` json DEFAULT NULL,
  `color` varchar(32) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_badge_definitions_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='徽章定义表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `card_rule_set_ref` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `card_id` bigint NOT NULL COMMENT '用户卡ID',
  `rule_set_id` bigint NOT NULL COMMENT '规则集ID',
  `ref_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'BASE' COMMENT 'BASE / OVERLAY',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `tenant_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_card_rule_set` (`card_id`,`rule_set_id`),
  KEY `idx_crsr_card` (`card_id`),
  KEY `idx_crsr_rule_set` (`rule_set_id`),
  CONSTRAINT `fk_crsr_card` FOREIGN KEY (`card_id`) REFERENCES `user_card` (`card_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_crsr_rule_set` FOREIGN KEY (`rule_set_id`) REFERENCES `rule_set` (`rule_set_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1157225487810007 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='卡片规则集绑定';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chapter_progress` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `chapter_id` bigint NOT NULL,
  `completed_levels` int DEFAULT NULL,
  `total_levels` int DEFAULT NULL,
  `completion_percentage` decimal(8,2) DEFAULT NULL,
  `average_score` decimal(8,2) DEFAULT NULL,
  `study_minutes` int DEFAULT NULL,
  `total_points` int DEFAULT NULL,
  `last_activity_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_chapter_progress_user` (`user_id`),
  KEY `idx_chapter_progress_chapter` (`chapter_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='章节进度表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_client_session` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '会话ID',
  `user_id` bigint NOT NULL COMMENT '用户ID',
  `client_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '客户端类型',
  `device_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '设备唯一标识',
  `device_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '设备名称',
  `connection_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'WebSocket连接ID',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'ONLINE' COMMENT '状态',
  `last_active_at` datetime DEFAULT NULL COMMENT '最后活跃时间',
  `push_token` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '推送Token',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_client_device` (`user_id`,`client_type`,`device_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='客户端会话表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_conversation` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '会话ID',
  `conversation_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '会话类型: SINGLE/GROUP/BUSINESS',
  `business_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '业务类型',
  `business_id` bigint DEFAULT NULL COMMENT '关联业务ID',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '会话名称',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '会话头像URL',
  `owner_id` bigint DEFAULT NULL COMMENT '群主ID',
  `domain_id` bigint NOT NULL COMMENT '域ID',
  `last_message_id` bigint DEFAULT NULL COMMENT '最后一条消息ID',
  `last_message_time` datetime DEFAULT NULL COMMENT '最后消息时间',
  `last_message_summary` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '最后消息摘要',
  `member_count` int DEFAULT '0' COMMENT '成员数量',
  `max_members` int DEFAULT '500' COMMENT '最大成员数',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'ACTIVE' COMMENT '状态: ACTIVE/ARCHIVED/DISBANDED',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_domain_org` (`domain_id`),
  KEY `idx_owner` (`owner_id`),
  KEY `idx_business` (`business_type`,`business_id`),
  KEY `idx_type_status` (`conversation_type`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='聊天会话表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_conversation_member` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '成员记录ID',
  `conversation_id` bigint NOT NULL COMMENT '会话ID',
  `user_id` bigint NOT NULL COMMENT '用户ID',
  `nickname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '群内昵称',
  `role` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'MEMBER' COMMENT '角色: OWNER/ADMIN/MEMBER',
  `last_read_message_id` bigint DEFAULT NULL COMMENT '最后已读消息ID',
  `last_read_time` datetime DEFAULT NULL COMMENT '最后阅读时间',
  `muted` tinyint DEFAULT '0' COMMENT '是否免打扰',
  `pinned` tinyint DEFAULT '0' COMMENT '是否置顶',
  `hide_nickname` tinyint DEFAULT '0' COMMENT '是否隐藏昵称',
  `joined_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '加入时间',
  `left_at` datetime DEFAULT NULL COMMENT '退出时间',
  `invite_by` bigint DEFAULT NULL COMMENT '邀请人ID',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_conversation_user` (`conversation_id`,`user_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_user_pinned` (`user_id`,`pinned`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='会话成员表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_delivery_intent` (
  `intent_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `scope_key_sha256` char(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_msg_id` varchar(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `request_sha256` char(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `message_uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `message_id` bigint DEFAULT NULL,
  `conversation_id` bigint NOT NULL,
  `sender_id` bigint NOT NULL,
  `identity_card_id` bigint NOT NULL,
  `user_card_id` bigint NOT NULL,
  `tenant_id` bigint NOT NULL,
  `domain_id` bigint NOT NULL,
  `payload_json` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `attempts` int NOT NULL DEFAULT '0',
  `next_attempt_at` datetime(6) DEFAULT NULL,
  `lease_owner` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lease_generation` bigint NOT NULL DEFAULT '0',
  `lease_expires_at` datetime(6) DEFAULT NULL,
  `published_at` datetime(6) DEFAULT NULL,
  `last_error` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`intent_id`),
  UNIQUE KEY `uk_chat_delivery_intent_scope_client` (`scope_key_sha256`,`client_msg_id`),
  UNIQUE KEY `uk_chat_delivery_intent_message_uuid` (`message_uuid`),
  UNIQUE KEY `uk_chat_delivery_intent_message_id` (`message_id`),
  KEY `idx_chat_delivery_intent_claim` (`status`,`lease_expires_at`,`created_at`,`intent_id`),
  KEY `idx_chat_delivery_intent_conversation` (`conversation_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_delivery_intent_recipient` (
  `intent_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `recipient_id` bigint NOT NULL,
  `identity_card_id` bigint NOT NULL,
  `user_card_id` bigint NOT NULL,
  `tenant_id` bigint NOT NULL,
  `domain_id` bigint NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`intent_id`,`recipient_id`,`identity_card_id`,`user_card_id`),
  KEY `idx_chat_delivery_intent_recipient_user` (`recipient_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_message` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '消息ID',
  `message_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '消息唯一标识(UUID)',
  `conversation_id` bigint NOT NULL COMMENT '会话ID',
  `sender_id` bigint NOT NULL COMMENT '发送者ID',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '消息类型',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '消息内容',
  `media_url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '媒体文件URL',
  `media_metadata` json DEFAULT NULL COMMENT '媒体元数据',
  `business_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '业务类型',
  `business_id` bigint DEFAULT NULL COMMENT '关联业务ID',
  `reference_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '引用类型',
  `reference_id` bigint DEFAULT NULL COMMENT '引用ID',
  `reference_data` json DEFAULT NULL COMMENT '引用数据快照',
  `reply_to_id` bigint DEFAULT NULL COMMENT '回复消息ID',
  `quote_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '引用内容',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'SENT' COMMENT '状态',
  `recalled_at` datetime DEFAULT NULL COMMENT '撤回时间',
  `domain_id` bigint NOT NULL COMMENT '域ID',
  `client_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '发送客户端类型',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_message_id` (`message_id`),
  KEY `idx_conversation_time` (`conversation_id`,`created_at`),
  KEY `idx_sender` (`sender_id`),
  KEY `idx_domain` (`domain_id`),
  KEY `idx_business` (`business_type`,`business_id`),
  FULLTEXT KEY `ft_content` (`content`) /*!50100 WITH PARSER `ngram` */ 
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='聊天消息表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_message_delivery` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `message_id` bigint NOT NULL COMMENT '消息ID',
  `recipient_id` bigint NOT NULL COMMENT '接收者ID',
  `client_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '目标客户端类型',
  `device_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '目标设备ID',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'PENDING' COMMENT '状态',
  `sent_at` datetime DEFAULT NULL COMMENT '发送时间',
  `delivered_at` datetime DEFAULT NULL COMMENT '送达时间',
  `read_at` datetime DEFAULT NULL COMMENT '阅读时间',
  `failed_at` datetime DEFAULT NULL COMMENT '失败时间',
  `failure_reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '失败原因',
  `retry_count` int DEFAULT '0' COMMENT '重试次数',
  `last_retry_at` datetime DEFAULT NULL COMMENT '最后重试时间',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_message_recipient` (`message_id`,`recipient_id`,`client_type`),
  KEY `idx_recipient` (`recipient_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='消息投递记录表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_read_watermark` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL COMMENT '用户ID',
  `conversation_id` bigint NOT NULL COMMENT '会话ID',
  `max_read_message_id` bigint NOT NULL COMMENT '已读的最大消息ID',
  `read_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '阅读时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_conversation` (`user_id`,`conversation_id`),
  KEY `idx_conversation` (`conversation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='已读水位线表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `departments` (
  `dept_id` bigint NOT NULL AUTO_INCREMENT COMMENT '部门ID',
  `tenant_id` bigint NOT NULL COMMENT '所属根租户ID',
  `sub_tenant_id` bigint DEFAULT NULL COMMENT '所属子租户ID（NULL=直辖部门）',
  `dept_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '部门名称',
  `dept_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '部门编码（同租户下唯一）',
  `parent_dept_id` bigint DEFAULT NULL COMMENT '父部门ID（支持部门嵌套）',
  `sort_order` int NOT NULL DEFAULT '0' COMMENT '排序',
  `status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE' COMMENT 'ACTIVE / SUSPENDED',
  `description` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '部门描述',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`dept_id`),
  UNIQUE KEY `uk_dept_code_tenant` (`tenant_id`,`dept_code`),
  KEY `idx_dept_tenant` (`tenant_id`),
  KEY `idx_dept_sub_tenant` (`sub_tenant_id`),
  KEY `idx_dept_parent` (`parent_dept_id`),
  CONSTRAINT `fk_dept_parent` FOREIGN KEY (`parent_dept_id`) REFERENCES `departments` (`dept_id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_dept_sub_tenant` FOREIGN KEY (`sub_tenant_id`) REFERENCES `tenant` (`tenant_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_dept_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`tenant_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='部门表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `file_type` varchar(64) DEFAULT NULL,
  `file_size` bigint DEFAULT NULL,
  `checksum` varchar(128) DEFAULT NULL,
  `subject_id` bigint DEFAULT NULL,
  `chapter_id` bigint DEFAULT NULL,
  `level_id` bigint DEFAULT NULL,
  `description` text,
  `storage_url` varchar(512) DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT NULL,
  `download_count` int DEFAULT NULL,
  `uploaded_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_documents_subject` (`subject_id`),
  KEY `idx_documents_chapter` (`chapter_id`),
  KEY `idx_documents_level` (`level_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='学习资料表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `domain_resource_type` (
  `resource_type_id` bigint NOT NULL AUTO_INCREMENT,
  `domain_id` bigint DEFAULT NULL COMMENT '所属域（NULL=全局资源）',
  `type_code` varchar(64) NOT NULL COMMENT '资源代码（如 enterprise, user）',
  `type_name` varchar(128) NOT NULL COMMENT '资源名称',
  `type_description` text,
  `sensitivity_level` int NOT NULL DEFAULT '0' COMMENT '敏感度 0-5',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`resource_type_id`),
  UNIQUE KEY `uk_domain_type_code` (`domain_id`,`type_code`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='域资源类型';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `identity_card` (
  `card_id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `status` varchar(32) NOT NULL DEFAULT 'ACTIVE' COMMENT 'ACTIVE|DISABLED|EXPIRED',
  `token_version` bigint NOT NULL DEFAULT '1' COMMENT 'Token 版本号，用于撤销',
  `expires_at` datetime DEFAULT NULL COMMENT '身份证过期时间',
  `disabled_reason` varchar(512) DEFAULT NULL COMMENT '禁用原因',
  `last_used_at` datetime DEFAULT NULL COMMENT '最后使用时间',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`card_id`),
  UNIQUE KEY `uk_ic_user` (`user_id`),
  KEY `idx_ic_status` (`status`),
  CONSTRAINT `fk_ic_user` FOREIGN KEY (`user_id`) REFERENCES `platform_user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='身份卡（身份证）：每人只有一张，用于身份认证';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `identity_global_admin` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `status` varchar(32) NOT NULL DEFAULT 'ACTIVE',
  `granted_by` bigint DEFAULT NULL,
  `granted_reason` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_identity_global_admin_user_id` (`user_id`),
  KEY `idx_identity_global_admin_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='全局管理员';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `identity_level_template` (
  `template_id` bigint NOT NULL AUTO_INCREMENT,
  `template_code` varchar(64) NOT NULL,
  `template_name` varchar(128) NOT NULL,
  `domain_id` bigint NOT NULL,
  `principal_type` varchar(32) NOT NULL COMMENT 'PERSONAL|ENTERPRISE',
  `grant_type` varchar(32) NOT NULL COMMENT 'NORMAL|SPECIAL',
  `level_no` int NOT NULL,
  `user_card_template_id` bigint DEFAULT NULL,
  `status` varchar(32) NOT NULL DEFAULT 'ACTIVE',
  `version_no` int NOT NULL DEFAULT '1',
  `force_cover` tinyint(1) NOT NULL DEFAULT '1',
  `description` varchar(512) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`template_id`),
  UNIQUE KEY `uk_ilt_domain_template_code` (`domain_id`,`template_code`),
  UNIQUE KEY `uk_ilt_scope` (`domain_id`,`principal_type`,`grant_type`,`level_no`,`status`),
  KEY `fk_ilt_card_template` (`user_card_template_id`),
  KEY `idx_ilt_domain_level` (`domain_id`,`level_no`),
  KEY `idx_ilt_status` (`status`),
  CONSTRAINT `fk_ilt_card_template` FOREIGN KEY (`user_card_template_id`) REFERENCES `user_card_template` (`template_id`),
  CONSTRAINT `fk_ilt_domain` FOREIGN KEY (`domain_id`) REFERENCES `platform_domain` (`domain_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='等级模板主表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `identity_level_template_action_map` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `template_id` bigint NOT NULL,
  `action_id` bigint NOT NULL,
  `effect` varchar(16) NOT NULL DEFAULT 'ALLOW',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ilta_template_action` (`template_id`,`action_id`),
  KEY `idx_ilta_action` (`action_id`),
  CONSTRAINT `fk_ilta_action` FOREIGN KEY (`action_id`) REFERENCES `permission_action` (`action_id`),
  CONSTRAINT `fk_ilta_template` FOREIGN KEY (`template_id`) REFERENCES `identity_level_template` (`template_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='等级模板功能映射';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `identity_level_template_resource_map` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `template_id` bigint NOT NULL,
  `resource_type_id` bigint NOT NULL,
  `priority` int NOT NULL DEFAULT '100',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_iltm_template_resource` (`template_id`,`resource_type_id`),
  KEY `fk_iltm_resource` (`resource_type_id`),
  KEY `idx_iltm_template` (`template_id`),
  KEY `idx_iltm_priority` (`priority`),
  CONSTRAINT `fk_iltm_resource` FOREIGN KEY (`resource_type_id`) REFERENCES `domain_resource_type` (`resource_type_id`),
  CONSTRAINT `fk_iltm_template` FOREIGN KEY (`template_id`) REFERENCES `identity_level_template` (`template_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='等级模板资源映射';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `identity_user_grading` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `level_no` int NOT NULL,
  `status` varchar(32) NOT NULL DEFAULT 'ACTIVE',
  `source` varchar(64) DEFAULT NULL,
  `description` varchar(512) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_iug_user_level` (`user_id`,`level_no`),
  KEY `idx_iug_user` (`user_id`),
  KEY `idx_iug_status` (`status`),
  CONSTRAINT `fk_iug_user` FOREIGN KEY (`user_id`) REFERENCES `platform_user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户等级授予';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `integration_identity_mapping` (
  `mapping_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `app_id` varbinary(64) NOT NULL,
  `issuer` varbinary(512) NOT NULL,
  `subject` varbinary(512) NOT NULL,
  `user_id` bigint NOT NULL,
  `identity_card_id` bigint NOT NULL,
  `status` enum('ACTIVE','DISABLED','REVOKED') CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `revision` bigint unsigned NOT NULL DEFAULT '1',
  `created_by` bigint NOT NULL,
  `updated_by` bigint NOT NULL,
  `operation_id` varbinary(64) NOT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`mapping_id`),
  UNIQUE KEY `uq_iim_external_identity` (`app_id`,`issuer`,`subject`),
  KEY `idx_iim_user_id` (`user_id`),
  KEY `idx_iim_identity_card_id` (`identity_card_id`),
  CONSTRAINT `fk_iim_identity_card` FOREIGN KEY (`identity_card_id`) REFERENCES `identity_card` (`card_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_iim_platform_user` FOREIGN KEY (`user_id`) REFERENCES `platform_user` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `integration_identity_mapping_operation` (
  `operation_id` varbinary(64) NOT NULL,
  `request_digest` binary(32) NOT NULL,
  `actor_id` bigint NOT NULL,
  `status` enum('PENDING','COMPLETED') CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `result_revision` bigint unsigned DEFAULT NULL,
  `claim_token` binary(16) DEFAULT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`operation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `leaderboards` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `school_id` bigint DEFAULT NULL,
  `tenant_id` bigint DEFAULT NULL,
  `global_rank` int DEFAULT NULL,
  `school_rank` int DEFAULT NULL,
  `total_score` int DEFAULT NULL,
  `levels_completed` int DEFAULT NULL,
  `questions_answered` int DEFAULT NULL,
  `average_accuracy` decimal(8,2) DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_leaderboards_user` (`user_id`),
  KEY `idx_leaderboards_school` (`school_id`),
  KEY `idx_leaderboards_tenant` (`tenant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='排行榜表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `learn_announcement` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `course_id` bigint NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `author_id` bigint NOT NULL,
  `pinned` tinyint NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_learn_announcement_course` (`course_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='课程公告表（Rust 后端）';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `learn_assignment` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `course_id` bigint NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text,
  `due_date` timestamp NULL DEFAULT NULL,
  `max_score` double NOT NULL DEFAULT '100',
  `status` varchar(32) NOT NULL DEFAULT 'DRAFT',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `system_role` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_learn_assignment_course_system_role` (`course_id`,`system_role`),
  KEY `idx_learn_assignment_course` (`course_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='作业表（Rust 后端）';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `learn_chapter` (
  `chapter_id` bigint NOT NULL AUTO_INCREMENT,
  `subject_id` bigint NOT NULL,
  `domain_id` bigint DEFAULT NULL,
  `chapter_no` varchar(64) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `description` text,
  `content_md` longtext,
  `cover_image` varchar(512) DEFAULT NULL,
  `difficulty` varchar(32) DEFAULT NULL,
  `sort_order` int DEFAULT NULL,
  `parent_chapter_id` bigint DEFAULT NULL,
  `level` int DEFAULT NULL,
  `level_count` int DEFAULT NULL,
  `is_locked` tinyint(1) DEFAULT NULL,
  `video_url` varchar(512) DEFAULT NULL,
  `video_duration` int DEFAULT NULL,
  `document_urls_json` json DEFAULT NULL,
  `learning_objectives_json` json DEFAULT NULL,
  `keywords_json` json DEFAULT NULL,
  `unlock_condition_json` json DEFAULT NULL,
  `estimated_hours` decimal(8,2) DEFAULT NULL,
  `question_count` int DEFAULT NULL,
  `completion_count` int DEFAULT NULL,
  `status` varchar(32) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by_user_id` bigint DEFAULT NULL,
  `tenant_id` bigint DEFAULT NULL,
  PRIMARY KEY (`chapter_id`),
  KEY `idx_learn_chapter_subject` (`subject_id`),
  KEY `idx_learn_chapter_domain` (`domain_id`),
  KEY `idx_learn_chapter_parent` (`parent_chapter_id`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='学习章节表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `learn_class_attendance` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `course_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `date` date DEFAULT NULL,
  `lesson_no` varchar(64) DEFAULT NULL,
  `instructor_user_id` bigint DEFAULT NULL,
  `instructor` varchar(128) DEFAULT NULL,
  `student_number` varchar(64) DEFAULT NULL,
  `student_name` varchar(128) DEFAULT NULL,
  `status` varchar(32) DEFAULT NULL,
  `class_group` varchar(128) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `method` varchar(64) DEFAULT NULL,
  `minutes_late` int DEFAULT NULL,
  `notes` text,
  `photo_url` varchar(512) DEFAULT NULL,
  `checkin_time` datetime DEFAULT NULL,
  `checkout_time` datetime DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `verified_by_user_id` bigint DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_class_attendance_course` (`course_id`),
  KEY `idx_class_attendance_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='课堂考勤表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `learn_course` (
  `course_id` bigint NOT NULL AUTO_INCREMENT,
  `subject_id` bigint DEFAULT NULL,
  `code` varchar(64) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `description` text,
  `academic_year` varchar(32) DEFAULT NULL,
  `semester` varchar(32) DEFAULT NULL,
  `classroom` varchar(128) DEFAULT NULL,
  `class_times_json` json DEFAULT NULL,
  `content_chapters_json` json DEFAULT NULL,
  `capacity` int DEFAULT NULL,
  `enrolled_count` int DEFAULT NULL,
  `instructor_user_id` bigint DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` varchar(32) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by_user_id` bigint DEFAULT NULL,
  `tenant_id` bigint DEFAULT NULL,
  PRIMARY KEY (`course_id`),
  UNIQUE KEY `uk_learn_course_code` (`code`),
  KEY `idx_learn_course_subject` (`subject_id`),
  KEY `idx_learn_course_instructor` (`instructor_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='课程表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `learn_course_enrollment` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `course_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `status` varchar(32) DEFAULT NULL,
  `final_score` decimal(8,2) DEFAULT NULL,
  `attendance_rate` decimal(8,2) DEFAULT NULL,
  `enrolled_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `tenant_id` bigint DEFAULT NULL,
  `progress_pct` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_course_enrollment` (`course_id`,`user_id`),
  KEY `idx_course_enrollment_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='课程报名表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `learn_device` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `device_name` varchar(255) DEFAULT NULL,
  `device_type` varchar(32) DEFAULT NULL,
  `device_id` varchar(255) DEFAULT NULL,
  `last_login_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_learn_device_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='学习设备表（Rust 后端）';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `learn_discussion_post` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `course_id` bigint NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `author_id` bigint NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_learn_discussion_post_course` (`course_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='课程讨论帖表（Rust 后端）';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `learn_lesson` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `chapter_id` bigint NOT NULL,
  `title` varchar(255) NOT NULL,
  `content_type` varchar(32) NOT NULL DEFAULT 'VIDEO',
  `content_url` varchar(512) DEFAULT NULL,
  `duration_minutes` int NOT NULL DEFAULT '0',
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_learn_lesson_chapter` (`chapter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='课时表（Rust 后端）';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `learn_level` (
  `level_id` bigint NOT NULL AUTO_INCREMENT,
  `subject_id` bigint DEFAULT NULL,
  `chapter_id` bigint DEFAULT NULL,
  `domain_id` bigint DEFAULT NULL,
  `code` varchar(64) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `level_type` varchar(64) DEFAULT NULL,
  `difficulty` varchar(32) DEFAULT NULL,
  `description` text,
  `sort_order` int DEFAULT NULL,
  `points` int DEFAULT NULL,
  `question_count` int DEFAULT NULL,
  `total_attempts` int DEFAULT NULL,
  `completed_count` int DEFAULT NULL,
  `average_score` decimal(8,2) DEFAULT NULL,
  `max_attempts` int DEFAULT NULL,
  `pass_score_percentage` decimal(8,2) DEFAULT NULL,
  `time_limit_minutes` int DEFAULT NULL,
  `is_locked` tinyint(1) DEFAULT NULL,
  `badge_url` varchar(512) DEFAULT NULL,
  `prerequisite_level_ids_json` json DEFAULT NULL,
  `unlock_condition_json` json DEFAULT NULL,
  `status` varchar(32) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by_user_id` bigint DEFAULT NULL,
  `tenant_id` bigint DEFAULT NULL,
  PRIMARY KEY (`level_id`),
  UNIQUE KEY `uk_learn_level_code` (`code`),
  KEY `idx_learn_level_subject` (`subject_id`),
  KEY `idx_learn_level_chapter` (`chapter_id`),
  KEY `idx_level_subject_chapter_sort` (`subject_id`,`chapter_id`,`sort_order`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='关卡表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `learn_level_completion` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `level_id` bigint NOT NULL,
  `total_score` int DEFAULT NULL,
  `percentage_score` decimal(8,2) DEFAULT NULL,
  `correct_count` int DEFAULT NULL,
  `attempt_number` int DEFAULT NULL,
  `best_score` int DEFAULT NULL,
  `is_best_attempt` tinyint(1) DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  `spent_minutes` int DEFAULT NULL,
  `total_questions` int DEFAULT NULL,
  `unlocked_next_level` tinyint(1) DEFAULT NULL,
  `feedback` text,
  `tenant_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_level_completion_user` (`user_id`),
  KEY `idx_level_completion_level` (`level_id`),
  KEY `idx_completion_user_level` (`user_id`,`level_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='关卡完成记录表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `learn_level_question` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `level_id` bigint NOT NULL,
  `question_id` bigint NOT NULL,
  `order_no` int DEFAULT NULL,
  `question_type` varchar(64) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `tenant_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_level_question` (`level_id`,`question_id`),
  KEY `idx_level_question_level` (`level_id`),
  KEY `idx_level_question_question` (`question_id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='关卡题目关联表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `learn_level_status` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `level_id` bigint NOT NULL,
  `best_score` int DEFAULT NULL,
  `attempts` int DEFAULT NULL,
  `unlocked_next` tinyint(1) DEFAULT NULL,
  `last_played` datetime DEFAULT NULL,
  `tenant_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_level_status_user` (`user_id`),
  KEY `idx_level_status_level` (`level_id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='关卡状态表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `learn_question` (
  `question_id` bigint NOT NULL AUTO_INCREMENT,
  `subject_id` bigint DEFAULT NULL,
  `chapter_id` bigint DEFAULT NULL,
  `domain_id` bigint DEFAULT NULL,
  `category` varchar(64) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `content` longtext,
  `explanation` longtext,
  `question_type` varchar(64) DEFAULT NULL,
  `difficulty` varchar(32) DEFAULT NULL,
  `options_json` json DEFAULT NULL,
  `answer_text` text,
  `answer_keys_json` json DEFAULT NULL,
  `points` int DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT NULL,
  `review_status` varchar(32) DEFAULT NULL,
  `reviewed_by_user_id` bigint DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `status` varchar(32) DEFAULT NULL,
  `attempt_count` int DEFAULT NULL,
  `correct_count` int DEFAULT NULL,
  `wrong_count` int DEFAULT NULL,
  `accuracy_rate` decimal(8,2) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by_user_id` bigint DEFAULT NULL,
  `tenant_id` bigint DEFAULT NULL,
  PRIMARY KEY (`question_id`),
  KEY `idx_learn_question_subject` (`subject_id`),
  KEY `idx_learn_question_chapter` (`chapter_id`),
  KEY `idx_learn_question_domain` (`domain_id`),
  KEY `idx_question_subject_chapter` (`subject_id`,`chapter_id`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='题目表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `learn_question_first_attempt` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `question_id` bigint NOT NULL,
  `level_id` bigint DEFAULT NULL,
  `subject_id` bigint DEFAULT NULL,
  `chapter_id` bigint DEFAULT NULL,
  `first_attempt_at` datetime DEFAULT NULL,
  `first_attempt_is_correct` tinyint(1) DEFAULT NULL,
  `first_selected_option` varchar(255) DEFAULT NULL,
  `first_selected_options_json` json DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `tenant_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_question_first_attempt` (`user_id`,`question_id`),
  KEY `idx_question_first_attempt_level` (`level_id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='题目首答记录表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `learn_question_solution` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `question_id` bigint NOT NULL COMMENT '题目ID',
  `user_id` bigint NOT NULL COMMENT '提交用户ID',
  `title` varchar(256) DEFAULT NULL COMMENT '题解标题',
  `content` text NOT NULL COMMENT '题解内容',
  `content_type` varchar(32) NOT NULL DEFAULT 'MARKDOWN' COMMENT '内容格式',
  `like_count` int NOT NULL DEFAULT '0' COMMENT '点赞数',
  `view_count` int NOT NULL DEFAULT '0' COMMENT '浏览数',
  `comment_count` int NOT NULL DEFAULT '0' COMMENT '评论数',
  `status` varchar(16) NOT NULL DEFAULT 'ACTIVE' COMMENT 'ACTIVE / HIDDEN / DELETED',
  `is_official` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否官方题解',
  `is_pinned` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否置顶',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `edited_at` datetime DEFAULT NULL COMMENT '最后编辑时间',
  PRIMARY KEY (`id`),
  KEY `idx_lqs_question` (`question_id`),
  KEY `idx_lqs_user` (`user_id`),
  KEY `idx_lqs_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='题解表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `learn_question_summary` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `question_id` bigint NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `subject_id` bigint DEFAULT NULL,
  `chapter_id` bigint DEFAULT NULL,
  `level_id` bigint DEFAULT NULL,
  `course_id` bigint DEFAULT NULL,
  `teacher_user_id` bigint DEFAULT NULL,
  `stage` varchar(64) DEFAULT NULL,
  `students_done` int DEFAULT NULL,
  `students_first_wrong` int DEFAULT NULL,
  `last_aggregated_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_question_summary_question` (`question_id`),
  KEY `idx_question_summary_subject` (`subject_id`),
  KEY `idx_question_summary_chapter` (`chapter_id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='题目汇总表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `learn_solution_like` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `solution_id` bigint NOT NULL COMMENT '题解ID',
  `user_id` bigint NOT NULL COMMENT '点赞用户ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_solution_like_user` (`solution_id`,`user_id`),
  KEY `idx_lsl_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='题解点赞表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `learn_subject` (
  `subject_id` bigint NOT NULL AUTO_INCREMENT,
  `domain_id` bigint DEFAULT NULL,
  `code` varchar(64) NOT NULL,
  `name` varchar(128) NOT NULL,
  `name_en` varchar(128) DEFAULT NULL,
  `category` varchar(64) DEFAULT NULL,
  `parent_subject_id` bigint DEFAULT NULL,
  `level` int DEFAULT NULL,
  `sort_order` int DEFAULT NULL,
  `description` text,
  `theme_color` varchar(32) DEFAULT NULL,
  `cover_image` varchar(512) DEFAULT NULL,
  `icon_url` varchar(512) DEFAULT NULL,
  `chapter_count` int DEFAULT NULL,
  `question_count` int DEFAULT NULL,
  `student_count` int DEFAULT NULL,
  `status` varchar(32) DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by_user_id` bigint DEFAULT NULL,
  `tenant_id` bigint DEFAULT NULL,
  PRIMARY KEY (`subject_id`),
  UNIQUE KEY `uk_learn_subject_code` (`code`),
  KEY `idx_learn_subject_domain` (`domain_id`),
  KEY `idx_learn_subject_parent` (`parent_subject_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='学习学科表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `learn_submission` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `assignment_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `content` text,
  `file_url` varchar(512) DEFAULT NULL,
  `score` double DEFAULT NULL,
  `feedback` text,
  `graded` tinyint NOT NULL DEFAULT '0',
  `status` varchar(32) NOT NULL DEFAULT 'SUBMITTED',
  `submitted_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_learn_submission` (`assignment_id`,`user_id`),
  KEY `idx_learn_submission_assignment` (`assignment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='作业提交表（Rust 后端）';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `learn_user_answer` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `level_id` bigint DEFAULT NULL,
  `question_id` bigint NOT NULL,
  `is_correct` tinyint(1) DEFAULT NULL,
  `points_earned` int DEFAULT NULL,
  `time_spent_seconds` int DEFAULT NULL,
  `user_answer_text` text,
  `user_answer_json` json DEFAULT NULL,
  `answered_at` datetime DEFAULT NULL,
  `device_info` varchar(512) DEFAULT NULL,
  `ip_address` varchar(64) DEFAULT NULL,
  `tenant_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_learn_user_answer_user` (`user_id`),
  KEY `idx_learn_user_answer_level` (`level_id`),
  KEY `idx_learn_user_answer_question` (`question_id`),
  KEY `idx_answer_user_level` (`user_id`,`level_id`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户答题记录表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `learn_user_profile` (
  `user_id` bigint NOT NULL,
  `domain_id` bigint DEFAULT NULL,
  `score` int DEFAULT NULL,
  `current_level_no` int DEFAULT NULL,
  `total_study_minutes` int DEFAULT NULL,
  `last_login_at` datetime DEFAULT NULL,
  `last_subject_id` bigint DEFAULT NULL,
  `nickname` varchar(128) DEFAULT NULL,
  `avatar_url` varchar(512) DEFAULT NULL,
  `status` varchar(32) DEFAULT NULL,
  `completed_chapters` int DEFAULT NULL,
  `total_chapters` int DEFAULT NULL,
  `completed_percent` decimal(8,2) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `tenant_id` bigint DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  KEY `idx_learn_user_profile_domain` (`domain_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='学习用户档案表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `learn_user_subject` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `subject_id` bigint NOT NULL,
  `domain_id` bigint DEFAULT NULL,
  `selected_at` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `tenant_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_learn_user_subject` (`user_id`,`subject_id`),
  KEY `idx_learn_user_subject_domain` (`domain_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户学科关联表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `learn_wrong_question` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL COMMENT '用户ID',
  `question_id` bigint NOT NULL COMMENT '题目ID',
  `subject_id` bigint DEFAULT NULL COMMENT '学科ID',
  `chapter_id` bigint DEFAULT NULL COMMENT '章节ID',
  `level_id` bigint DEFAULT NULL COMMENT '关卡ID',
  `wrong_answer` text COMMENT '错误答案',
  `wrong_count` int NOT NULL DEFAULT '1' COMMENT '错误次数',
  `first_wrong_at` datetime DEFAULT NULL COMMENT '首次错误时间',
  `last_wrong_at` datetime DEFAULT NULL COMMENT '最近错误时间',
  `is_reviewed` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否已复习',
  `reviewed_at` datetime DEFAULT NULL COMMENT '复习时间',
  `review_count` int NOT NULL DEFAULT '0' COMMENT '复习次数',
  `is_mastered` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否已掌握',
  `mastered_at` datetime DEFAULT NULL COMMENT '掌握时间',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_lwq_user` (`user_id`),
  KEY `idx_lwq_question` (`question_id`),
  KEY `idx_lwq_mastered` (`is_mastered`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='错题本表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mfa_attempt_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `mfa_type` varchar(32) NOT NULL,
  `attempt_code` varchar(64) DEFAULT NULL,
  `status` varchar(32) NOT NULL DEFAULT 'UNKNOWN',
  `success` tinyint(1) NOT NULL DEFAULT '0',
  `failure_reason` varchar(512) DEFAULT NULL,
  `attempted_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ip` varchar(64) DEFAULT NULL,
  `user_agent` varchar(512) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_mal_attempt_code` (`attempt_code`),
  KEY `idx_mal_created` (`created_at`),
  KEY `idx_mal_user` (`user_id`),
  KEY `idx_mal_user_attempt_status` (`user_id`,`attempted_at`,`success`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='MFA 尝试日志';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `monitor_activity_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `event_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '事件类型',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '事件标题',
  `detail` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '事件详情',
  `level` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'info' COMMENT '级别（info / warn / error）',
  `source_service` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '来源服务',
  `occurred_at` timestamp NOT NULL COMMENT '发生时间',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_mal_event_type` (`event_type`),
  KEY `idx_mal_level` (`level`),
  KEY `idx_mal_source` (`source_service`),
  KEY `idx_mal_occurred` (`occurred_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `monitor_alert_history` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `rule_id` bigint NOT NULL COMMENT '关联告警规则ID',
  `rule_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '告警规则名称（快照）',
  `metric_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '指标类型',
  `actual_value` double DEFAULT NULL COMMENT '触发时的实际值',
  `severity` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'WARNING' COMMENT '严重级别',
  `status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'triggered' COMMENT 'triggered / acknowledged / resolved',
  `triggered_at` timestamp NOT NULL COMMENT '触发时间',
  `resolved_at` timestamp NULL DEFAULT NULL COMMENT '确认/解决时间',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_mah_rule` (`rule_id`),
  KEY `idx_mah_status` (`status`),
  KEY `idx_mah_severity` (`severity`),
  KEY `idx_mah_triggered` (`triggered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `monitor_metric_snapshot` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `service_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '服务名称',
  `metric_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '指标类型（latency / reachable / cpu_usage / memory_usage 等）',
  `metric_value` double NOT NULL,
  `collected_at` timestamp NOT NULL COMMENT '采集时间',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_mms_service` (`service_name`),
  KEY `idx_mms_type` (`metric_type`),
  KEY `idx_mms_collected` (`collected_at`),
  KEY `idx_mms_service_type` (`service_name`,`metric_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mq_consumer_lease` (
  `idem_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'public IDEM key: mq:idempotent:<message_type>:<message_id>',
  `message_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `message_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload_sha256` char(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'lowercase sha256 of the raw delivery body; NULL = legacy claim without digest, exact-duplicate enforcement requires both digests',
  `status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PROCESSING' COMMENT 'PROCESSING / COMPLETED',
  `lease_owner` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'run-scoped consumer identity that holds (or last held) the lease',
  `lease_token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'per-claim CAS token; renew/complete/release must match it exactly',
  `lease_generation` bigint NOT NULL DEFAULT '0' COMMENT 'monotonic per (message_type, message_id); incremented on every takeover',
  `claim_attempts` int NOT NULL DEFAULT '0' COMMENT 'observability only; broker DLX retry budget is bounded elsewhere',
  `lease_expires_at` datetime(6) DEFAULT NULL COMMENT 'server-side lease TTL; NULL = released or completed',
  `completed_at` datetime(6) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`message_type`,`message_id`),
  UNIQUE KEY `uk_mq_consumer_lease_idem_key` (`idem_key`),
  KEY `idx_mq_consumer_lease_active` (`status`,`lease_expires_at`),
  KEY `idx_mq_consumer_lease_completed` (`status`,`completed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mq_idempotent_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `message_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `message_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PROCESSED',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_mq_msg` (`message_type`,`message_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_channel` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `channel_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'EMAIL',
  `config` json DEFAULT NULL,
  `enabled` tinyint NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL,
  `webhook_config_id` bigint DEFAULT NULL,
  `notification_type` varchar(64) DEFAULT NULL,
  `event_type` varchar(64) DEFAULT NULL,
  `event_data` json DEFAULT NULL,
  `status` varchar(32) DEFAULT NULL,
  `status_code` int DEFAULT NULL,
  `response_text` text,
  `error_message` text,
  `attempt_count` int DEFAULT NULL,
  `last_attempt_at` datetime DEFAULT NULL,
  `recipient` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_notifications_user` (`user_id`),
  KEY `idx_notifications_webhook` (`webhook_config_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='通知表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `org_scope_audit` (
  `audit_id` bigint NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint NOT NULL,
  `actor_user_id` bigint NOT NULL,
  `actor_tenant_id` bigint DEFAULT NULL,
  `action` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_kind` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `request_id` bigint DEFAULT NULL,
  `operation_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `detail_json` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`audit_id`),
  KEY `idx_osau_tenant` (`tenant_id`,`created_at`),
  KEY `idx_osau_operation` (`operation_id`),
  KEY `idx_osau_request` (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Org-scope durable audit trail correlated per operation';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `org_scope_current` (
  `tenant_id` bigint NOT NULL,
  `publication_id` bigint NOT NULL,
  `generation` bigint NOT NULL,
  `manifest_digest` binary(32) NOT NULL,
  `revoke_fence` bigint NOT NULL,
  `cas_version` bigint NOT NULL DEFAULT '0',
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`tenant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Current sealed publication pointer per managed unit (generation CAS)';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `org_scope_dependency` (
  `dependency_id` bigint NOT NULL AUTO_INCREMENT,
  `dependent_tenant_id` bigint NOT NULL,
  `depends_on_tenant_id` bigint NOT NULL,
  `publication_id` bigint NOT NULL,
  `pinned_generation` bigint NOT NULL,
  `pinned_revoke_fence` bigint NOT NULL,
  `pinned_relationship_revision` bigint NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`dependency_id`),
  UNIQUE KEY `uk_osd_pin` (`dependent_tenant_id`,`depends_on_tenant_id`,`publication_id`),
  KEY `idx_osd_fanout` (`depends_on_tenant_id`,`dependent_tenant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Durable dependency pins for fan-out and freshness validation';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `org_scope_grant` (
  `grant_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `revision` bigint NOT NULL DEFAULT '1',
  `receiving_tenant_id` bigint NOT NULL,
  `origin_tenant_id` bigint NOT NULL,
  `root_tenant_id` bigint NOT NULL,
  `resource_tenant_id` bigint NOT NULL,
  `domain_id` bigint DEFAULT NULL,
  `resource` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `action` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `valid_from` bigint DEFAULT NULL,
  `valid_until` bigint DEFAULT NULL,
  `delegable` tinyint NOT NULL DEFAULT '0',
  `parent_tenant_id` bigint DEFAULT NULL,
  `parent_grant_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_grant_revision` bigint DEFAULT NULL,
  `subject_kind` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_user_id` bigint DEFAULT NULL,
  `subject_card_id` bigint DEFAULT NULL,
  `active` tinyint NOT NULL DEFAULT '1',
  `operation_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`grant_id`),
  KEY `idx_osg_receiving` (`receiving_tenant_id`,`active`),
  KEY `idx_osg_origin` (`origin_tenant_id`,`active`),
  KEY `idx_osg_root` (`root_tenant_id`,`active`),
  KEY `idx_osg_resource` (`resource_tenant_id`,`resource`,`action`),
  CONSTRAINT `chk_osg_parent` CHECK ((((`parent_tenant_id` is null) and (`parent_grant_id` is null) and (`parent_grant_revision` is null)) or ((`parent_tenant_id` is not null) and (`parent_grant_id` is not null) and (`parent_grant_revision` is not null) and (`parent_tenant_id` = `origin_tenant_id`) and (`parent_grant_id` <> `grant_id`)))),
  CONSTRAINT `chk_osg_subject` CHECK ((((`subject_kind` = _utf8mb4'UNIT') and (`subject_user_id` is null) and (`subject_card_id` is null)) or ((`subject_kind` = _utf8mb4'PERSONAL') and (`subject_user_id` is not null) and (`subject_card_id` is not null) and (`subject_user_id` > 0) and (`subject_card_id` > 0))))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Org-scope approved scope grants (current state)';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `org_scope_mask` (
  `mask_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenant_id` bigint NOT NULL,
  `target_tenant_id` bigint NOT NULL,
  `target_grant_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_grant_revision` bigint NOT NULL,
  `revision` bigint NOT NULL DEFAULT '1',
  `active` tinyint NOT NULL DEFAULT '1',
  `active_flag` tinyint GENERATED ALWAYS AS (if((`active` = 1),1,NULL)) STORED,
  `operation_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`mask_id`),
  UNIQUE KEY `uk_osm_active` (`tenant_id`,`target_grant_id`,`active_flag`),
  KEY `idx_osm_target` (`target_grant_id`,`active`),
  KEY `idx_osm_tenant` (`tenant_id`,`active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Local exact-origin grant masks; local overlay, not source deletion';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `org_scope_membership` (
  `membership_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenant_id` bigint NOT NULL,
  `root_tenant_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `identity_card_id` bigint NOT NULL,
  `card_id` bigint NOT NULL,
  `revision` bigint NOT NULL DEFAULT '1',
  `active` tinyint NOT NULL DEFAULT '1',
  `active_card_flag` tinyint GENERATED ALWAYS AS (if((`active` = 1),1,NULL)) STORED,
  `valid_from` bigint DEFAULT NULL,
  `valid_until` bigint DEFAULT NULL,
  `operation_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`membership_id`),
  UNIQUE KEY `uk_osmem_active_card` (`card_id`,`active_card_flag`),
  KEY `idx_osmem_unit` (`tenant_id`,`user_id`,`active`),
  KEY `idx_osmem_card` (`card_id`,`active`),
  KEY `idx_osmem_root` (`root_tenant_id`),
  KEY `idx_osmem_user_active` (`user_id`,`active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Org-scope memberships binding card pairs to managed units';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `org_scope_node` (
  `tenant_id` bigint NOT NULL,
  `root_tenant_id` bigint NOT NULL,
  `parent_tenant_id` bigint DEFAULT NULL,
  `generation` bigint NOT NULL DEFAULT '1',
  `revoke_fence` bigint NOT NULL DEFAULT '0',
  `relationship_revision` bigint NOT NULL DEFAULT '1',
  `active` tinyint NOT NULL DEFAULT '1',
  `created_request_id` bigint NOT NULL,
  `created_operation_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_operation_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `activation_operator_user_id` bigint DEFAULT NULL,
  `activation_approval_operation_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`tenant_id`),
  KEY `idx_osn_root` (`root_tenant_id`),
  KEY `idx_osn_parent` (`parent_tenant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Org-scope administrative tree node; one unit aggregate per tenant';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `org_scope_operation` (
  `operation_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `operation_kind` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenant_id` bigint NOT NULL,
  `input_digest` binary(32) NOT NULL,
  `outcome_json` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`operation_id`),
  KEY `idx_osop_tenant` (`tenant_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Operation-id idempotency ledger with exact input digest binding';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `org_scope_outbox` (
  `org_event_id` bigint NOT NULL AUTO_INCREMENT,
  `event_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenant_id` bigint NOT NULL,
  `event_kind` varchar(48) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `operation_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload_json` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `attempts` int NOT NULL DEFAULT '0',
  `next_attempt_at` datetime(6) DEFAULT NULL,
  `lease_owner` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lease_token_hash` binary(32) DEFAULT NULL,
  `lease_expires_at` datetime(6) DEFAULT NULL,
  `cas_version` bigint NOT NULL DEFAULT '0',
  `last_error` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`org_event_id`),
  UNIQUE KEY `uk_oso_event` (`event_id`),
  KEY `idx_oso_due` (`status`,`next_attempt_at`,`created_at`),
  KEY `idx_oso_tenant` (`tenant_id`,`status`),
  KEY `idx_oso_operation` (`operation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Org-scope outbox events for the new org worker (org payload contract)';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `org_scope_publication` (
  `publication_id` bigint NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint NOT NULL,
  `root_tenant_id` bigint NOT NULL,
  `generation` bigint NOT NULL,
  `relationship_revision` bigint NOT NULL,
  `revoke_fence` bigint NOT NULL,
  `dependencies_json` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `dependency_digest` binary(32) NOT NULL,
  `manifest_digest` binary(32) NOT NULL,
  `compiler_version` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `segment_count` int NOT NULL DEFAULT '0',
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'SEALED',
  `operation_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`publication_id`),
  UNIQUE KEY `uk_osp_generation` (`tenant_id`,`generation`),
  KEY `idx_osp_tenant` (`tenant_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Immutable sealed org-scope publications (insert-only)';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `org_scope_request` (
  `request_id` bigint NOT NULL AUTO_INCREMENT,
  `request_kind` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `requester_tenant_id` bigint NOT NULL,
  `requester_user_id` bigint NOT NULL,
  `target_tenant_id` bigint NOT NULL,
  `parent_tenant_id` bigint DEFAULT NULL,
  `payload_json` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `revision` bigint NOT NULL DEFAULT '1',
  `operation_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `operation_digest` binary(32) NOT NULL,
  `decided_by` bigint DEFAULT NULL,
  `decided_at` datetime(6) DEFAULT NULL,
  `decision_note` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`request_id`),
  UNIQUE KEY `uk_osr_operation` (`operation_id`),
  KEY `idx_osr_target_status` (`target_tenant_id`,`status`),
  KEY `idx_osr_status` (`status`,`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Org-scope approval requests; source of truth for authority mutations';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `org_scope_revision` (
  `revision_row_id` bigint NOT NULL AUTO_INCREMENT,
  `subject_kind` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenant_id` bigint NOT NULL,
  `subject_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `revision` bigint NOT NULL,
  `payload_json` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload_digest` binary(32) NOT NULL,
  `operation_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`revision_row_id`),
  UNIQUE KEY `uk_osv_subject` (`subject_kind`,`subject_id`,`revision`),
  KEY `idx_osv_tenant` (`tenant_id`,`subject_kind`,`created_at`),
  KEY `idx_osv_operation` (`operation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Append-only typed revision ledger for org-scope subjects';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `org_scope_segment` (
  `segment_id` bigint NOT NULL AUTO_INCREMENT,
  `publication_id` bigint NOT NULL,
  `segment_index` int NOT NULL,
  `segment_digest` binary(32) NOT NULL,
  `content_json` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`segment_id`),
  UNIQUE KEY `uk_oss_position` (`publication_id`,`segment_index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Sealed segments of one org-scope publication (insert-only)';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pending_compensation` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `entity_id` bigint NOT NULL COMMENT '关联实体 ID（card_id / rule_set_id）',
  `op_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '操作类型：REBUILD_SNAPSHOT / EVICT_CACHE / FIND_BOUND_CARDS',
  `error_msg` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '错误信息',
  `status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING' COMMENT 'PENDING / COMPLETED / FAILED',
  `retry_count` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_entity` (`entity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permission_action` (
  `action_id` bigint NOT NULL AUTO_INCREMENT,
  `domain_id` bigint DEFAULT NULL,
  `resource_type_id` bigint NOT NULL,
  `action_code` varchar(64) NOT NULL COMMENT '动作代码（如 read, write, delete）',
  `action_name` varchar(128) NOT NULL,
  `action_description` text,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`action_id`),
  UNIQUE KEY `uk_resource_action` (`resource_type_id`,`action_code`),
  KEY `idx_action_domain` (`domain_id`)
) ENGINE=InnoDB AUTO_INCREMENT=632 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='权限动作';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permission_delegation` (
  `delegation_id` bigint NOT NULL AUTO_INCREMENT,
  `delegator_card_id` bigint NOT NULL COMMENT '委托方卡片ID',
  `delegate_card_id` bigint NOT NULL COMMENT '被委托方卡片ID',
  `resource_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '委托的资源类型',
  `action_code` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '委托的动作',
  `effective_from` datetime NOT NULL,
  `effective_until` datetime NOT NULL,
  `max_duration_hours` int DEFAULT '24',
  `is_revokable` tinyint(1) DEFAULT '1',
  `delegated_at` datetime NOT NULL,
  `revoked_at` datetime DEFAULT NULL,
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'ACTIVE',
  PRIMARY KEY (`delegation_id`),
  KEY `idx_delegator` (`delegator_card_id`),
  KEY `idx_delegate` (`delegate_card_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permission_hit_stat` (
  `card_id` bigint NOT NULL,
  `resource_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `action_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `hit_count` bigint DEFAULT '0',
  `last_hit_at` datetime DEFAULT NULL,
  PRIMARY KEY (`card_id`,`resource_type`,`action_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permission_request` (
  `request_id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL COMMENT '申请人ID',
  `request_type` varchar(32) NOT NULL COMMENT '申请类型: RULE / LEVEL_UP / TEMP_PERMISSION',
  `request_content` text COMMENT '申请内容JSON',
  `reason` varchar(512) DEFAULT NULL COMMENT '申请原因',
  `status` varchar(32) NOT NULL DEFAULT 'PENDING' COMMENT 'PENDING / APPROVED / REJECTED / CANCELLED',
  `approver_id` bigint DEFAULT NULL COMMENT '审批人ID',
  `approved_at` datetime DEFAULT NULL COMMENT '审批时间',
  `approve_comment` varchar(512) DEFAULT NULL COMMENT '审批意见',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`request_id`),
  KEY `idx_pr_user` (`user_id`),
  KEY `idx_pr_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='权限申请表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permission_rule` (
  `rule_id` bigint NOT NULL AUTO_INCREMENT,
  `card_id` bigint NOT NULL COMMENT '用户卡ID',
  `resource_type` varchar(64) NOT NULL COMMENT '资源类型编码',
  `resource_id` bigint DEFAULT NULL COMMENT '资源ID，可为空表示资源类型级',
  `action_code` varchar(64) NOT NULL COMMENT '动作编码',
  `effect` varchar(16) NOT NULL DEFAULT 'ALLOW' COMMENT 'ALLOW / DENY',
  `condition_json` text COMMENT '规则条件JSON',
  `priority` int NOT NULL DEFAULT '0' COMMENT '优先级，越大越先匹配',
  `source_type` varchar(32) NOT NULL DEFAULT 'MANUAL' COMMENT 'MANUAL / TEMPLATE / SYSTEM',
  `source_id` bigint DEFAULT NULL COMMENT '来源ID',
  `valid_from` datetime DEFAULT NULL COMMENT '生效时间',
  `valid_to` datetime DEFAULT NULL COMMENT '失效时间',
  `enabled` tinyint NOT NULL DEFAULT '1' COMMENT '是否启用',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `tenant_id` bigint DEFAULT NULL,
  PRIMARY KEY (`rule_id`),
  KEY `idx_permission_rule_card_scope` (`card_id`,`resource_type`,`action_code`,`enabled`,`priority`),
  KEY `idx_permission_rule_effective` (`card_id`,`enabled`,`valid_from`,`valid_to`),
  CONSTRAINT `fk_permission_rule_card` FOREIGN KEY (`card_id`) REFERENCES `user_card` (`card_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1157225487810008 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='权限规则表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permission_rule_audit_log` (
  `audit_id` bigint NOT NULL AUTO_INCREMENT,
  `rule_id` bigint DEFAULT NULL,
  `card_id` bigint DEFAULT NULL,
  `changed_by` bigint DEFAULT NULL COMMENT '操作人用户ID',
  `change_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'CREATE/UPDATE/DELETE',
  `old_value_json` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '变更前完整快照',
  `new_value_json` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '变更后完整快照',
  `changed_at` datetime NOT NULL,
  `ip_address` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`audit_id`),
  KEY `idx_rule` (`rule_id`),
  KEY `idx_card` (`card_id`),
  KEY `idx_changed_at` (`changed_at`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permission_rule_template` (
  `template_rule_id` bigint NOT NULL AUTO_INCREMENT COMMENT '规则模板条目ID',
  `template_id` bigint NOT NULL COMMENT '用户卡模板ID，引用 user_card_template.template_id',
  `resource_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '资源类型（如 course, question, subject）',
  `resource_id` bigint DEFAULT NULL COMMENT '资源ID，NULL 表示该类型下所有资源',
  `action_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '动作编码（如 read, write, delete）',
  `effect` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ALLOW' COMMENT 'ALLOW / DENY',
  `condition_json` json DEFAULT NULL COMMENT 'ABAC 条件（预留）',
  `priority` int NOT NULL DEFAULT '0' COMMENT '优先级，越大越优先',
  `enabled` tinyint NOT NULL DEFAULT '1' COMMENT '是否启用：1=启用，0=禁用',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`template_rule_id`),
  UNIQUE KEY `uk_prt_template_resource_action` (`template_id`,`resource_type`,`action_code`),
  KEY `idx_prt_template` (`template_id`),
  CONSTRAINT `fk_prt_template` FOREIGN KEY (`template_id`) REFERENCES `user_card_template` (`template_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=548 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='规则模板表：模板级规则定义，发放时实例化到 user_card';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `platform_domain` (
  `domain_id` bigint NOT NULL AUTO_INCREMENT,
  `domain_code` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `domain_name` varchar(128) NOT NULL,
  `domain_description` varchar(512) DEFAULT NULL,
  `status` varchar(32) NOT NULL DEFAULT 'ACTIVE',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`domain_id`),
  UNIQUE KEY `uk_pd_domain_code` (`domain_code`)
) ENGINE=InnoDB AUTO_INCREMENT=1157225487810002 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='模块域（Chat/Learn/Identity/TrustGraph 等）';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `platform_package` (
  `package_id` bigint NOT NULL AUTO_INCREMENT,
  `package_name` varchar(64) NOT NULL,
  `package_code` varchar(64) NOT NULL,
  `description` varchar(512) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT '0.00',
  `status` varchar(16) DEFAULT 'ACTIVE',
  `version_no` int DEFAULT '1',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`package_id`),
  UNIQUE KEY `uk_pkg_code` (`package_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='方案包定义';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `platform_package_domain_ref` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `package_id` bigint NOT NULL,
  `domain_id` bigint NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ppdr_pkg_domain` (`package_id`,`domain_id`),
  KEY `fk_ppdr_domain` (`domain_id`),
  CONSTRAINT `fk_ppdr_domain` FOREIGN KEY (`domain_id`) REFERENCES `platform_domain` (`domain_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ppdr_package` FOREIGN KEY (`package_id`) REFERENCES `platform_package` (`package_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='方案包-域关联';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `platform_package_rule_set_ref` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `package_id` bigint NOT NULL,
  `rule_set_id` bigint NOT NULL,
  `role_type` varchar(16) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_pprsr_pkg_rule_role` (`package_id`,`rule_set_id`,`role_type`),
  KEY `fk_pprsr_rule_set` (`rule_set_id`),
  CONSTRAINT `fk_pprsr_package` FOREIGN KEY (`package_id`) REFERENCES `platform_package` (`package_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pprsr_rule_set` FOREIGN KEY (`rule_set_id`) REFERENCES `rule_set` (`rule_set_id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='方案包-规则集关联';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `platform_user` (
  `user_id` bigint NOT NULL AUTO_INCREMENT,
  `user_no` varchar(64) NOT NULL,
  `display_name` varchar(128) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(32) DEFAULT NULL,
  `avatar_url` varchar(512) DEFAULT NULL,
  `source_type` varchar(64) NOT NULL DEFAULT 'LOCAL' COMMENT '账户来源类型',
  `status` varchar(32) NOT NULL DEFAULT 'ACTIVE',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `uk_pu_user_no` (`user_no`),
  KEY `idx_pu_email` (`email`),
  KEY `idx_pu_phone` (`phone`),
  KEY `idx_pu_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=1157225487810003 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='平台用户';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rule_set` (
  `rule_set_id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '规则集名称',
  `code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '规则集编码',
  `description` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '描述',
  `source_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'TEMPLATE' COMMENT 'TEMPLATE / OVERLAY',
  `source_id` bigint DEFAULT NULL COMMENT '来源ID（如模板ID）',
  `enabled` tinyint NOT NULL DEFAULT '1' COMMENT '是否启用',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `tenant_id` bigint DEFAULT NULL COMMENT 'tenant_id',
  PRIMARY KEY (`rule_set_id`),
  UNIQUE KEY `uk_rule_set_code` (`code`),
  KEY `idx_rule_set_source` (`source_type`,`source_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1157225487810005 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='规则集';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rule_set_audit_log` (
  `audit_id` bigint NOT NULL AUTO_INCREMENT,
  `rule_set_id` bigint NOT NULL COMMENT '规则集ID',
  `entry_id` bigint DEFAULT NULL COMMENT '条目ID',
  `changed_by` bigint NOT NULL COMMENT '操作人ID',
  `change_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'CREATE / UPDATE / DELETE / REBUILD_SNAPSHOT',
  `old_value_json` json DEFAULT NULL COMMENT '变更前值',
  `new_value_json` json DEFAULT NULL COMMENT '变更后值',
  `changed_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `tenant_id` bigint DEFAULT NULL,
  PRIMARY KEY (`audit_id`),
  KEY `idx_rsal_rule_set` (`rule_set_id`),
  KEY `idx_rsal_changed_by` (`changed_by`),
  CONSTRAINT `fk_rsal_rule_set` FOREIGN KEY (`rule_set_id`) REFERENCES `rule_set` (`rule_set_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='规则集审计日志';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rule_set_entry` (
  `entry_id` bigint NOT NULL AUTO_INCREMENT,
  `rule_set_id` bigint NOT NULL COMMENT '所属规则集ID',
  `resource_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '资源类型',
  `resource_id` bigint DEFAULT NULL COMMENT '资源ID（NULL表示类型级）',
  `action_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '动作编码',
  `effect` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ALLOW' COMMENT 'ALLOW / DENY',
  `condition_json` json DEFAULT NULL COMMENT 'ABAC条件',
  `priority` int NOT NULL DEFAULT '0' COMMENT '优先级，越大越优先',
  `enabled` tinyint NOT NULL DEFAULT '1' COMMENT '是否启用',
  `valid_from` datetime DEFAULT NULL COMMENT '生效时间',
  `valid_to` datetime DEFAULT NULL COMMENT '失效时间',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `tenant_id` bigint DEFAULT NULL,
  PRIMARY KEY (`entry_id`),
  KEY `idx_rule_set_entry` (`rule_set_id`,`enabled`,`priority`),
  CONSTRAINT `fk_rse_rule_set` FOREIGN KEY (`rule_set_id`) REFERENCES `rule_set` (`rule_set_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1157225487810006 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='规则集条目';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rule_set_projection_audit` (
  `audit_id` bigint NOT NULL AUTO_INCREMENT,
  `rule_set_id` bigint NOT NULL,
  `entry_id` bigint DEFAULT NULL,
  `changed_by` bigint NOT NULL,
  `change_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `old_value_json` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `new_value_json` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `changed_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `tenant_id` bigint DEFAULT NULL,
  `aggregate_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `aggregate_id` bigint NOT NULL,
  `event_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_generation` bigint NOT NULL,
  `operation_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`audit_id`),
  UNIQUE KEY `uk_rsp_audit_event_generation` (`event_id`,`source_generation`,`change_type`),
  KEY `idx_rsp_audit_rule_set_generation` (`rule_set_id`,`source_generation`),
  KEY `idx_rsp_audit_operation` (`operation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Rust-owned RuleSet source/projection audit correlation';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `school_members` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `school_id` bigint NOT NULL,
  `tenant_id` bigint DEFAULT NULL,
  `user_id` bigint NOT NULL,
  `member_type` varchar(32) NOT NULL,
  `student_number` varchar(64) DEFAULT NULL,
  `department` varchar(128) DEFAULT NULL,
  `major` varchar(128) DEFAULT NULL,
  `grade` varchar(64) DEFAULT NULL,
  `class_name` varchar(128) DEFAULT NULL,
  `status` varchar(32) NOT NULL DEFAULT 'ACTIVE',
  `joined_at` datetime DEFAULT NULL,
  `left_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_school_members_school` (`school_id`),
  KEY `idx_school_members_user` (`user_id`),
  KEY `idx_school_members_status` (`status`),
  KEY `idx_school_members_tenant` (`tenant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='学校成员表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `school_tenant_migration` (
  `school_id` bigint NOT NULL,
  `tenant_id` bigint NOT NULL,
  `tenant_code` varchar(64) NOT NULL,
  `migration_status` varchar(32) NOT NULL DEFAULT 'MIGRATED',
  `migrated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `verified_at` datetime DEFAULT NULL,
  `rollback_note` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`school_id`),
  UNIQUE KEY `uk_school_tenant_migration_tenant` (`tenant_id`),
  UNIQUE KEY `uk_school_tenant_migration_code` (`tenant_code`),
  KEY `idx_school_tenant_migration_status` (`migration_status`),
  CONSTRAINT `fk_school_tenant_migration_school` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_school_tenant_migration_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`tenant_id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Schools to tenants migration audit mapping';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schools` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(64) NOT NULL COMMENT '学校代码',
  `name` varchar(128) NOT NULL COMMENT '学校名称',
  `name_en` varchar(128) DEFAULT NULL COMMENT '英文名称',
  `type` varchar(32) DEFAULT NULL COMMENT '机构类型',
  `contact_person` varchar(64) DEFAULT NULL COMMENT '联系人',
  `contact_phone` varchar(32) DEFAULT NULL COMMENT '联系电话',
  `contact_email` varchar(128) DEFAULT NULL COMMENT '联系邮箱',
  `country` varchar(16) DEFAULT NULL COMMENT '国家代码',
  `province` varchar(64) DEFAULT NULL COMMENT '省份',
  `city` varchar(64) DEFAULT NULL COMMENT '城市',
  `district` varchar(64) DEFAULT NULL COMMENT '区县',
  `address` varchar(512) DEFAULT NULL COMMENT '详细地址',
  `postal_code` varchar(32) DEFAULT NULL COMMENT '邮编',
  `logo_url` varchar(512) DEFAULT NULL COMMENT 'Logo URL',
  `website` varchar(512) DEFAULT NULL COMMENT '官网',
  `description` text COMMENT '简介',
  `timezone` varchar(64) DEFAULT NULL COMMENT '时区',
  `locale` varchar(16) DEFAULT NULL COMMENT '语言地区',
  `settings` json DEFAULT NULL COMMENT '学校配置JSON',
  `status` varchar(16) NOT NULL DEFAULT 'ACTIVE' COMMENT '状态',
  `verified` tinyint(1) DEFAULT '0' COMMENT '是否认证',
  `verified_at` datetime DEFAULT NULL COMMENT '认证时间',
  `student_count` int DEFAULT '0' COMMENT '学生数',
  `teacher_count` int DEFAULT '0' COMMENT '教师数',
  `course_count` int DEFAULT '0' COMMENT '课程数',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint DEFAULT NULL COMMENT '创建人ID',
  `domain_id` bigint DEFAULT NULL,
  `tenant_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_school_code` (`code`),
  KEY `idx_schools_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='学校/机构表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sod_policy` (
  `policy_id` bigint NOT NULL AUTO_INCREMENT,
  `policy_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `conflict_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'STATIC / DYNAMIC / BEHAVIORAL',
  `resource_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '资源类型（动态/行为类需要）',
  `action_code` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '动作代码（动态/行为类需要）',
  `permission_a` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '互斥权限 A，如 question:create',
  `permission_b` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '互斥权限 B，如 question:publish',
  `condition_script` varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '条件脚本',
  `limit_count` int DEFAULT '0' COMMENT '行为限制次数',
  `limit_window` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '行为时间窗口，如 1d/1h',
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'ACTIVE',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`policy_id`),
  UNIQUE KEY `uk_policy_name` (`policy_name`),
  KEY `idx_conflict_type` (`conflict_type`),
  KEY `idx_sod_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sod_violation` (
  `violation_id` bigint NOT NULL AUTO_INCREMENT,
  `policy_id` bigint NOT NULL,
  `policy_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_id` bigint DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `operator_id` bigint DEFAULT NULL,
  `violation_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'GRANT / RUNTIME',
  `details_json` json DEFAULT NULL,
  `blocked` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`violation_id`),
  KEY `idx_policy` (`policy_id`),
  KEY `idx_card` (`card_id`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subject_progress` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `subject_id` bigint NOT NULL,
  `completed_chapters` int DEFAULT NULL,
  `total_chapters` int DEFAULT NULL,
  `completed_levels` int DEFAULT NULL,
  `total_levels` int DEFAULT NULL,
  `completion_percentage` decimal(8,2) DEFAULT NULL,
  `average_score` decimal(8,2) DEFAULT NULL,
  `study_minutes` int DEFAULT NULL,
  `total_points` int DEFAULT NULL,
  `last_activity_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_subject_progress_user` (`user_id`),
  KEY `idx_subject_progress_subject` (`subject_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='学科进度表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_settings` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(128) NOT NULL,
  `setting_value` text,
  `value_type` int NOT NULL DEFAULT '0',
  `category` varchar(64) DEFAULT NULL,
  `display_name` varchar(128) DEFAULT NULL,
  `description` text,
  `is_system` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_system_settings_key` (`setting_key`),
  KEY `idx_system_settings_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='系统配置表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenant` (
  `tenant_id` bigint NOT NULL AUTO_INCREMENT,
  `tenant_code` varchar(64) NOT NULL,
  `tenant_name` varchar(128) NOT NULL,
  `tenant_type` varchar(32) NOT NULL,
  `status` varchar(32) NOT NULL DEFAULT 'ACTIVE',
  `parent_tenant_id` bigint DEFAULT NULL COMMENT '父租户ID（NULL=根租户）',
  `path` varchar(512) DEFAULT NULL COMMENT '物化路径，如 /1/2/5',
  `depth` int NOT NULL DEFAULT '0' COMMENT '层级深度（0=根）',
  `contact_person` varchar(64) DEFAULT NULL,
  `contact_phone` varchar(32) DEFAULT NULL,
  `contact_email` varchar(128) DEFAULT NULL,
  `max_members` int NOT NULL DEFAULT '1000' COMMENT '最大成员数',
  `max_admins` int NOT NULL DEFAULT '10',
  `current_members` int NOT NULL DEFAULT '0' COMMENT '当前成员数',
  `license_key` varchar(256) DEFAULT NULL,
  `license_expires` datetime DEFAULT NULL,
  `logo_url` varchar(512) DEFAULT NULL COMMENT 'Logo URL',
  `settings_json` json DEFAULT NULL,
  `org_id` bigint DEFAULT NULL,
  `country` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `province` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `city` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `district` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `address` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `postal_code` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `website` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `verified` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`tenant_id`),
  UNIQUE KEY `uk_tenant_code` (`tenant_code`),
  KEY `idx_tenant_parent` (`parent_tenant_id`),
  KEY `idx_tenant_path` (`path`),
  CONSTRAINT `fk_tenant_parent` FOREIGN KEY (`parent_tenant_id`) REFERENCES `tenant` (`tenant_id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=1157225487810001 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='租户主表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenant_audit_log` (
  `log_id` bigint NOT NULL AUTO_INCREMENT COMMENT '日志ID',
  `tenant_id` bigint NOT NULL COMMENT '租户ID',
  `operator_id` bigint DEFAULT NULL COMMENT '操作人用户ID',
  `action` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '操作类型',
  `target_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '目标类型',
  `target_id` bigint DEFAULT NULL COMMENT '目标ID',
  `detail_json` json DEFAULT NULL COMMENT '详情JSON',
  `ip` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '操作来源IP',
  `trace_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '链路追踪ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`log_id`),
  KEY `idx_tal_tenant` (`tenant_id`),
  KEY `idx_tal_operator` (`operator_id`),
  KEY `idx_tal_action` (`action`),
  KEY `idx_tal_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='租户操作审计日志';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenant_domain_map` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint NOT NULL,
  `domain_id` bigint NOT NULL,
  `granted_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `granted_by` bigint DEFAULT NULL,
  `status` varchar(32) NOT NULL DEFAULT 'ACTIVE',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tenant_domain` (`tenant_id`,`domain_id`),
  KEY `fk_tdm_domain` (`domain_id`),
  CONSTRAINT `fk_tdm_domain` FOREIGN KEY (`domain_id`) REFERENCES `platform_domain` (`domain_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tdm_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`tenant_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1157225487810009 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='租户-域映射';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenant_invitation` (
  `invitation_id` bigint NOT NULL AUTO_INCREMENT COMMENT '邀请ID',
  `tenant_id` bigint NOT NULL COMMENT '租户ID',
  `sub_tenant_id` bigint DEFAULT NULL COMMENT '目标子租户ID',
  `dept_id` bigint DEFAULT NULL COMMENT '目标部门ID',
  `invite_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '邀请码（唯一）',
  `role` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'MEMBER' COMMENT '邀请角色',
  `invited_by` bigint DEFAULT NULL COMMENT '邀请人用户ID',
  `max_uses` int DEFAULT NULL COMMENT '最大使用次数（NULL无限制）',
  `current_uses` int NOT NULL DEFAULT '0' COMMENT '已使用次数',
  `expires_at` datetime DEFAULT NULL COMMENT '过期时间',
  `status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE' COMMENT 'ACTIVE / REVOKED / EXHAUSTED',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`invitation_id`),
  UNIQUE KEY `uk_invite_code` (`invite_code`),
  KEY `idx_ti_tenant` (`tenant_id`),
  KEY `idx_ti_status` (`status`),
  KEY `idx_ti_sub_tenant` (`sub_tenant_id`),
  KEY `idx_ti_dept` (`dept_id`),
  CONSTRAINT `fk_ti_dept` FOREIGN KEY (`dept_id`) REFERENCES `departments` (`dept_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ti_sub_tenant` FOREIGN KEY (`sub_tenant_id`) REFERENCES `tenant` (`tenant_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ti_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`tenant_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='租户邀请码';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenant_members` (
  `member_id` bigint NOT NULL AUTO_INCREMENT COMMENT '成员记录ID',
  `user_id` bigint NOT NULL COMMENT '用户ID',
  `tenant_id` bigint NOT NULL COMMENT '所属根租户ID',
  `sub_tenant_id` bigint DEFAULT NULL COMMENT '所属子租户ID',
  `dept_id` bigint DEFAULT NULL COMMENT '所属部门ID',
  `admin_level` int NOT NULL DEFAULT '0' COMMENT '管理等级（0=成员, 1+=管理层级, 值越大权限越高）',
  `role_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'MEMBER' COMMENT 'TENANT_OWNER / ADMIN / MEMBER',
  `position` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '职位名称',
  `member_status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE' COMMENT 'ACTIVE / SUSPENDED / REMOVED',
  `is_primary` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否主租户',
  `joined_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `invited_by` bigint DEFAULT NULL COMMENT '邀请人ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`member_id`),
  UNIQUE KEY `uk_member_user_tenant` (`user_id`,`tenant_id`),
  KEY `idx_tm_tenant` (`tenant_id`),
  KEY `idx_tm_sub_tenant` (`sub_tenant_id`),
  KEY `idx_tm_dept` (`dept_id`),
  KEY `idx_tm_role` (`tenant_id`,`role_type`),
  KEY `idx_tm_user` (`user_id`),
  CONSTRAINT `fk_tm_dept` FOREIGN KEY (`dept_id`) REFERENCES `departments` (`dept_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_tm_sub_tenant` FOREIGN KEY (`sub_tenant_id`) REFERENCES `tenant` (`tenant_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_tm_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`tenant_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tm_user` FOREIGN KEY (`user_id`) REFERENCES `platform_user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='租户成员表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenant_purchase` (
  `purchase_id` bigint NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint NOT NULL,
  `sub_tenant_id` bigint DEFAULT NULL COMMENT '若为子租户单独购买',
  `package_id` bigint NOT NULL,
  `status` varchar(16) DEFAULT 'ACTIVE',
  `purchased_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `expired_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`purchase_id`),
  KEY `idx_tp_tenant` (`tenant_id`),
  KEY `idx_tp_package` (`package_id`),
  KEY `idx_tp_sub_tenant` (`sub_tenant_id`),
  CONSTRAINT `fk_tp_package` FOREIGN KEY (`package_id`) REFERENCES `platform_package` (`package_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tp_sub_tenant` FOREIGN KEY (`sub_tenant_id`) REFERENCES `tenant` (`tenant_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_tp_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`tenant_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='租户购买记录';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenant_user_map` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `role` varchar(32) NOT NULL DEFAULT 'MEMBER',
  `status` varchar(32) NOT NULL DEFAULT 'ACTIVE',
  `joined_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `invited_by` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tenant_user` (`tenant_id`,`user_id`),
  KEY `fk_tum_user` (`user_id`),
  CONSTRAINT `fk_tum_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`tenant_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tum_user` FOREIGN KEY (`user_id`) REFERENCES `platform_user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='租户-用户绑定';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_badges` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `badge_id` bigint NOT NULL,
  `earned_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_badges` (`user_id`,`badge_id`),
  KEY `idx_user_badges_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户徽章表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_card` (
  `card_id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL COMMENT '可为空，发布后自动发放',
  `domain_id` bigint DEFAULT NULL,
  `card_type` varchar(32) NOT NULL COMMENT 'PLATFORM_CARD|ORG_CARD|STARTER_CARD',
  `card_status` varchar(32) NOT NULL DEFAULT 'ACTIVE',
  `template_id` bigint DEFAULT NULL,
  `level_id` bigint DEFAULT NULL,
  `priority` int NOT NULL DEFAULT '100',
  `is_primary` tinyint(1) NOT NULL DEFAULT '0',
  `valid_from` datetime DEFAULT NULL,
  `valid_until` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `tenant_id` bigint DEFAULT NULL,
  PRIMARY KEY (`card_id`),
  KEY `fk_uc_level` (`level_id`),
  KEY `fk_uc_template` (`template_id`),
  KEY `idx_uc_card_type` (`card_type`),
  KEY `idx_uc_domain` (`domain_id`),
  KEY `idx_uc_primary` (`is_primary`),
  KEY `idx_uc_user` (`user_id`),
  CONSTRAINT `fk_uc_domain` FOREIGN KEY (`domain_id`) REFERENCES `platform_domain` (`domain_id`),
  CONSTRAINT `fk_uc_level` FOREIGN KEY (`level_id`) REFERENCES `user_card_level_definition` (`level_id`),
  CONSTRAINT `fk_uc_template` FOREIGN KEY (`template_id`) REFERENCES `user_card_template` (`template_id`),
  CONSTRAINT `fk_uc_user` FOREIGN KEY (`user_id`) REFERENCES `platform_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1157225487810004 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户卡片';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_card_context_cache` (
  `card_id` bigint NOT NULL COMMENT '用户卡ID（user_card.card_id）',
  `context_hash` varchar(255) NOT NULL,
  `scope_json` json DEFAULT NULL,
  `grants_json` json DEFAULT NULL,
  `expire_at` datetime DEFAULT NULL,
  PRIMARY KEY (`card_id`),
  CONSTRAINT `fk_uccc_card` FOREIGN KEY (`card_id`) REFERENCES `user_card` (`card_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户卡上下文缓存';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_card_level_definition` (
  `level_id` bigint NOT NULL AUTO_INCREMENT,
  `domain_id` bigint NOT NULL,
  `level_no` int NOT NULL,
  `level_code` varchar(64) NOT NULL,
  `level_name` varchar(128) NOT NULL,
  `status` varchar(32) NOT NULL DEFAULT 'ACTIVE',
  `upgrade_strategy_json` text COMMENT '升级策略预留，当前为空',
  `description` varchar(512) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`level_id`),
  UNIQUE KEY `uk_iuld_domain_level_code` (`domain_id`,`level_code`),
  UNIQUE KEY `uk_iuld_domain_level_no` (`domain_id`,`level_no`),
  KEY `idx_iuld_status` (`status`),
  CONSTRAINT `fk_iuld_domain` FOREIGN KEY (`domain_id`) REFERENCES `platform_domain` (`domain_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户卡等级定义';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_card_template` (
  `template_id` bigint NOT NULL AUTO_INCREMENT,
  `domain_id` bigint NOT NULL,
  `tenant_id` bigint DEFAULT NULL COMMENT '租户ID',
  `parent_template_id` bigint DEFAULT NULL,
  `template_code` varchar(128) NOT NULL,
  `template_name` varchar(128) NOT NULL,
  `card_type` varchar(32) NOT NULL COMMENT 'PLATFORM_CARD|ORG_CARD|STARTER_CARD',
  `template_scope` varchar(32) NOT NULL DEFAULT 'SYSTEM' COMMENT 'SYSTEM|DOMAIN|ORG',
  `version_no` int NOT NULL DEFAULT '1',
  `default_priority` int NOT NULL DEFAULT '100',
  `default_roles_json` json DEFAULT NULL,
  `resource_scope_json` json DEFAULT NULL,
  `status` varchar(32) NOT NULL DEFAULT 'ACTIVE',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`template_id`),
  UNIQUE KEY `uk_uct_domain_code` (`domain_id`,`template_code`),
  KEY `idx_parent_template` (`parent_template_id`),
  CONSTRAINT `fk_parent_template` FOREIGN KEY (`parent_template_id`) REFERENCES `user_card_template` (`template_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_uct_domain` FOREIGN KEY (`domain_id`) REFERENCES `platform_domain` (`domain_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户卡模板（员工证/医疗证模板）';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_identity` (
  `identity_id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL COMMENT '冗余字段，便于快速查询',
  `identity_card_id` bigint DEFAULT NULL COMMENT '绑定的身份证ID',
  `provider_client_id` bigint DEFAULT NULL,
  `provider` varchar(64) NOT NULL COMMENT 'wechat|google|github|microsoft|local',
  `subject_key` varchar(255) NOT NULL,
  `account_key` varchar(255) DEFAULT NULL,
  `provider_user_id` varchar(255) DEFAULT NULL COMMENT '旧字段兼容',
  `provider_username` varchar(255) DEFAULT NULL,
  `provider_email` varchar(255) DEFAULT NULL,
  `provider_phone` varchar(64) DEFAULT NULL,
  `provider_data` json DEFAULT NULL,
  `verified` tinyint(1) NOT NULL DEFAULT '0',
  `provider_account_id` varchar(255) DEFAULT NULL,
  `provider_subject_id` varchar(255) DEFAULT NULL,
  `provider_subject_type` varchar(64) DEFAULT NULL,
  `provider_account_type` varchar(64) DEFAULT NULL,
  `app_id` varchar(128) DEFAULT NULL,
  `client_app_id` varchar(128) DEFAULT NULL,
  `tenant_id` varchar(128) DEFAULT NULL,
  `channel_code` varchar(64) DEFAULT NULL,
  `binding_status` varchar(32) DEFAULT NULL,
  `merged_to_identity_id` bigint DEFAULT NULL,
  `display_name` varchar(128) DEFAULT NULL,
  `avatar_url` varchar(512) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `email_verified` tinyint(1) DEFAULT '0',
  `meta_json` json DEFAULT NULL,
  `access_token_enc` blob,
  `refresh_token_enc` blob,
  `token_expires_at` datetime DEFAULT NULL,
  `last_used_at` datetime DEFAULT NULL,
  `bound_at` datetime DEFAULT NULL,
  `unbound_at` datetime DEFAULT NULL,
  `unbound_by` varchar(128) DEFAULT NULL,
  `disabled_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_primary` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`identity_id`),
  UNIQUE KEY `uk_ui_provider_user` (`provider`,`provider_user_id`),
  KEY `fk_ui_identity_card` (`identity_card_id`),
  KEY `idx_ui_subject_key` (`provider`,`subject_key`),
  KEY `idx_ui_account_key` (`provider`,`account_key`),
  KEY `idx_ui_provider_account_id` (`provider`,`provider_account_id`),
  KEY `idx_ui_provider_subject_id` (`provider`,`provider_subject_id`),
  KEY `idx_ui_provider` (`provider`),
  KEY `idx_ui_user` (`user_id`),
  CONSTRAINT `fk_ui_identity_card` FOREIGN KEY (`identity_card_id`) REFERENCES `identity_card` (`card_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ui_user` FOREIGN KEY (`user_id`) REFERENCES `platform_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户身份（第三方身份绑定到身份证）';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_learning_profile` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL COMMENT '用户ID',
  `score` int DEFAULT NULL COMMENT '积分',
  `user_level` int DEFAULT NULL COMMENT '用户等级',
  `completed_chapters` int DEFAULT NULL COMMENT '已完成章节数',
  `total_chapters` int DEFAULT NULL COMMENT '总章节数',
  `completed_percent` decimal(5,2) DEFAULT NULL COMMENT '完成百分比',
  `last_activity_at` datetime DEFAULT NULL COMMENT '最后活动时间',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_ulp_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户学习档案（历史遗留）';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_local_credential` (
  `credential_id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `login_name` varchar(128) DEFAULT NULL COMMENT '登录名（手机号/邮箱/用户名）',
  `password_hash` varchar(256) NOT NULL,
  `credential_version` bigint NOT NULL DEFAULT '1',
  `password_algo` varchar(32) NOT NULL DEFAULT 'ARGON2ID' COMMENT '密码算法',
  `password_set_at` datetime DEFAULT NULL COMMENT '密码设置时间',
  `password_updated_at` datetime DEFAULT NULL COMMENT '密码更新时间',
  `must_change_password` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否需要修改密码',
  `status` varchar(32) NOT NULL DEFAULT 'ACTIVE' COMMENT '状态',
  `last_login_at` datetime DEFAULT NULL COMMENT '最后登录时间',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`credential_id`),
  UNIQUE KEY `uk_ulc_user_id` (`user_id`),
  UNIQUE KEY `uk_ulc_login_name` (`login_name`),
  KEY `idx_ulc_user` (`user_id`),
  KEY `idx_ulc_login_name` (`login_name`),
  CONSTRAINT `fk_ulc_user` FOREIGN KEY (`user_id`) REFERENCES `platform_user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户本地凭证';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_mfa` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `mfa_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'TOTP|RECOVERY_CODES',
  `secret_enc` blob COMMENT 'AES-256-GCM åŠ å¯†çš„ TOTP Secret',
  `phone` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_enabled` tinyint NOT NULL DEFAULT '0',
  `is_primary` tinyint NOT NULL DEFAULT '0',
  `backup_codes_hash` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'JSON æ•°ç»„: SHA-256 å“ˆå¸Œçš„æ¢å¤ç ',
  `backup_codes_used` int NOT NULL DEFAULT '0',
  `verified_at` timestamp NULL DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `last_totp_counter` bigint DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_um_user_type` (`user_id`,`mfa_type`),
  KEY `idx_um_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_personal_permission_binding` (
  `binding_id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL COMMENT '用户ID',
  `permission_code` varchar(128) NOT NULL COMMENT '权限编码',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`binding_id`),
  KEY `idx_uppb_user` (`user_id`),
  KEY `idx_uppb_code` (`permission_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户个人权限绑定表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_profiles` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `school_id` bigint DEFAULT NULL,
  `tenant_id` bigint DEFAULT NULL,
  `total_levels_completed` int DEFAULT NULL,
  `total_questions_answered` int DEFAULT NULL,
  `overall_accuracy` decimal(8,2) DEFAULT NULL,
  `total_points` int DEFAULT NULL,
  `badge_count` int DEFAULT NULL,
  `current_level_id` bigint DEFAULT NULL,
  `last_activity_at` datetime DEFAULT NULL,
  `preferences` json DEFAULT NULL,
  `streak_days` int DEFAULT NULL,
  `total_correct_answers` int DEFAULT NULL,
  `user_rank` int DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_profiles_user` (`user_id`),
  KEY `idx_user_profiles_school` (`school_id`),
  KEY `idx_user_profiles_tenant` (`tenant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户学习档案表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_sessions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `refresh_token_id` bigint DEFAULT NULL,
  `device_id` varchar(255) DEFAULT NULL,
  `device_type` varchar(64) DEFAULT NULL,
  `device_name` varchar(255) DEFAULT NULL,
  `os_name` varchar(128) DEFAULT NULL,
  `os_version` varchar(128) DEFAULT NULL,
  `browser_name` varchar(128) DEFAULT NULL,
  `browser_version` varchar(128) DEFAULT NULL,
  `ip` varchar(64) DEFAULT NULL,
  `ip_location` varchar(512) DEFAULT NULL,
  `is_current` tinyint(1) NOT NULL DEFAULT '0',
  `trusted` tinyint(1) NOT NULL DEFAULT '0',
  `last_active_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `revoked` tinyint(1) NOT NULL DEFAULT '0',
  `revoked_at` datetime DEFAULT NULL,
  `revoked_reason` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_usersessions_user` (`user_id`),
  KEY `idx_usersessions_refresh` (`refresh_token_id`),
  KEY `idx_usersessions_device` (`device_id`),
  CONSTRAINT `fk_usersessions_user` FOREIGN KEY (`user_id`) REFERENCES `platform_user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户会话';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` bigint NOT NULL AUTO_INCREMENT,
  `openid` varchar(128) DEFAULT NULL,
  `unionid` varchar(128) DEFAULT NULL,
  `nickname` varchar(128) DEFAULT NULL,
  `avatar_url` varchar(512) DEFAULT NULL,
  `gender` int DEFAULT NULL,
  `phone_number` varchar(64) DEFAULT NULL,
  `score` int DEFAULT NULL,
  `level` int DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_login` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `uk_users_openid` (`openid`),
  UNIQUE KEY `uk_users_unionid` (`unionid`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='小程序用户表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webhook_configs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `webhook_url` varchar(512) NOT NULL,
  `events` json DEFAULT NULL,
  `secret_key` varchar(255) DEFAULT NULL,
  `use_hmac` tinyint(1) NOT NULL DEFAULT '0',
  `retry_times` int NOT NULL DEFAULT '3',
  `retry_delay` int NOT NULL DEFAULT '5',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_webhook_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Webhook配置表';
/*!40101 SET character_set_client = @saved_cs_client */;
