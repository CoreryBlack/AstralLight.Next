# AstralLight final9 frozen campaign evidence archive

- Run: `rust3n-dist-20260906-final9` (2026-09-06), three-node ZeroTier deployment.
- Campaign verdict: `EVIDENCE PASS: {'PASS': 11}` (scope=full), four provenance-identity
  gates PASS at every step boundary and campaign end, per-node exact-secret scan PASS.
- This is the only paper-eligible evidence source; earlier runs (final2-final8) are
  diagnostic and excluded.

## Pinned identities

| Item | SHA-256 |
|---|---|
| Production binary (astral-trustgraph) | `44d6b9562bb1b6022face27ec4313b80d270a3eb29c865f7f9b2dd94801fe6d0` |
| Engine-comparison binary | `4e7ae52caed48f20c9cc6e6e50371f172c6ab7377e82dbca19aaef25b99d8cfa` |
| Bootstrap binary | `cccd7d1cfc65eb8255d754a93a33038105260e54ac92b8d989d7694ba188ef62` |
| Source snapshot manifest (SOURCE_SNAPSHOT) | `5886ebb4e2fe40c4fd71bd2cf3b04157fa8aac618b08b017402c1bbce049a81a` |
| Source tar | `0eccc0131b2c116ad78d98f0c2cf028494b9b2cc87a00e33965fe42e2d07d74e` |
| Dirty-state patch | `debf74998967774471eef12d5d3f25ca80de829eb6d627095d74c13c90bac771` |
| Harness (combined, 10 files) | `46baf0089238eeb99c3d82ec9282964c9c0f496fbe136217a984421791713cd5` |
| Integration tree (382 files) | `65b86eae3728bc0544cfa5bd8981c353e0e31842d267adf93cad951245488bb7` |
| Source git revision | `6822d38ba504c42f38411179cc7d79c3bea7c70f` |
| OPA image | `1a8ce152ab9a54353573e68bbbdf5c74f0f22d0eec3c9d90c2657a95d3281151` |

## Contents

- `evidence/` — the 11-step campaign out-dir (128 artifact/log files verified
  digest-identical against the campaign host, plus `final9-deploy-provenance.json`
  (secret-free)). Contains `cs_evidence_manifest.json` (step records + final gates),
  `setup_provenance.json`, coordinator/perf/RQ/race/integration artifacts and logs,
  and `engine-comparison/` raw per-repeat CSVs. No secrets: the campaign's final
  exact-secret gate scanned this tree against all run credential values (PASS).
- `harness/` — the frozen 10-file experiment harness (including the coordinator,
  orchestrator, deploy script, seed) plus the TOCTOU script, digest-matched to the
  campaign's pinned harness identity.

## Verification

1. `sha256sum` any file and compare against the digests recorded inside
   `evidence/cs_evidence_manifest.json` and the table above.
2. The paper (Computers & Security submission, `Docs/ComputersSecurity/latex-cas-dc/`)
   cites exclusively numbers from this archive.
